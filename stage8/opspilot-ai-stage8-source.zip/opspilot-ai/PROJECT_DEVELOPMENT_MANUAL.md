# OpsPilot AI 项目开发手册

**项目名称：** OpsPilot AI  
**项目定位：** AI-Powered Cloud Native Operations Platform  
**项目类型：** AI 智能运维与云原生管理平台  
**项目目标：** 构建一个真实可运行、可部署、可测试、具备故障诊断能力的智能运维平台，用于个人技术学习、GitHub 开源展示及云原生运维岗位求职。

---

# 第一章：项目总体目标

## 1.1 项目介绍

OpsPilot AI 是一个基于 Python Flask、Kubernetes 和 DeepSeek 大模型构建的智能运维平台。

平台通过 Linux Agent 收集服务器运行指标，通过 Kubernetes API 获取集群资源和异常事件，通过 AI 对系统指标、容器日志和 Kubernetes Events 进行综合分析，最终实现：

1. Linux 多服务器监控。
2. Kubernetes 集群资源管理。
3. Docker 容器管理扩展。
4. AI 智能故障诊断。
5. 告警管理。
6. 自动化巡检。
7. 运维操作审计。

项目不是简单的 AI 聊天机器人，也不是只有静态页面的 Dashboard。

最终必须实现真实数据采集、真实 API 调用、数据库持久化、故障分析和可验证的功能。

## 1.2 项目开发原则

- 采用模块化单体架构，不采用微服务架构。
- 后端使用 Python Flask。
- 前端使用 Bootstrap 5，不引入 Vue 3。
- 优先使用已有技术栈，不盲目引入复杂组件。
- 所有功能必须有真实业务逻辑。
- 不允许通过模拟数据伪装成真实监控结果。
- 不允许一次性生成整个项目。
- 每次只开发一个明确模块。
- 每个模块必须经过测试和验收。
- 开发过程中同步更新 README 和项目进度。
- 必须保证项目能够在真实环境中部署运行。

---

# 第二章：实际开发环境

本项目已经拥有一套 VMware 多节点 Kubernetes 集群。

## 2.1 Windows 开发环境

Windows 电脑负责：

- PyCharm：Python 开发。
- Codex：辅助代码编写、分析、调试和测试。
- Git：版本控制。
- 浏览器：访问 OpsPilot AI 管理页面。
- Flask：开发阶段运行后端服务。

注意：Windows 是开发机，不是 Kubernetes 集群节点。

## 2.2 VMware 虚拟机环境

目前已经建立三节点 Kubernetes 集群。

| 节点名称 | 节点角色 | 内网 IP |
|---|---|---|
| k8s-master | Control Plane | 192.168.209.144 |
| k8s-node01 | Worker | 192.168.209.145 |
| k8s-node02 | Worker | 192.168.209.146 |

操作系统：

- Rocky Linux 9.4
- Kernel：5.14.0-427.13.1.el9_4.x86_64

Kubernetes：

- Kubernetes v1.32.13
- 容器运行时：containerd 1.7.29
- 三台节点均处于 Ready 状态。

## 2.3 特别重要的环境约束

1. 当前 Kubernetes 集群使用 containerd，不是 Docker Engine。
2. 不允许使用 Docker SDK 管理 Kubernetes 中的 Pod。
3. Kubernetes 资源统一通过 Kubernetes Python Client 管理。
4. Docker SDK 仅用于连接独立的 Docker Engine。
5. 三台 Linux 节点均可以作为 Linux 服务器监控对象。
6. Linux Agent 第一版优先直接运行在三台 Linux 宿主机上。
7. Windows 已经能够访问 Kubernetes API Server，但开发时仍需验证实际 endpoint、TLS 证书和认证。
8. 不需要额外创建一台虚拟机运行项目。
9. 不允许为了方便而将 Kubernetes API Server 暴露到公网。
10. 所有 IP、端口、认证信息必须配置化，不得随意硬编码。

Kubernetes API Server 地址必须从实际 kubeconfig 中获取：

```bash
kubectl config view --minify
```

以其中的 server 地址为准，不得未经验证就假设 API Server 一定使用某个 IP。

---

# 第三章：最终技术选型

| 技术分类 | 技术选型 | 主要用途 |
|---|---|---|
| 开发语言 | Python 3.11/3.12 | 后端和 Agent |
| 后端框架 | Flask | API 和业务逻辑 |
| 前端 | HTML5 + CSS3 | 页面结构和样式 |
| UI 框架 | Bootstrap 5 | 页面布局和组件 |
| 页面模板 | Jinja2 | Flask 页面渲染 |
| 前端交互 | JavaScript + Fetch API | 异步请求 |
| 数据可视化 | Chart.js | 监控图表 |
| 数据库 | MySQL | 业务数据和历史指标 |
| 缓存 | Redis | 最新状态和缓存 |
| ORM | Flask-SQLAlchemy | 数据库操作 |
| 数据迁移 | Flask-Migrate | 数据库版本管理 |
| 用户认证 | Flask-JWT-Extended | API 身份认证 |
| Linux 监控 | psutil | 系统指标采集 |
| HTTP 通信 | requests | Agent 上报 |
| Docker 管理 | Docker SDK for Python | 独立 Docker Engine 管理 |
| Kubernetes 管理 | Kubernetes Python Client | Kubernetes API 操作 |
| AI 模型 | DeepSeek API | 故障诊断 |
| Web 服务 | Nginx | 反向代理 |
| 部署 | Docker Compose | 应用部署 |
| 自动化测试 | pytest | 单元和集成测试 |
| 版本控制 | Git + GitHub | 项目管理 |

第一版不引入以下技术：

- Vue 3
- Element Plus
- ECharts
- Celery
- 微服务
- Prometheus
- Grafana

如果后续有明确需求，可以在项目第二阶段扩展，不允许一开始增加不必要的复杂度。

---

# 第四章：系统总体架构

采用模块化单体架构。

## 4.1 整体数据流

### Linux 监控数据流

```text
Rocky Linux Master
        |
        | psutil
        v
   Linux Agent
        |
        | HTTP POST
        v
Windows Flask API
        |
        v
数据校验与身份认证
        |
        +------ MySQL
        |
        +------ Redis
        |
        v
Bootstrap + Chart.js
```

Worker01 和 Worker02 采用相同的采集和上报方式。

### Kubernetes 数据流

```text
浏览器
  |
  v
Flask API
  |
  v
Kubernetes Service
  |
  v
Kubernetes Python Client
  |
  v
Kubernetes API Server
  |
  +--- Node
  +--- Pod
  +--- Deployment
  +--- Service
  +--- Namespace
  +--- Events
  +--- Pod Logs
```

### AI 诊断数据流

```text
Linux 指标
    |
Kubernetes Events
    |
Pod Logs
    |
    v
Flask 故障上下文整理
    |
    v
DeepSeek API
    |
    v
结构化诊断结果
    |
    v
MySQL 保存
    |
    v
前端展示
```

AI 诊断必须结合真实数据，不允许仅凭用户输入一句话就伪装成真实故障诊断。

## 4.2 模块职责

### Linux Monitoring

负责服务器指标采集、上报、存储和展示。

### Kubernetes Management

负责 Kubernetes 集群资源查询、异常识别和日志读取。

### Docker Management

负责独立 Docker Engine 的容器管理。

### AI Diagnosis

负责整合监控指标、日志和集群事件，生成诊断建议。

### Alert Management

负责规则判断、告警记录和处理状态。

### Audit Management

负责用户操作记录和重要操作审计。

---

# 第五章：项目功能需求

## 5.1 用户认证模块

功能：

- 用户登录。
- 用户退出。
- 用户身份认证。
- 用户权限控制。
- Token 或 Session 有效期管理。
- 未授权请求拦截。

要求：

- 密码必须安全哈希存储。
- 不得明文存储密码。
- API 必须进行身份验证。
- 关键操作必须检查用户权限。

## 5.2 Linux 服务器监控模块

每台 Linux 虚拟机运行一个 Python Agent。

第一版需要监控：

| 指标 | 采集方式 |
|---|---|
| CPU 使用率 | psutil.cpu_percent |
| 内存使用率 | psutil.virtual_memory |
| 磁盘使用率 | psutil.disk_usage |
| 网络发送流量 | psutil.net_io_counters |
| 网络接收流量 | psutil.net_io_counters |
| 系统运行时间 | 系统信息 |
| 主机名称 | socket.gethostname |
| Agent 心跳 | 定时上报 |

要求：

1. 三台服务器分别部署 Agent。
2. 每台服务器具有唯一身份标识。
3. Agent 每 15 秒上报一次。
4. Agent 支持配置文件。
5. Agent 网络失败时支持有限重试。
6. Agent 上报必须进行身份认证。
7. 服务端识别每台服务器。
8. 服务端记录历史指标。
9. 页面显示在线、离线状态。
10. 页面支持查看单台服务器详细信息。

注意：

Agent 第一版只负责采集和上报，不接收服务端任意 Shell 命令。

Agent 直接运行在 Rocky Linux 宿主机上，优先使用 systemd 管理。

后续可以扩展成 Kubernetes DaemonSet，但不能为了实现 DaemonSet 而牺牲主机监控安全性。

## 5.3 Kubernetes 管理模块

使用 Kubernetes Python Client。

必须实现：

### Node 管理

- 获取所有节点。
- 显示节点名称。
- 显示节点 IP。
- 显示节点状态。
- 显示节点角色。
- 显示 Kubernetes 版本。
- 显示容器运行时。
- 显示节点资源容量和可分配资源。

### Pod 管理

- 获取所有 Namespace 的 Pod。
- 查看 Pod 名称。
- 查看所在节点。
- 查看 Pod IP。
- 查看状态。
- 查看重启次数。
- 查看容器状态。
- 查看异常原因。
- 获取 Pod 日志。

### Deployment 管理

- 查询 Deployment。
- 查看期望副本数。
- 查看可用副本数。
- 查看部署状态。

### Service 管理

- 查询 Service。
- 查看 Service 类型。
- 查看 ClusterIP。
- 查看端口信息。

### Namespace 管理

- 获取 Namespace 列表。
- 显示 Namespace 状态。

### Events 管理

- 获取 Kubernetes Events。
- 按时间排序。
- 识别 Warning 事件。
- 展示相关资源和原因。

### 异常识别

至少识别：

- Pending
- CrashLoopBackOff
- ImagePullBackOff
- ErrImagePull
- OOMKilled
- FailedScheduling
- Node NotReady

要求：

1. Kubernetes 管理页面展示真实集群数据。
2. 支持按 Namespace 筛选。
3. 支持查看 Pod 日志。
4. 支持查看异常 Events。
5. API 错误必须明确返回。
6. 对 Kubernetes API 调用设置超时。
7. 对异常情况进行适当处理。
8. 第一版采用只读 RBAC。
9. 不使用集群管理员凭据作为项目长期运行凭据。

## 5.4 Docker 管理模块

由于当前集群使用 containerd，Docker 管理模块不负责管理 Kubernetes Pod。

第一版可以先完成独立 Docker Engine 的连接接口和容器查询功能。

如果当前没有独立 Docker Engine 测试环境，则明确标记为待接入，不得用 containerd 伪装 Docker。

后续功能：

- Docker 容器列表。
- 容器状态。
- 镜像列表。
- 容器日志。
- CPU 和内存使用情况。
- 受控启动和停止。

所有管理操作必须经过认证、权限校验和审计。

禁止直接向不可信网络暴露 Docker Socket 或未认证的 Docker TCP API。

## 5.5 AI 智能诊断模块

使用 DeepSeek API。

AI 必须能够分析：

1. Linux CPU 使用率过高。
2. Linux 内存不足。
3. Linux 磁盘空间不足。
4. Nginx 502 错误。
5. Docker 容器异常退出。
6. Kubernetes CrashLoopBackOff。
7. Kubernetes Pod Pending。
8. Kubernetes Node NotReady。

每次诊断至少输出：

```json
{
  "fault_type": "故障类型",
  "severity": "故障等级",
  "summary": "故障摘要",
  "evidence": [],
  "possible_causes": [],
  "troubleshooting_steps": [],
  "recommendations": [],
  "prevention": []
}
```

要求：

- AI 必须基于真实采集到的上下文进行分析。
- 诊断结果必须经过 JSON 解析和字段校验。
- API 调用失败必须有错误处理。
- DeepSeek API Key 通过环境变量读取。
- 不得把密码、Token、私钥等敏感数据发送给模型。
- 保存诊断历史。
- 记录诊断时间、关联服务器或集群资源。
- 诊断结果必须区分事实证据和推测根因。

安全要求：

AI 只负责分析和提出建议，不允许直接获得 root 权限，不允许直接执行高风险 Shell 命令或 Kubernetes 操作。

## 5.6 告警管理模块

第一版告警规则：

| 告警对象 | 规则 |
|---|---|
| CPU | 使用率超过 80% |
| 内存 | 使用率超过 85% |
| 磁盘 | 使用率超过 90% |
| Agent | 超过规定时间没有心跳 |
| Kubernetes | Node NotReady |
| Kubernetes | Pod CrashLoopBackOff |
| Kubernetes | Pod Pending 超过规定时间 |

要求：

- 告警规则可配置。
- 告警自动生成。
- 记录告警等级。
- 记录触发时间。
- 支持确认告警。
- 支持关闭告警。
- 保存历史记录。
- 避免同一故障重复生成大量告警。
- 记录告警来源和关联对象。

## 5.7 自动化巡检模块

第一版实现：

- Linux 服务器健康检查。
- CPU、内存、磁盘检查。
- Agent 心跳检查。
- Kubernetes Node 状态检查。
- Pod 异常检查。
- Kubernetes Warning Events 检查。
- 输出巡检报告。

自动化巡检先以只读检查为主，不执行危险操作。

## 5.8 审计模块

记录：

- 用户登录。
- 用户退出。
- 重要 API 操作。
- Kubernetes 查询。
- 容器管理操作。
- 告警处理。
- AI 诊断请求。
- 自动化任务执行。

审计记录至少包括：

- 操作用户。
- 操作类型。
- 操作对象。
- 操作时间。
- 操作结果。
- 请求来源。
- 必要的操作上下文。

不得将密码、Token、API Key 写入日志。

---

# 第六章：前端页面设计

使用 Bootstrap 5 + JavaScript + Chart.js。

整体采用简洁、专业的科技风格，布局清晰，适合运维监控大屏和日常管理。

必须有以下页面：

1. 登录页面。
2. Dashboard 总览。
3. Linux 服务器管理。
4. 服务器详细监控。
5. Kubernetes 集群管理。
6. Node 管理。
7. Pod 管理。
8. Deployment 管理。
9. Service 管理。
10. Events 事件管理。
11. Docker 管理。
12. AI 故障诊断。
13. 告警管理。
14. 自动化巡检。
15. 操作审计。

Dashboard 至少展示：

- 服务器总数。
- 在线服务器数量。
- 离线服务器数量。
- Kubernetes 节点数量。
- Ready 节点数量。
- Pod 总数。
- 异常 Pod 数量。
- 活跃告警数量。
- CPU 使用率图表。
- 内存使用率图表。
- 磁盘使用率图表。
- 最近故障事件。

所有页面必须通过后端 API 获取数据，不允许长期使用硬编码假数据。

如果后端数据暂不可用，应显示明确的错误或空状态。

---

# 第七章：数据库设计

使用 MySQL + Flask-SQLAlchemy。

第一版至少考虑以下数据模型：

## User

用户信息：

- id
- username
- password_hash
- role
- created_at

## Server

服务器资产：

- id
- hostname
- ip_address
- agent_id
- status
- os_version
- last_heartbeat
- created_at

## Metric

监控指标：

- id
- server_id
- cpu_usage
- memory_usage
- disk_usage
- network_in
- network_out
- collected_at

## Alert

告警：

- id
- alert_type
- severity
- source
- resource_name
- message
- status
- created_at
- resolved_at

## Diagnosis

AI 诊断：

- id
- fault_type
- severity
- summary
- evidence
- possible_causes
- recommendations
- created_at

## AuditLog

操作审计：

- id
- user_id
- action
- resource
- result
- created_at

具体字段和索引由 Codex 在设计阶段进一步分析。

要求：

- 合理设计主键和外键。
- 为常用查询字段建立索引。
- 指标数据必须考虑数据量增长。
- 不允许每 15 秒将全部指标无节制地永久存储。
- 后续需要设计历史数据保留和清理策略。
- 使用 Flask-Migrate 管理数据库迁移。
- 数据库密码从环境变量读取。

---

# 第八章：最终项目目录结构

```text
OpsPilot-AI/
│
├── backend/
│   ├── app.py
│   ├── config.py
│   ├── extensions.py
│   │
│   ├── api/
│   │   ├── auth.py
│   │   ├── servers.py
│   │   ├── metrics.py
│   │   ├── docker.py
│   │   ├── kubernetes.py
│   │   ├── alerts.py
│   │   ├── diagnosis.py
│   │   └── inspection.py
│   │
│   ├── models/
│   │   ├── user.py
│   │   ├── server.py
│   │   ├── metric.py
│   │   ├── alert.py
│   │   ├── diagnosis.py
│   │   └── audit.py
│   │
│   ├── services/
│   │   ├── monitoring_service.py
│   │   ├── docker_service.py
│   │   ├── k8s_service.py
│   │   ├── alert_service.py
│   │   ├── diagnosis_service.py
│   │   └── inspection_service.py
│   │
│   ├── integrations/
│   │   ├── kubernetes_client.py
│   │   ├── docker_client.py
│   │   └── deepseek_client.py
│   │
│   ├── ai_engine/
│   │   ├── analyzer.py
│   │   └── prompts.py
│   │
│   ├── templates/
│   └── static/
│       ├── css/
│       ├── js/
│       └── images/
│
├── agent/
│   ├── agent.py
│   ├── collector.py
│   ├── reporter.py
│   └── config.py
│
├── deploy/
│   ├── docker-compose.yml
│   └── nginx/
│
├── tests/
├── docs/
│
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
└── PROJECT_DEVELOPMENT_MANUAL.md
```

这只是最终规划，不允许一次性创建全部空文件。

必须根据开发进度逐步建立目录和文件。

---

# 第九章：分阶段开发计划

整个项目划分为九个阶段。

每个阶段完成后必须测试和验收，不能直接跳到下一阶段。

## 阶段 0：环境准备和项目骨架

任务：

- 检查 Windows 开发环境。
- 检查 Python 版本。
- 创建 Python 虚拟环境。
- 初始化 Git。
- 创建 Flask 项目。
- 创建基础目录。
- 配置 requirements.txt。
- 创建配置管理。
- 创建 `/api/v1/health` 健康检查接口。

验收标准：

- Flask 可以正常启动。
- 浏览器能够访问健康检查接口。
- 返回正确 JSON。
- Git 仓库正常。
- 项目依赖可以正常安装。

## 阶段 1：Kubernetes 连接测试

任务：

- 获取真实 Kubernetes API Server 地址。
- 配置 Kubernetes Client。
- 实现连接测试。
- 获取 Node 列表。
- 获取 Pod 列表。
- 获取集群版本。
- 处理认证和 TLS 错误。
- 验证只读 RBAC。

验收标准：

- Windows Flask 能够访问真实集群。
- 能够查询三台 Node。
- 能够获取真实 Pod。
- 不使用伪造数据。
- 连接失败时有明确错误信息。

## 阶段 2：Linux Agent 开发

任务：

- 实现 CPU 采集。
- 实现内存采集。
- 实现磁盘采集。
- 实现网络采集。
- 实现主机身份识别。
- 实现 HTTP 上报。
- 实现 Agent 心跳。
- 实现有限重试。
- 实现配置文件。
- 支持 Rocky Linux 9.4。
- 支持 systemd 管理。

验收标准：

三台 Linux 虚拟机均能向 Flask 上报真实数据。

服务端可以区分：

- k8s-master
- k8s-node01
- k8s-node02

## 阶段 3：数据库和后端业务

任务：

- 配置 MySQL。
- 配置 Redis。
- 配置 SQLAlchemy。
- 配置 Flask-Migrate。
- 创建用户模型。
- 创建服务器模型。
- 创建监控指标模型。
- 创建告警模型。
- 创建诊断记录模型。
- 实现服务器 API。
- 实现指标 API。
- 实现 Agent 身份认证。
- 实现用户认证。

验收标准：

- 数据能够写入 MySQL。
- 服务重启后数据仍然存在。
- Redis 能够正常工作。
- 不同服务器数据不会混淆。
- 未授权请求不能访问受保护 API。

## 阶段 4：前端监控 Dashboard

任务：

- 创建 Bootstrap 页面框架。
- 实现登录页面。
- 实现 Dashboard。
- 实现服务器列表。
- 实现服务器详情。
- 使用 Fetch API 请求后端。
- 使用 Chart.js 绘制监控图表。
- 实现定时刷新。
- 实现错误和空数据展示。

验收标准：

页面可以真实展示三台 Linux 虚拟机的数据。

## 阶段 5：Kubernetes 管理

任务：

- Node 管理。
- Pod 管理。
- Deployment 管理。
- Service 管理。
- Namespace 管理。
- Events 管理。
- Pod 日志查询。
- Pod 异常识别。
- Node 状态监控。

验收标准：

能够在页面查看真实 Kubernetes 集群资源。

能够识别至少以下异常：

- CrashLoopBackOff
- Pending
- ImagePullBackOff
- OOMKilled
- Node NotReady

## 阶段 6：Docker 管理扩展

任务：

- 设计 Docker Engine 连接模块。
- 使用 Docker SDK。
- 实现连接状态检测。
- 实现容器列表。
- 实现容器状态查询。
- 实现容器日志。
- 实现受控启停。
- 实现权限校验和审计。

重要：

当前集群使用 containerd，不允许将 containerd 伪装成 Docker Engine。

如果没有独立 Docker Engine 测试环境，先完成模块接口和单元测试，真实连接功能标记为待接入。

## 阶段 7：DeepSeek AI 故障诊断

任务：

- 封装 DeepSeek API。
- 管理 API Key。
- 编写 Prompt。
- 整理故障上下文。
- 设计结构化 JSON 输出。
- 实现 JSON 校验。
- 保存诊断记录。
- 展示诊断结果。

至少完成三个真实故障诊断场景：

1. Linux 磁盘使用率过高。
2. Docker 容器异常退出（需要 Docker Engine 测试环境）。
3. Kubernetes CrashLoopBackOff。

验收标准：

AI 能够基于真实日志、指标和事件生成结构化诊断。

## 阶段 8：告警、巡检、部署和项目完善

任务：

- 告警规则。
- 告警历史。
- 告警确认和关闭。
- 自动化巡检。
- 审计日志。
- Docker Compose 部署。
- Nginx 反向代理。
- pytest 测试。
- README。
- 架构图。
- 项目截图。
- 演示视频。
- GitHub 发布。

验收标准：

- 项目能够正常部署。
- 所有核心功能能够演示。
- 数据来源真实。
- API 和数据库正常。
- README 能够指导其他人部署。
- 核心安全措施已经实现。

---

# 第十章：安全设计

这是本项目的重要要求。

## 10.1 Kubernetes 安全

- 使用独立 ServiceAccount。
- 使用最小权限 RBAC。
- 第一版只读。
- 不使用集群管理员凭据长期运行。
- 不将 API Server 暴露到公网。
- kubeconfig 不得提交到 GitHub。
- API 访问必须验证 TLS 证书。

## 10.2 Agent 安全

- 每台 Agent 使用唯一身份。
- Agent 上报必须认证。
- 不允许接收任意 Shell 命令。
- 不允许未经授权执行远程操作。
- 不在日志中输出密钥。

## 10.3 AI 安全

- AI 不拥有 root 权限。
- AI 不直接执行命令。
- AI 不直接操作 Kubernetes 集群。
- AI 输出的建议必须由后端校验。
- 高风险操作必须经过人工审批。

## 10.4 Docker 安全

- 不暴露未认证 Docker TCP API。
- 不将 Docker Socket 暴露给不可信网络。
- 关键操作必须进行权限验证。
- 关键操作必须有审计记录。

## 10.5 配置安全

所有敏感配置放在 `.env`：

```env
SECRET_KEY=
DATABASE_URL=
REDIS_URL=
DEEPSEEK_API_KEY=
K8S_API_SERVER=
```

`.env` 必须加入 `.gitignore`。

GitHub 只提交 `.env.example`，不能提交真实密码、Token、API Key 或 kubeconfig。

---

# 第十一章：Codex 开发协作规范

Codex 必须严格遵守以下要求。

## 11.1 开发前

每次开发前：

1. 检查当前工作目录。
2. 检查现有文件。
3. 检查 Git 状态。
4. 阅读 README。
5. 阅读本开发手册。
6. 阅读已有开发进度文档。
7. 判断当前处于哪个开发阶段。
8. 不得覆盖或删除已有成果。

如果目录中已经有项目文件，必须先理解已有结构，再决定修改方案。

## 11.2 开发过程中

每次只处理一个明确任务。

开发前先向用户解释：

- 当前任务是什么。
- 为什么需要这个模块。
- 模块在整体架构中的位置。
- 使用了什么技术。
- 数据如何流动。
- 关键原理是什么。

然后再开始编码。

不允许一次性生成整个项目。

不允许为了完成任务而大规模重写已有代码。

不允许在没有分析问题的情况下随意修改配置。

## 11.3 代码质量要求

- 代码结构清晰。
- 函数职责明确。
- 模块之间低耦合。
- 使用合理的异常处理。
- 添加必要的注释和类型提示。
- 不编写无意义的复杂代码。
- 不硬编码敏感信息。
- 不返回虚假的成功状态。
- 不吞掉异常。
- 正确使用 HTTP 状态码。
- 对外部 API 设置超时。
- 对重要操作进行日志记录。

## 11.4 测试要求

每个模块开发完成后：

1. 运行语法检查。
2. 运行单元测试。
3. 运行必要的集成测试。
4. 检查 API 返回。
5. 检查数据库数据。
6. 验证异常情况。
7. 说明实际测试结果。

不得伪造测试成功。

如果因为环境缺失无法测试，必须明确说明原因和后续验证方法。

## 11.5 每次交付必须说明

每个任务完成后，向用户提供：

1. 本次完成的功能。
2. 新增的文件。
3. 修改的文件。
4. 每个文件的作用。
5. 核心代码原理。
6. 运行命令。
7. 测试命令。
8. 预期结果。
9. 实际测试结果。
10. 当前存在的问题。
11. 下一步建议。

每个阶段完成后：

- 更新 README。
- 更新 docs/DEVELOPMENT_PROGRESS.md。
- 记录已完成内容。
- 记录未完成内容。
- 建议 Git Commit。
- 等待用户确认后再进入下一个阶段。

---

# 第十二章：项目验收和求职展示

最终项目至少需要完成以下演示。

## 场景一：Linux 磁盘空间告警

1. 在某台 Linux 节点上制造安全、可控的磁盘使用率变化。
2. Agent 采集指标。
3. Flask 接收数据。
4. Dashboard 显示磁盘使用率。
5. 告警模块触发磁盘告警。
6. AI 分析相关指标。
7. 输出排查建议。
8. 保存诊断记录。

## 场景二：Kubernetes Pod 故障

1. 创建测试 Pod。
2. 让 Pod 进入异常状态。
3. Kubernetes 模块获取 Pod 状态。
4. 获取 Events。
5. 获取容器日志。
6. AI 综合分析。
7. 返回根因推测和排查建议。
8. 保存诊断记录。

## 场景三：Linux 节点异常

1. 查看三台节点的资源指标。
2. 识别 CPU、内存或磁盘异常。
3. 关联节点与 Kubernetes 资源。
4. 生成告警。
5. 输出诊断结果。

## 最终交付物

- 完整源代码。
- 完整项目目录。
- requirements.txt。
- Docker Compose 配置。
- Nginx 配置。
- 数据库模型和迁移文件。
- Linux Agent。
- Kubernetes 管理模块。
- AI 故障诊断模块。
- 自动化测试。
- README.md。
- 项目架构图。
- 项目部署说明。
- 功能演示截图。
- 项目演示视频。

最终项目必须能够从空环境按照 README 完成部署，并通过核心功能测试。

---

# 第十三章：最终开发要求

请将本手册作为 OpsPilot AI 的长期项目开发依据。

开发过程中始终坚持：

**先理解原理，再编写代码；先完成一个模块，再进入下一个模块；先保证真实可运行，再考虑功能扩展。**

不要追求代码数量，不要为了展示技术而引入没有实际价值的组件。

项目的最终目标不是生成一堆 Python 文件，而是构建一个能够真正连接 Linux、Kubernetes、Docker Engine 和 AI 模型的智能运维平台。

请从阶段 0 开始，先检查现有开发环境和工作目录，然后向用户报告环境检查结果与第一阶段实施计划。

未经用户确认，不要直接大规模修改项目文件或开始跨阶段开发。