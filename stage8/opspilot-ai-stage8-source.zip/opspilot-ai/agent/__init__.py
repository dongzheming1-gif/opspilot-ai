"""Linux host metrics agent; no remote command execution."""
