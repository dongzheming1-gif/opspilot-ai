import argparse
import logging
import time

from agent.collector import collect
from agent.config import load_config
from agent.reporter import report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    config = load_config(args.config)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    while True:
        started = time.monotonic()
        try:
            report(config, collect(config["agent_id"]))
            logging.info("Metrics accepted")
        except (RuntimeError, ValueError, OSError) as exc:
            logging.error("Collection/report failed: %s", type(exc).__name__)
            if args.once:
                raise SystemExit(1)
        if args.once:
            return
        time.sleep(max(0, config["interval"] - (time.monotonic() - started)))


if __name__ == "__main__":
    main()
