import json
from pathlib import Path
from urllib.parse import urlsplit


def load_config(path: str) -> dict:
    config = json.loads(Path(path).read_text())
    for name in ("agent_id", "token", "endpoint", "ca_file"):
        if not config.get(name):
            raise ValueError(f"Missing agent configuration: {name}")
    if urlsplit(config["endpoint"]).scheme != "https":
        raise ValueError("Agent endpoint must use HTTPS")
    config.setdefault("interval", 15)
    if config["interval"] < 5:
        raise ValueError("Interval must be at least 5 seconds")
    return config
