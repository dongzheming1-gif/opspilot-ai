import socket
import time
from datetime import datetime, timezone

import psutil


def collect_disk(path: str = "/") -> dict:
    """Read real filesystem counters; callers must preserve the filesystem scope."""
    usage = psutil.disk_usage(path)
    return {"total_bytes": usage.total, "used_bytes": usage.used,
            "free_bytes": usage.free, "disk_usage": usage.percent}


def collect(agent_id: str) -> dict:
    network = psutil.net_io_counters()
    return {
        "agent_id": agent_id,
        "hostname": socket.gethostname(),
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "cpu_usage": psutil.cpu_percent(interval=1),
        "memory_usage": psutil.virtual_memory().percent,
        "disk_usage": collect_disk()["disk_usage"],
        "network_in": network.bytes_recv,
        "network_out": network.bytes_sent,
        "uptime_seconds": max(0, time.time() - psutil.boot_time()),
    }
