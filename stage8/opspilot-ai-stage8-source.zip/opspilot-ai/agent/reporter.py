import time
import requests


def report(config: dict, payload: dict) -> None:
    """Three attempts maximum; never retry an authentication/validation failure."""
    for attempt in range(3):
        try:
            response = requests.post(config["endpoint"], json=payload,
                                     headers={"Authorization": "Bearer " + config["token"]},
                                     timeout=(3, 8), verify=config["ca_file"],
                                     allow_redirects=False)
            if response.status_code == 202:
                return
            if response.status_code < 500:
                raise ValueError(f"Report rejected: HTTP {response.status_code}")
            response.raise_for_status()
        except requests.RequestException:
            if attempt == 2:
                raise RuntimeError("Report failed after three network/server attempts") from None
        time.sleep(2 ** attempt)
