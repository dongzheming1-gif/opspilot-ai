# Linux Agent

2026-11-05 已在三台 Rocky Linux 主机部署并收到真实数据。

## 运行原理

每 15 秒使用 psutil 从 Linux 内核接口读取 CPU、内存、根分区、网卡累计字节数和启动时间。
CPU 采样窗口为 1 秒。网络值是累计字节，不是每秒速率；后续图表需用相邻样本差值除以时间差计算速率，并处理重启导致的计数器重置。
主机独立 agent_id 和 Token 标识身份，HTTPS 验证接收端证书。
失败最多尝试三次，认证或输入错误不重试。日志不包含 Token 或配置内容。

## 已部署路径

- `/opt/opspilot-agent/agent/`：代码。
- `/opt/opspilot-agent/python/`：独立 CPython 3.12.16，不替换系统 Python 3.9。
- `/opt/opspilot-agent/.venv/`：隔离环境。
- `/etc/opspilot-agent/config.json`：独立身份、上报地址、CA、间隔；权限 root:opspilot-agent 640。
- `/etc/opspilot-agent/ca.pem`：接收端证书。
- `/etc/systemd/system/opspilot-agent.service`：非 root 专用用户服务，已启用开机启动。

```bash
systemctl status opspilot-agent
journalctl -u opspilot-agent -n 20 --no-pager
sudo -u opspilot-agent /opt/opspilot-agent/.venv/bin/python -m agent.agent --config /etc/opspilot-agent/config.json --once
```

最后一条命令需在 `/opt/opspilot-agent` 工作目录运行。

## Windows 开发接收端

当前开发接收地址从实际 VMnet8 地址确定为 `https://192.168.209.1:5443/api/v1/metrics`。
证书与各主机凭据存储于排除 Git 的 `work/agent-secrets/`；证书有效期 30 天，部署阶段需替换或续期。
接收端拒绝未知身份、错误 Token、超出范围的指标、非有限数字和与服务端相差超过五分钟的时间戳。
阶段 2 仅使用最多 1000 条的内存缓冲，HTTP 202 明确声明 memory，不宣称持久化。
阶段 3 将接入 MySQL，开发接收器文件位于 work，仅为本次验收工具。

未修改 Windows 防火墙，未关闭 TLS 验证，未添加 Agent 远程执行能力。
