# Kubernetes 连接

应用使用 `deploy/kubernetes/readonly-rbac.yaml` 定义的 opspilot-reader ServiceAccount。
允许读取 Node、Pod、Deployment、Service、Namespace、Events 和 Pod 日志，不允许读取 Secret 或修改资源。
阶段 5 已开放受应用 JWT 保护的 `/api/v1/kubernetes/*` 只读业务接口。

```powershell
$env:K8S_KUBECONFIG = Join-Path (Get-Location) 'work\readonly-kubeconfig.json'
.\.venv\Scripts\python.exe -m flask --app backend.app:create_app check-kubernetes
```

本机只读 kubeconfig 位于被 Git 排除的 `work/readonly-kubeconfig.json`。不得分享或提交此文件。

阶段 5 新增可重复验收命令（要求 MySQL 可用、已有指定用户、kubeconfig 有效）：

```powershell
.\.venv\Scripts\python.exe -m flask --app backend.app:create_app verify-kubernetes --expected-nodes 3 --output outputs/kubernetes-acceptance.json
```

该命令在 Flask 本地测试客户端中使用现有用户的短期 JWT，调用真实 Kubernetes API；结束后退出并撤销测试 Token。
不输出密码、Token 或日志正文；结果只包含资源计数、观察到的异常、日志长度和新增审计数。
HTTP 接口可用与浏览器操作验收是不同检查，页面验证需另外完成。
当前外部开发/Compose 客户端的只读 Token 有效期为 30 天，由 API Server 实际签发时间为准；过期后请求将失败，不会自动降级成管理员。Token 只保存在 Git 忽略且 ACL 受限的 `work/readonly-kubeconfig.json` 中。
2026-11-07 已配置本机自动续期：Windows 任务计划程序每周一 09:00 及用户登录时检查。当前 Token 剩余有效期超过 21 天时不做网络请求；否则通过 SSH 请求 master 上的专用受限账户签发新 Token。SSH 私钥 ACL 仅允许当前用户、SYSTEM 和本机 Administrators 读取；master 上该账户没有密码登录权限，SSH key 强制执行一个固定命令，sudo 仅允许运行 root 所有的只读 ServiceAccount Token 签发脚本。
客户端验证新 Token 的 ServiceAccount 身份、有效期、真实 Node 列表读取，以及 Secret 列表仍被 403 拒绝；全部通过后才原子替换 kubeconfig。Token 不写入脚本日志或任务输出。每个应用请求都会重新读取 kubeconfig，所以无需重启 Flask。
手动检查/运行任务：`Start-ScheduledTask -TaskName 'OpsPilot-Kubernetes-Token-Renewal'`。普通运行若 Token 尚有超过 21 天有效期会记录 `not_due`；仅维护/验证时强制轮换：

```powershell
.\.venv\Scripts\python.exe deploy\windows\renew_kubernetes_token.py --force
```
Windows 机器关机、集群 master 未启动或网络不可达时，续期任务会失败并写入不含凭据的错误类型日志；任务在登录时、每周和系统补运行策略下重试。集群恢复后可以手动触发任务。将来容器内部署仍应改用 Kubernetes 投射的 ServiceAccount Token。

### 502 / upstream 401 的续期方法

浏览器的应用 JWT 和后端的 Kubernetes ServiceAccount Token 是两套凭据。
如果响应是 502 且 upstream_status=401，表示后端访问集群被拒绝；重新登录页面不能替换集群 Token。
2026-11-07 自动续期实测成功，新 Token 到期时间为北京时间 **2026-12-07 23:17:23**。Windows 任务计划 `OpsPilot-Kubernetes-Token-Renewal` 已注册，每周一 09:00 及用户登录触发；最近一次任务结果 0。轮换过程使用受限 SSH key，不储存 VM 密码。
真实 TokenRequest、Node 查询和 Secret 403 边界检查通过。API Server 的 TLS 校验保持开启；轮换身份只能为指定只读 ServiceAccount 签发 Token。

每个 API 请求的连接/读取超时为 3/10 秒，列表按页读取。TLS 必须启用，只接受 Token 身份配置，不运行 kubeconfig exec 插件。
CA 验证用于确认服务器身份；ServiceAccount Token 用于认证客户端；RBAC 决定客户端可以执行哪些操作。

2026-11-05 实测：3 个 Ready 节点、22 个 Pod；kubelet v1.32.13，API Server v1.32.2。
现有部分 Pod 为 Pending，这些是真实状态，项目未修改它们。
