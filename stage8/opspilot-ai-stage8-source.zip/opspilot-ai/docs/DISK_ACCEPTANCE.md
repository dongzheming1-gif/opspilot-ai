# 隔离磁盘高占用验收（2026-11-06）

本场景检验真实 Linux 文件系统采样、DeepSeek 诊断、MySQL 保存和页面历史。不会填满 Kubernetes 节点根分区。

## 原理

在 k8s-node02 的 /var/tmp 创建新的临时目录，目录内创建 64 MiB 文件，仅对这个新文件执行 mkfs.ext4，再通过 loop 设备挂载，启用 nosuid,nodev,noexec。
写入最多 60 个 1 MiB 块，每次 flush/fsync 后检查 psutil.disk_usage，超过 92% 就停止。容量很小，所以节点根盘额外占用有明确上限。
使用 agent.collector.collect_disk 读取真实字节数与百分比；线上 Agent 仍默认采集 /，没有修改线上配置或上报隔离指标。
脚本 finally 卸载后才删除自己的临时目录；卸载失败则保留文件并报错。强制杀进程/掉电不保证 finally 执行，重复验收前应检查遗留挂载，不可直接删除正在挂载的目录。

## 真实结果

- 测试镜像：67108864 字节；ext4 可报告空间：57381888 字节。
- 使用率：0.0% → 93.6%；写入后已用 52444160 字节、可用 3596288 字节。
- 节点根分区测试前后均为 30.6%。
- 临时挂载、镜像、数据与上传的辅助脚本均清理；复查未发现测试挂载/临时目录，Agent active。
- DeepSeek 真实诊断保存为 Diagnosis #10，模型明确指出隔离文件系统超过 90%，同时测试已清理且根分区未满。
- JWT 认证的详情 GET 返回 200，证据回读一致；Edge 浏览器真实查看历史与隔离范围说明通过，截图位于 outputs/disk-diagnosis-page.png。
- pytest 85 passed，compileall、JavaScript 语法、pip check 通过。

本轮使用本地受控验收脚本整理真实采样并调用共用 DeepSeek 适配器，沿用每小时限流与请求/结果审计；没有创建可任意提交外部证据的 HTTP 接口。
这不是主机 Agent 上报 → 历史曲线 → 自动告警的完整链路验收。隔离指标未写入现有根分区 Metric，避免混淆数据含义；自动告警为阶段 8 待实现功能。

## 文件

- agent/collector.py：提取 collect_disk 函数，原 collect 的默认 / 行为不变。
- tests/disk_scenario_linux.py：显式运行的 Linux 隔离验收工具，不由 pytest 或线上 Agent 自动执行。
- tests/test_disk_collector.py：磁盘路径与原默认行为的边界测试。
- backend/static/js/diagnosis.js：为隔离范围和已清理状态增加中文说明。
- work/verify_disk_diagnosis.py、work/check_disk_page.cjs：本机验收辅助，非生产入口。

## 复验

在 Linux 专用临时目录放置 tests/disk_scenario_linux.py 和 agent/collector.py（命名 collector.py），使用已安装 psutil 的 Python 以 root 显式运行：

```sh
python scenario.py
```

需要 mkfs.ext4/mount/umount、可用 loop 设备，以及宿主 /var/tmp 至少 1 GiB 可用。只在确认工具内容后使用；输出实际证据 JSON。不要对已有块设备执行格式化。
常规开发验证：

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m compileall -q backend agent tests
node --check backend/static/js/diagnosis.js
.\.venv\Scripts\python.exe -m pip check
```

无新依赖或数据库迁移。此轮没有把新版 collector 部署到线上 Agent，因为默认采集逻辑未变，隔离实验使用独立副本。
