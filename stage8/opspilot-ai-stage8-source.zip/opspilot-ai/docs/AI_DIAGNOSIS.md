# 阶段 7.1：主机诊断后端

数据路径：Agent → MySQL Metric → 白名单上下文 → DeepSeek HTTPS → JSON 校验 → MySQL Diagnosis。
阶段 7 已完成主机、Pod/Node、独立 Docker 上下文与前端展示；三类规定故障场景均有真实验收记录。

## 原理与安全边界

- 只读取指定服务器最新真实指标，超过 120 秒拒绝诊断，避免把旧数据当成当前状态。
- 仅发送 CPU、内存、磁盘百分比及采集时间、固定说明；主机名、IP、密码、日志原文、Token 不进入上下文。
- requests 已是现有依赖，无新增安装。密钥仅从 DEEPSEEK_API_KEY 环境变量读取。
- DEEPSEEK_MODEL 默认 deepseek-flash，可通过环境变量调整；HTTPS 地址固定为官方域名，不接受用户传入地址。
- JSON 模式不等于业务正确。后端额外校验字段、类型、长度、等级和证据引用，拒绝空白、截断和未知字段。
- evidence 引用本地保存的真实证据编号；possible_causes 是模型推测。编号校验不能证明推理正确，仍需人工核实。
- 没有命令执行入口。模型建议作为文本保存；后续页面必须使用 textContent 展示。
- 仅 admin/operator 可以请求；登录用户可查看历史。Redis 原子限流，每用户每小时最多 5 次尝试（失败同样计数）。
- 付费调用前先提交审计；成功后提交诊断和成功审计。调用超时或供应商错误不保存成功诊断，不自动重试。
- 数据库若在调用成功后不可用，可能已经产生 API 费用而未保存结果，当前版本没有跨系统事务或自动重试。
- HTTP 连接/读取超时为 5/45 秒，响应最大 256 KiB；读取块时检查 60 秒预算，该预算不是操作系统级硬截止。

## API

POST `/api/v1/diagnosis` 另支持 `{"source":"docker","container_id":"完整64位ID"}`。只采集状态、退出码、OOM 状态、重启次数及固定日志特征，不发送环境变量或日志原文。
GET `/api/v1/diagnosis/quota` 返回当前限额、剩余次数和窗口剩余秒数。DIAGNOSIS_HOURLY_LIMIT 默认 5，可配置为 1–100；页面读取真实配置。
本次验收因计数已满临时设为 8，完成后已恢复 5 并重启应用；没有清空历史计数。

请求均使用 Authorization: Bearer <登录返回的 JWT>。

POST `/api/v1/diagnosis`：`{"source":"server","server_id":1}`，服务器 ID 应从服务器列表读取。
成功 201 返回诊断及保存的 context/model；409 表示指标缺失/过期；429 表示额度用尽；502 表示上游失败；503 表示配置或限流服务不可用。

GET `/api/v1/diagnosis`：最近 50 条摘要。
GET `/api/v1/diagnosis/<id>`：诊断详情、采样证据和模型名称。

阶段 7.2 新增 POST 请求：

```json
{"source":"pod","namespace":"default","name":"实际 Pod 名称"}
```

```json
{"source":"node","name":"实际 Node 名称"}
```

资源名由现有资源列表取得。后端使用只读身份读取资源；按 UID 查询最多 100 条事件，有下一页时标记 truncated，不宣称获取全部或最新事件。
日志优先选异常容器，跳过已正常完成的初始化容器；只读取一个容器当前/上次日志，每次最多 200 行、32 KiB。
仅输出固定错误特征的计数，不发送日志原文、事件 message、资源名、IP、标签或环境变量。
特征包括 connection refused、permission denied、no space left on device、out of memory、no such file or directory、502 bad gateway。
未匹配不代表无错误；日志/事件读取失败会标记 unavailable。资源本身读取失败则拒绝诊断。
采集后复查 UID，若资源已重建则返回 409；这不是 Kubernetes 的原子快照，期间状态仍可能变化。
Ready 缺失记为 Unknown；初始化与应用容器计数分开，避免把完成的初始化容器当作业务就绪。
每次 Kubernetes 调用设置连接/读取 3/10 秒超时，最多两次资源读取、一次事件列表和两次日志调用。
请求最长时间可能超过前端原来的 15 秒；下一任务接入页面时需要调整诊断请求超时，不自动重试付费请求。

## 页面使用（阶段 7.3）

刷新浏览器并登录，左侧选择“AI 故障诊断”。选择 Linux 主机、Pod 或 Node，再选择实际资源，点击“开始 AI 诊断”。
页面显示模型返回的摘要、真实采样证据及限制、待验证原因、排查和处理建议。下方最近 50 条历史可点击详情。
页面不会自动触发诊断或每 15 秒重绘。手动“刷新数据”只刷新资源和历史，不发起模型请求。
请求等待上限 180 秒，期间禁用提交和导航；退出仍可用，但不保证取消已经开始的服务端请求。
超时/网络中断后应先刷新历史确认结果，避免重复付费。每用户每小时最多 5 次尝试，429 不会产生新的成功诊断。
viewer 可查看历史，但不能发起诊断。模型建议不会自动执行，页面也不提供执行命令按钮。

页面自动化测试：安装可选工具 `npm install --prefix work/ui-tests playwright --no-audit --no-fund`，保持本机 Edge、服务与 work/initial-login.json 可用，然后执行 `node tests/diagnosis_ui.cjs`。
测试包括真实登录/资源/历史与真实提交；若额度可用，提交会产生一次实际诊断调用及费用。若额度耗尽则验证 429。
另以拦截响应检查成功展示、重复点击、恶意 HTML 文本显示等边界，不将测试响应写入 MySQL。测试不属于生产运行依赖。

使用现有 Diagnosis JSON 列，无需新建表或执行数据库迁移。

## 官方接口依据

- https://api-docs.deepseek.com/guides/json_mode/
- https://api-docs.deepseek.com/guides/thinking_mode/

## 本机验证（2026-11-05）

pytest 69 passed，compileall 成功，pip check 无依赖冲突。
实际读取三台 Agent 中一台的最新 MySQL 样本，调用 DeepSeek 成功，API 返回 201。
采样 CPU 0.8%、内存 9.7%、磁盘 35.3%，诊断未发现阈值异常；新增 Diagnosis 1 条，请求和成功审计均落库，详情回读一致。
真实结果见 outputs/diagnosis-backend-acceptance.json。
这不是磁盘高占用故障验收。阶段 7 的三个真实故障场景及页面验收尚未完成。

阶段 7.2 实测：83 项测试通过。真实 CrashLoopBackOff Pod 重启累计 345 次，当前及上次日志各匹配 connection_refused 一次；DeepSeek 返回结构化诊断，HTTP 201，MySQL 保存及详情回读通过。
真实 Node Ready=True，压力条件为 False；诊断同样返回 201 并保存。没有制造 Node NotReady 故障，不把健康 Node 诊断当作该故障验收。
复查修正了日志误选已完成初始化容器的问题，并重新执行真实调用；早期诊断作为历史保留，最终验收记录见 outputs/cluster-diagnosis-acceptance.json。

## 启动与测试

```powershell
.\.venv\Scripts\python.exe -m flask --app backend.app:create_app run --host 127.0.0.1 --port 5000
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m compileall -q backend tests
.\.venv\Scripts\python.exe -m pip check
```
