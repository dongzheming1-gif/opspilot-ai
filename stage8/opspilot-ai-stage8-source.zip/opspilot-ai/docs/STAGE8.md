# 阶段 8：告警、巡检、审计与部署

## 告警规则

Agent 每次上报指标时，在同一数据库事务中评估 CPU > 80%、内存 > 85%、磁盘 > 90%（默认）。超过阈值时生成活动告警，恢复时自动关闭，历史保留。阈值用 `ALERT_*_THRESHOLD` 配置。

巡检每五分钟检查 Agent 心跳（默认 60 秒）、Node Ready、Pod CrashLoopBackOff、Pending 超过 300 秒。`AGENT_OFFLINE_SECONDS` 与 `POD_PENDING_SECONDS` 可以调整。相同对象和规则保留一个活动告警；人工关闭后有一小时抑制期，避免每轮重复生成。Kubernetes 查询失败时报告标为 `partial`，不自动关闭既有集群告警。Warning Event 仅统计最近一小时，历史事件不会当作当前异常。巡检只调用 Kubernetes 列表接口，写入的只有本项目数据库报告和告警。

Compose 部署时，可在 `.env.compose` 设置上述阈值、`DIAGNOSIS_HOURLY_LIMIT` 和 `METRIC_RETENTION_DAYS`；这些值会同时传给应用和巡检容器。修改后需要重新创建容器才会生效。

## API 与权限

| 接口 | 作用 | 角色 |
|---|---|---|
| `GET /api/v1/alerts?status=open` | 查询最近 200 条告警 | admin/operator/viewer |
| `POST /api/v1/alerts/{id}/acknowledge` | 确认 | admin/operator |
| `POST /api/v1/alerts/{id}/close` | 关闭 | admin/operator |
| `POST /api/v1/inspections` | 立即执行只读巡检 | admin/operator |
| `GET /api/v1/inspections` | 最近 50 次巡检 | admin/operator/viewer |
| `GET /api/v1/inspections/{id}` | 巡检报告 | admin/operator/viewer |
| `GET /api/v1/audit-logs` | 最近 200 条操作记录 | admin |

所有接口均需要 JWT。定时巡检用 `flask inspect`，以系统操作写入审计；手动巡检记录执行用户。审计中有用户、操作、对象、时间、结果和来源 IP。列表均设置上限，避免无界查询。

## 本地验证

```powershell
.\.venv\Scripts\python.exe -m flask --app backend.app:create_app db upgrade
.\.venv\Scripts\python.exe -m flask --app backend.app:create_app inspect
.\.venv\Scripts\python.exe -m pytest -q
node --check backend/static/js/stage8.js
```

`inspect` 返回报告 ID、状态和检查结果数。`complete` 表示所需 Kubernetes 查询完成，仍需查看具体 findings；`partial` 表示集群查询失败，不能据此判断集群健康。阶段验收证据保存在本机 `outputs/`，不包含登录凭据。

## 部署与限制

Compose 部署步骤见项目 README。2026-11-07 在独立 CentOS 7 虚拟机实际构建并启动 MySQL、Redis、应用、巡检和 Nginx；验证 HTTPS 证书、真实容器指标、告警处理、只读 Kubernetes 查询、巡检和审计，重启数据库和应用后持久数据仍在。隔离环境为触发真实采样告警临时将内存阈值设为 0%，未复用业务数据库或 Agent 凭据，也未在此环境重新调用付费 AI 或独立 Docker 管理引擎。

原 `nginx:stable-alpine` 在该旧内核上启动时 PID 写入报权限错误；项目改为 Debian 版 `nginx:stable` 并增加 HTTP 健康检查后实测通过。Compose 5.1.4 与该主机 Buildx 0.14.1 不兼容，实际使用 `DOCKER_BUILDKIT=0 docker build` 和镜像标签后 `up --no-build`；完整细节见 README。CentOS Linux 7 已于 2024-06-30 [停止维护](https://www.centos.org/centos-linux/)，不适合作为长期部署平台。当前 `mysql-1` 原副本复制故障和 WordPress 无历史内容的问题独立于本项目应用。
