# 告警规则与处理

Linux Agent 上报一个新指标样本后，后端在同一数据库事务中比较 CPU、内存和磁盘使用率。默认阈值分别为 80%、85%、90%，由 `.env` 中的 `ALERT_CPU_THRESHOLD`、`ALERT_MEMORY_THRESHOLD`、`ALERT_DISK_THRESHOLD` 配置，并校验为 0–100 的有限数值。每台主机同一规则只保留一条活动告警；恢复后自动关闭，下一次越线可以再次生成告警。

定时巡检补充 Agent 离线、Node NotReady、Pod CrashLoopBackOff、Pod Pending 超时告警。巡检间隔由 Compose `inspector` 进程定为五分钟；也可通过页面或 CLI 手动执行。人工关闭记录处理用户并抑制相同异常一小时，防止持续异常反复生成告警；自动恢复关闭不触发该抑制。Kubernetes 查询失败时不关闭已有集群告警。Warning Event 作为最近一小时的巡检发现，暂不单独生成告警。

`GET /api/v1/alerts` 需要登录，可用 `status=open|acknowledged|closed` 筛选最近 200 条。admin/operator 可确认或关闭，viewer 只读；处理写入审计。页面使用 DOM 文本节点展示告警内容，不把事件消息当作 HTML 执行。规则、巡检 API 与部署细节见 `docs/STAGE8.md`。
