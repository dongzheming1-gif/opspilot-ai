# 数据与认证

## 开发实例

Windows 已有 MySQL 8.0.29 程序被用于项目专用实例，数据目录为 work/mysql-data，端口 3307，仅绑定回环地址。
没有修改原有 3306 服务或其中的数据库。专用账号只能访问 opspilot 数据库，密码位于排除 Git 的 .env。
启动已有数据实例时不要再执行 initialize 或初始化 SQL：

```powershell
& C:\mysql-8.0.29-winx64\bin\mysqld.exe --no-defaults --basedir=C:/mysql-8.0.29-winx64 --datadir="$((Get-Location).Path)/work/mysql-data" --bind-address=127.0.0.1 --port=3307 --mysqlx=OFF --console
```

Redis 6.2.24 通过 Rocky 官方签名 RPM 安装到 master，独立服务 opspilot-redis，TLS 6380，关闭明文端口。
配置和数据路径为 /etc/opspilot-redis、/var/lib/opspilot-redis，内存上限 128 MB。
Redis 用于短期状态及登录限流，关键数据及退出 Token 撤销记录保存在 MySQL。
Redis 不可用时指标仍写入 MySQL并明确返回 cached=false；登录限流不可用时拒绝登录并返回 503。

## 数据库迁移与保留

```powershell
.\.venv\Scripts\python.exe -m flask --app backend.app:create_app db upgrade
.\.venv\Scripts\python.exe -m flask --app backend.app:create_app db check
.\.venv\Scripts\python.exe -m flask --app backend.app:create_app prune-metrics
```

迁移在修改数据库结构前应先审阅，生产需备份。指标保留期默认 7 天，每批删除最多 1000 条。
三台主机每 15 秒上报一天约 17280 条，七天约 120960 条；阶段 8 将配置周期清理。
server_id 与 collected_at 共同唯一，重试同一采样不会产生重复记录。UTC 存储，API 时间戳带 Z。

## 用户认证

```powershell
.\.venv\Scripts\python.exe -m flask --app backend.app:create_app create-user --username your-name --role admin
```

命令交互输入密码，不将密码放在命令行。密码至少 12 字符，经 Werkzeug scrypt 哈希后入库。
JWT 有效期 30 分钟；退出写入持久化撤销表，重启也不会重新激活退出 Token。
角色有 admin/operator/viewer。业务 API 必须认证；管理写操作后续按角色限制。
本机初始 admin 随机凭据仅保存在 work/initial-login.json，用于首次登录，不能提交或分享。

## 验收

真实 MySQL 已保存三台主机指标；新建应用实例读取到原数据。
真实 Redis TLS PING、SETEX、GET 成功；登录、受保护 API、退出撤销验证通过。
单元测试使用明确隔离的 SQLite 内存库和 Mock Redis，不代替真实 MySQL/Redis 验收。
