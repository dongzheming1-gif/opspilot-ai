# OpsPilot AI 小白使用手册

更新日期：2026-11-07。本文按当前 Windows + VMware 学习环境编写；真实部署的地址、证书和凭据以本机配置为准，不要把密钥抄进聊天、截图或 Git。

## 1. 先认识它在做什么

OpsPilot AI 是一个云原生运维工作台。它把三类信息汇集到一个页面：

1. **Linux 主机指标：**每台 Linux VM 上的 Agent 定时采集 CPU、内存、磁盘、网络累计字节、运行时间和心跳，再通过 HTTPS 上报。
2. **Kubernetes 集群状态：**后端用专用只读 ServiceAccount 查询 Node、Pod、Deployment、Service、Namespace、Events 和容器日志。
3. **独立 Docker Engine 状态：**后端通过双向 TLS 连接单独的 Docker Engine。这个 Engine 与 Kubernetes 的 containerd 分离，OpsPilot 不用 Docker SDK 管 Kubernetes Pod。

页面还提供 AI 诊断、告警、巡检和审计。AI 只分析证据并提出建议，**不会执行 Shell 命令、修复 Pod 或修改集群**。

## 2. 当前环境是什么样

| 机器/服务 | 用途 | 当前信息 |
|---|---|---|
| Windows 主机 | Flask 网页、开发数据库、Agent 接收端 | 浏览器访问 `http://127.0.0.1:5000/` |
| `k8s-master` | Kubernetes 控制平面、Redis、只读 Token 签发 | API Server `192.168.209.144:6443` |
| `k8s-node01` | Kubernetes 工作节点、Linux Agent | `192.168.209.145` |
| `k8s-node02` | Kubernetes 工作节点、Linux Agent、独立 Docker Engine | `192.168.209.146`；Docker API 使用 TLS |
| CentOS 7 VM | Compose 实际验收用 Docker 主机 | Dify 容器已删除；OpsPilot 的 6 个验收容器已停止，数据卷保留 |

当前使用四台 VMware VM。为让四台同时启动，VMware 全局内存设置现为 `prefvmx.minVmMemPct=25`。实测 `50` 时第四台 CentOS 因宿主机内存准入失败；`25` 可以启动，但允许 VMware 更多地交换内存。电脑重负载时可能变慢。CentOS 7 已停止维护，只适合本项目隔离学习验收，不建议作为长期生产主机。

## 3. 每次开机怎样启动项目

### 第一步：登录 Windows

Windows 用户登录后，`OpsPilot-AI-Start` 计划任务会依次启动本机 MySQL 3307、Flask 网页 5000 和 Agent HTTPS 接收端 5443。它**不会替你启动 VMware 虚拟机**。

检查本机任务结果：

```powershell
Get-ScheduledTaskInfo -TaskName 'OpsPilot-AI-Start'
```

`LastTaskResult` 为 `0` 表示任务正常结束。工作台健康接口可这样检查：

```powershell
Invoke-RestMethod http://127.0.0.1:5000/api/v1/health
```

健康接口只说明 Flask 进程能响应，不代表 Kubernetes、Redis 或 Agent 都已就绪。

### 第二步：在 VMware 中启动四台 VM

建议按这个顺序：

1. `Rocky9-Template`（实际 Kubernetes 节点名为 `k8s-master`），等待控制平面启动。
2. `k8s-node01`。
3. `k8s-node02`。
4. `CentOS 7 64 位`（只在需要这台 Docker/Compose 验收环境时启动）。

集群就绪后，工作台 Kubernetes 页面应显示三个 Node。Node Ready 前不要把短暂启动中的错误当成项目故障。Docker 管理页连接的是 node02 上独立的 TLS Engine；CentOS 是另一台 Docker 主机。

### 第三步：登录并逐项检查

1. 打开 `http://127.0.0.1:5000/`，用本机账号登录。初始账号资料仅在被忽略的 `work/initial-login.json` 中，不要把它发给别人；忘记密码时使用项目的 `create-user` 命令建立新用户。
2. 首页查看主机在线状态和 CPU、内存、磁盘曲线。
3. Kubernetes 页面检查 Node、Pod、Namespace；再按需查看 Deployment、Service、Events 和 Pod 日志。
4. Docker 页面查看独立 Engine 连接状态。若显示 `not_configured` 或不可达，先核对 `.env` 中的 `DOCKER_HOST` 和 TLS 文件，不要把 Kubernetes containerd 当作 Docker Engine。
5. 打开告警、巡检和审计页面检查当前状态。

正式验收快照曾显示 3 个 Node Ready、24 个 Pod、3 台 Agent 在线。它是某一时刻的真实数据，不保证以后每次开机后数量不变。

## 4. 页面各模块怎么用

### 主机监控

Agent 每约 15 秒采集并上报一次。主机离线通常表示 Agent 心跳超时、网络不通或接收端未启动。网络指标是网卡累计字节，不是即时速率；页面展示的图表需要结合相邻采样的变化理解。

### Kubernetes 资源

- Node：节点 Ready 状态、地址、版本、运行时及资源容量。
- Pod：按 Namespace 筛选，查看节点、状态、重启数、异常容器和日志。
- Deployment / Service / Namespace / Events：查看集群真实对象，不代表这些页面会修改集群。
- Pod 日志最多读取 200 行或 32 KiB；Events 和列表也有数量、时间预算，页面可能明确提示截断。

当前只读 RBAC 能查看规定资源，不允许读取 Secret 或创建、删除工作负载。查看 Secret 时得到 403 是预期的安全拒绝，不要为让页面“成功”而换成管理员 kubeconfig。

### AI 故障诊断

选择主机、Pod、Node 或独立 Docker 容器，点击“开始 AI 诊断”后，页面会展示：

- **证据：**来自采样指标、资源状态或本地保存上下文的事实。
- **可能原因：**模型基于这些证据作出的推测，需要你继续验证。
- **排查/预防建议：**仅供人工判断，不会被系统自动执行。

DeepSeek 调用有每用户每小时限额，模型调用可能产生费用。网络超时后先刷新历史确认诊断是否已经保存，不要连续点击造成重复请求。日志以固定错误特征计数的方式传给模型，不发送原始日志、Token 或环境变量。

**安全动作：**DeepSeek Key 曾经出现在聊天中，应在 DeepSeek 控制台撤销旧 Key、创建新 Key，只更新本机被 Git 忽略的 `.env`，再重启 Flask 使新值生效。不要把新 Key 发到聊天、截图或仓库。

### 告警

默认主机阈值：CPU 超过 80%、内存超过 85%、磁盘超过 90%。同一主机/规则只保留一个活动告警；指标恢复后自动关闭并保留历史。确认表示有人接手，关闭表示人工处理完毕；持续异常的人工关闭有一小时抑制期，避免巡检每轮重新生成。

Agent 离线、Node NotReady、CrashLoopBackOff 和超时 Pending 由巡检检查。Compose 的 `inspector` 每五分钟巡检一次；本机开发环境可从页面/API 或 `flask inspect` 手动启动巡检。Kubernetes 查询失败时报告应为 `partial`，`partial` 绝不等于集群健康。

### 审计

重要操作和用户身份写入 MySQL 审计表。审计页仅 admin 可看。用它确认谁在什么时候请求诊断、处理告警或执行其他记录操作；它不应被当作对 Shell 历史的替代。

## 5. Kubernetes Token 自动续期

本机任务 `OpsPilot-Kubernetes-Token-Renewal` 每周一 09:00 和 Windows 用户登录时检查 Token。只有剩余有效期不超过 21 天时才申请新 Token；程序实际测试新凭据能查询 Node、且读取 Secret 仍会被 403 拒绝后，才原子替换 kubeconfig。

查看任务和无凭据续期日志：

```powershell
Get-ScheduledTaskInfo -TaskName 'OpsPilot-Kubernetes-Token-Renewal'
Get-Content .\work\token-renewal\renewal.log -Tail 10
```

若 master 尚未启动，任务会失败并重试。启动集群后可手动补跑：

```powershell
Start-ScheduledTask -TaskName 'OpsPilot-Kubernetes-Token-Renewal'
```

该续期只用 Windows 任务计划、OpenSSH 和现有 Kubernetes API，不需要购买续期服务。SSH 私钥、只读 kubeconfig 和 Token 都在受限本机文件中；不要复制或公开。详见 [Kubernetes 连接说明](KUBERNETES.md)。

## 6. 常见现象与处理方法

| 现象 | 通常原因 | 安全处理 |
|---|---|---|
| 页面打不开或 health 不是 200 | 本机 MySQL/Flask 未启动，或端口被其他进程占用 | 查看 `OpsPilot-AI-Start` 任务结果和 `work/startup.log`；不要删除 MySQL 数据目录 |
| Kubernetes 502 / upstream 401 | 只读 Token 过期/无效，或 master/API 不可达 | 先确认 master 和 API Ready；查看 Token 续期任务日志并手动补跑 |
| Kubernetes 403 | 角色没有所请求动作的 RBAC 权限 | 若请求 Secret 或写集群资源，这是预期拒绝；不要加大权限绕过 |
| Node 暂时 NotReady | VM/节点启动中、kubelet/containerd 尚未恢复 | 等待服务就绪后刷新；不要立即重建节点或删除工作负载 |
| Docker 状态不可达 | node02 独立 Engine 未启动、TLS 证书或地址不匹配 | 核对 `docs/DOCKER.md`；不要连 `/run/containerd/containerd.sock` |
| AI 返回 429 | 每小时诊断额度已用完 | 等待限额窗口恢复，或查看已有诊断历史；不要重复提交 |
| AI 返回 502/503 | DeepSeek Key、网络、限流或后端配置问题 | 检查 `.env` Key 是否有效；不要在日志或聊天中打印 Key |
| VMware 拒绝启动第四台 | 内存策略回到 50，或宿主机内存不足 | 当前成功的设置是 25；先关掉不需要的 VM/应用，勿强制改 VMX 资源值 |

## 7. 正常关机

保存工作后，先正常关闭 CentOS 和两个 Kubernetes 工作节点，最后关闭 master。可以在 VMware 菜单使用来宾关机，也可以在各 Linux 来宾终端运行 `systemctl poweroff`。避免直接点“Power Off”或重置虚拟机；后者相当于突然断电。

Windows 登录任务不会开 VM。再次开机时先登录 Windows，再手动启动 VMware 中的 VM。四台 VM 级关机/启动已实际验收；Windows 整机冷启动后的全部流程仍待日后验证。

## 8. 需要记住的边界

- MySQL 3307 是 OpsPilot 的项目数据库，与 Kubernetes 里的原 `mysql-1` 不是同一个实例。后者复制错误尚未修复，不要用 OpsPilot 的 MySQL 覆盖它。
- Kubernetes 原 WordPress 没有找到可用历史内容备份；新建空站点不等于恢复旧内容。
- Dify 容器已移除，但其数据、配置、镜像和代码目录保留；不是磁盘彻底卸载。
- GitHub 尚未发布，源码包在本机 `outputs/opspilot-ai-stage8-source.zip`。
- CentOS 7 已停止维护；本项目的 Compose 验收通过不代表它适合作长期生产系统。

## 9. 词汇表

| 词 | 简单解释 |
|---|---|
| Agent | 安装在 Linux 主机上的轻量采集程序，负责上报指标 |
| API Server | Kubernetes 集群接收资源查询/管理请求的入口 |
| ServiceAccount | Pod 或外部程序访问 Kubernetes API 时使用的服务身份 |
| RBAC | Kubernetes 的授权规则，决定一个身份能读/写哪些资源 |
| Token | 这里指 Kubernetes ServiceAccount 凭据；与网页登录 JWT 不同 |
| JWT | 用户登录后访问 OpsPilot API 的短期凭据 |
| 双向 TLS | 客户端和服务端都用证书证明身份，适用于远程 Docker Engine |
| 持久化 | 进程/容器重启后，数据库中的业务记录仍保留 |
| 巡检 `partial` | 只完成部分检查；不能据此说集群健康 |
