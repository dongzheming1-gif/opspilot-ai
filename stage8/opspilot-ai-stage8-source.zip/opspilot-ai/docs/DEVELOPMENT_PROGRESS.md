# 开发进度

## 2026-11-05：阶段 0 完成

- 根目录正式手册与用户附件 SHA-256 一致：`9754D34FA5CA4C6AE373D1C7951726707BB6DE98C511C63C70BCE96CF0030F9D`。
- uv 0.13.7 安装于 work/tooling，用于获取独立 CPython 3.12.16；不修改全局 Python。
- `.venv` 已建立，`sys.prefix != sys.base_prefix` 为 True。
- Flask 3.1.3、python-dotenv 1.2.4、pytest 9.2.0 安装完成。
- Git 2.31 初始化失败（Permission denied）；使用本机已有 Git 2.56.0 成功初始化 main，无需改动权限。
- 实现配置管理与 GET `/api/v1/health`；未知路由及不允许的方法返回 JSON 错误，保留 Allow 头。
- compileall 成功；限定 tests 目录后 pytest 为 **5 passed**；pip check 无依赖冲突。
- 真实 Flask 进程 HTTP 检查：200、application/json，内容符合约定。
- 内置浏览器实际显示健康接口 JSON，完成浏览器验收。
- 初次未限定目录的 pytest 收集了 work 中的第三方测试（11 passed），不将其计为项目测试。

## 后续

阶段 1 已完成：实际 kubeconfig endpoint 为 https://192.168.209.144:6443，TLS 验证开启。
新建 opspilot-system Namespace、opspilot-reader ServiceAccount、只读 ClusterRole 和 ClusterRoleBinding。
Windows Flask CLI 使用独立只读凭据查到 3 个 Ready Node 和 22 个 Pod。
API Server 实测为 v1.32.2，节点 kubelet 为 v1.32.13；未变更现有集群版本。
权限自检：list nodes/pods 允许，get secrets、create/delete pods 拒绝；实际 Secret 查询 403、无效 Token 401、错误 CA 被 TLS 拒绝。
最初无效 Token 测试被客户端自动刷新钩子覆盖，修正测试禁用刷新后重测得到 401；未误判集群认证失效。
pytest 12 passed，compileall 成功，pip check 无冲突。测试中的分页和配置反例为明确的单元测试，不是监控数据。
开发只读 Token 24 小时需续期，方法见 docs/KUBERNETES.md。
之后逐阶段完成 Agent、数据库、前端、Kubernetes 管理、Docker、AI、告警巡检和部署。
每阶段均需真实验收；缺失的外部环境与凭据必须明确记录。

建议提交：`chore: establish stage 0 Flask foundation`。尚未执行提交或推送。

## 阶段 2 完成

三台 Rocky Linux 均安装独立 Python 3.12.16 和 psutil/requests，由 opspilot-agent 非 root 用户运行 systemd 服务。
实际通过 TLS 上报到 Windows VMnet8 地址，收到 k8s-master、k8s-node01、k8s-node02 三个唯一身份的 CPU、内存、磁盘、网络累计字节、运行时间和心跳。
接收记录位于本机 work/agent-receipt-evidence.json（真实采样，不是单元测试数据）。
配置验证、跨 Agent 冒充、异常数值、有限重试和认证错误不重试测试通过；pytest 共 23 passed，compileall 成功。
服务端目前为明确标注的有限内存缓冲。下一任务为阶段 3 MySQL/Redis 与认证、持久化。

## 阶段 3 完成

独立 MySQL 3307 已完成迁移，保留已有 3306 服务。建立 User、Server、Metric、Alert、Diagnosis、AuditLog 及 Token 撤销表。
三台 Agent 已切换到真实 MySQL 持久化；实际读取 3 个服务器和 20 条指标（验收时刻），新应用实例可读取原数据。
Redis 6.2.24 独立 TLS 服务已安装，真实 PING/SETEX/GET 成功，凭据不进入日志。
登录、退出撤销、服务器列表、指标历史、跨 Agent 认证、数据校验、缓存失败降级及去重已实现。
pytest 27 passed；compileall、pip check、db check 成功。真实 MySQL 登录与退出后拒绝访问验证通过。
初次 Redis dnf 安装超时，改从 Rocky 官方下载 RPM并通过 rpm 签名检查后安装，未禁用软件包签名校验。
下一任务为阶段 4 真实监控页面。

## 阶段 4 完成

Bootstrap 5.3.8 和 Chart.js 4.5.1 作为本地静态资源提供，原生 Fetch 获取认证 API。
实现登录、总览、服务器列表、主机选择、CPU/内存/磁盘历史曲线与 15 秒刷新，缺失数据与请求失败有明确提示。
浏览器实际显示三台主机在线及真实指标，续接开发时再次登录并复验成功。JWT 仅保存在页面内存，过期或刷新需重新登录。
首次浏览器测试发现 JS 括号错误引发默认 GET 表单提交；已修正语法、将表单明确设为 POST，并立即轮换初始密码使旧值失效。
Python 测试 27 passed，node --check 成功，HTTP 页面 200 和安全响应头已验证。
下一任务：阶段 5 Kubernetes 资源与异常展示。

## 阶段 5：已完成

已实现 Node、Pod、Deployment、Service、Namespace、Events 页面与认证接口，支持 Namespace 筛选和按容器读取当前/上次日志。
异常识别覆盖 Pending、CrashLoopBackOff、ImagePullBackOff、ErrImagePull、历史 OOMKilled、FailedScheduling 和 Node NotReady。
日志限定 200 行/32 KiB；Events 展示最近 200 条，返回 total/truncated，不以部分结果冒充完整列表。
分页查询增加时间预算、20000 条数量预算及重复游标检查，超限明确报错。
上游 401/403 返回明确的集群凭据/权限错误，不错误地注销用户的应用登录；上游错误正文和日志内容不会回显到错误响应。

本次真实验收：3 Node、22 Pod、8 Deployment、11 Service、9 Namespace、7660 Events（返回最近 200 条）。
实际识别 CrashLoopBackOff、ImagePullBackOff、Pending 等现存异常，读取真实容器日志（115 字符，不保存日志正文到验收输出），数据库新增 9 条查询审计记录。
新增可重复的 Flask CLI：verify-kubernetes，验证认证、真实资源、筛选、日志、只读 HTTP 方法及审计落库。
pytest **46 passed**；Python 编译检查、两份 JS 语法检查、pip check 通过。
真实验收结果保存于 outputs/kubernetes-acceptance.json。单元测试中的故障注入均与真实数据验证分开。

浏览器控制持续超时，不能把代码/API 验收等同于页面点击验收。已请求用户协助确认 Node/Pod 页面。
用户随后在本机浏览器逐项确认：登录、主机监控和曲线、Node、Pod 与 Namespace 筛选、Pod 日志、Deployment/Service/Namespace/Events、退出均通过，问题无。
据此阶段 5 完成验收，进入阶段 6。页面验收证据来自用户实际操作，不是浏览器工具自动验证。
DeepSeek Key 已配置在被忽略的 .env，仅验证读取，尚未进行真实 API 调用。

## 阶段 6：接口与单元测试完成，真实 Docker Engine 待接入

依据手册允许的无 Engine 分支，完成显式连接适配、状态、容器、镜像、日志、受控启停、角色校验和持久审计。
禁止明文 TCP，远程连接要求双向 TLS；启停默认关闭，仅允许管理员操作带 opspilot.managed=true 标签的容器，必须确认完整 ID。
Docker SDK 7.2.0 已安装。pytest 55 passed，compileall、JS 语法与 pip check 通过。
实际本地 Docker CLI 连接失败，应用状态接口返回 503 not_configured；未经认证返回 401，MySQL 审计已验证。
没有实际 Engine，不能将 Mock 测试写成容器真实操作成功，也没有对集群 containerd 做任何 Docker 操作。
新增 docs/DOCKER.md 说明配置和补验收方法。下一任务为阶段 7 DeepSeek 故障诊断。

## 阶段 7.1：主机诊断后端完成（阶段 7 尚未完成）

新增 DeepSeek 适配器、固定 Prompt、字段/证据校验、最新主机指标白名单上下文、认证诊断 API、历史/详情读取。
复用 requests 与现有 Diagnosis 表；无需新增依赖和迁移。Key 从环境变量读取，不打印或写入审计。
仅 admin/operator 可以发起，每用户每小时 5 次尝试；API 不自动重试，调用前审计先落库。
69 项 pytest 通过，compileall 和 pip check 通过。
2026-11-05 真实调用 DeepSeek 成功，接口 201；CPU 0.8%、内存 9.7%、磁盘 35.3%，模型返回未发现阈值异常。
MySQL 新增 1 条诊断，请求和成功审计通过，历史详情回读一致。结果记录 outputs/diagnosis-backend-acceptance.json。
此项只验证主机诊断真实链路，未宣称完成磁盘高使用率故障。未制造主机高负载或磁盘耗尽。
下一任务：Pod/Node 真实上下文和日志/Events 安全提取，随后 AI 页面与故障验收；独立 Docker Engine 仍待接入。
建议提交：feat: add validated host AI diagnosis backend。未执行 Git 提交或推送。

## 阶段 7.2：Pod/Node 诊断上下文完成

新增 cluster_diagnosis 服务，扩展诊断 API 与 Prompt。只读获取真实 Pod/Node、按 UID 关联最多 100 条 Events、异常容器当前/上次日志。
固定词组在本地提取为特征计数，原文不发送；事件 reason 和条件类型按白名单筛选。缺失、未知、截断明确标注。
修正初次实测中优先选到已完成初始化容器的问题；测试补充此反例，随后重新实测。
83 项 pytest 通过，compileall、pip check 通过。
最终真实 CrashLoopBackOff Pod 累计重启 345 次，当前及上次日志各提取 connection_refused 一次；诊断 201，新增记录并回读一致。
真实 Node Ready=True，压力状态 False，诊断 201、持久化与回读通过。没有实际测试 Node NotReady。
共执行两轮 Pod/Node 真实调用，历史均保留；最终报告 outputs/cluster-diagnosis-acceptance.json。
没有修改集群资源、没有执行模型建议。无新增依赖或数据库迁移。
下一任务：AI 诊断页面（资源选择、显式触发、等待/错误状态、证据和推测分开展示、历史详情）。阶段 7 整体未完成。

## 阶段 7.3：AI 诊断页面接入完成

新增 diagnosis.js，注册页面和导航。支持真实主机、Pod（显示 Namespace）、Node 选择、手动诊断、历史详情。
事实证据/限制与推测原因分开展示；全部外部文本使用 textContent。权限不足不允许发起，后端继续负责真实权限验证。
诊断页停止 15 秒自动刷新，诊断 POST 超时为 180 秒且不重试；期间禁用重复提交和导航；退出清理内存结果，过期异步响应不写回页面。
更新 app.js、index.html。无新增运行依赖、无数据库迁移。浏览器测试工具 Playwright 仅安装在忽略的 work/ui-tests，使用本机 Edge。
pytest 83 passed；Python 编译、JavaScript 语法检查通过。
真实浏览器验证登录、3 主机/Pod/Node 列表、已保存真实诊断详情、定时器不重置选择、退出清理、390px 无页面横向溢出。
本轮真实提交 HTTP 429（此前诊断已用完每小时 5 次尝试）；未修改限流或把 429 当作成功诊断。
成功返回、重复点击、HTML 文本安全、限流提示和 viewer UI 使用明确标记的边界测试；模拟响应不写数据库。浏览器无 JS 异常。
第一轮页面测试因集群连接暂时失败而超时，复查真实接口恢复后重测通过，页面提供可恢复错误提示。
结果见 outputs/ai-page-acceptance.json，桌面及手机截图已保存。阶段 7 整体仍缺磁盘高占用、Docker 独立 Engine 故障验收。
下一任务：安全可控的磁盘高占用场景设计与验收；Docker 仍标记待接入。无需重复请求开发许可。

## 阶段 7.4：隔离磁盘高占用诊断验收完成（2026-11-06）

在 node02 使用独立 64 MiB ext4 loop 文件系统，真实写入后使用率从 0.0% 升为 93.6%；根分区前后均 30.6%。
采集使用抽取的 collect_disk；线上 Agent 配置和根分区 Metric 未改，避免把隔离测试冒充节点根盘异常。
脚本卸载后清理，复查无测试挂载/临时目录，上传工具已移除，Agent 仍 active。
真实 DeepSeek 分析保存为 Diagnosis #10，明确区分测试高占用、已清理和宿主根盘正常；详情 API 回读及浏览器真实历史展示通过。
85 项 pytest 通过；compileall、JS 语法、pip check 通过。无新增运行依赖或数据库迁移。
产物 outputs/disk-filesystem-evidence.json、disk-diagnosis-acceptance.json、disk-diagnosis-page.png。
本任务完成真实文件系统采样 → AI → 诊断存储/页面；未声称完成 Agent 持续上报 → 曲线 → 自动告警链路，后者需多文件系统建模及阶段 8 告警能力。
阶段 7 整体仍缺独立 Docker 异常退出诊断；下一项核实独立 Docker 测试环境与补齐该场景，不能以 containerd 代替。

## 阶段 7：功能与三个真实场景验收完成（2026-11-06）

新增 docker_diagnosis.py，诊断 API/UI 支持独立 Docker 完整容器 ID。只发送白名单状态、退出码、OOM/重启数与日志特征。
node02 建立独立 Docker Engine 29.9.3，禁用网桥和防火墙/转发改动，独立 containerd/数据/运行目录；双向 TLS，未提供客户端证书实测拒绝。
通过真实受限容器读取不存在文件，进程退出码 1，状态 exited，日志 file_not_found。浏览器真实提交 201，Diagnosis #11 保存、回读一致，页面无 JS 错误。
新增可配置小时限额及 quota API/UI。验收临时由 5 调至 8，保留计数，验收后恢复 5 并重启。测试固定配置避免依赖本机 .env。
最终 pytest 93 passed；compileall、JS 语法与 pip check 通过。
三类证据：磁盘 #10（隔离文件系统 93.6%，清理完成）；CrashLoopBackOff #4（当前/上次日志 connection_refused）；Docker #11（exited/1/file_not_found）。
所有模型结果通过 JSON 字段与证据校验，保存时间、资源、上下文和审计。AI 不执行操作，无原始日志/密钥外传。
Docker 保留停止的测试容器及专用引擎用于复验；证书 30 天有效，服务未设开机自启，管理操作开关未打开。

最终环境检查发现 master API Server 持续重启（attempt 378），6443 间歇拒绝连接，两次复查失败；不能声称集群健康。node02 原 containerd PID=890 未变，kubelet/Agent active。
此前已通过的真实 CrashLoopBackOff 验收记录保留；阶段 7 功能和规定场景完成不代表控制平面稳定性问题已解决。下一项优先排查此基础设施问题，再继续阶段 8 告警/巡检/部署。未执行 Git 提交或推送。

## 控制平面修复（2026-11-06）

三台节点 kubelet systemd 与 containerd SystemdCgroup=false 不匹配，备份后统一 true，逐台重启两项服务。
master Flannel 缺镜像导致 subnet.env 缺失，从 node01 导入相同摘要的 v0.25.6 并重建失败 Pod，三台 Flannel、两台 CoreDNS 恢复。
连续观察控制平面 UID/重启数稳定，3 Node Ready，readyz/livez ok；项目真实 Kubernetes 查询/日志/审计复验通过。
证据 outputs/control-plane-observation.json、kubernetes-after-repair.json、控制平面修复报告.md。仍有原有业务和 metrics-server 镜像拉取问题，未宣称全业务正常。

## 镜像、存储、业务依赖及 Kubernetes 凭据修复（2026-11-06）

本次属于环境修复，不跨入阶段 8 功能开发。未修改应用业务代码、未增加应用依赖或数据库迁移。
重新签发 opspilot-reader 24 小时 Token，经 SFTP 原子更新忽略的 work/readonly-kubeconfig.json；到期北京时间 2026-11-07 16:52:32。
真实 Flask 5000 端口登录、六类 Kubernetes 查询、退出全部 200；CLI verify-kubernetes 通过，Secret 读取和 Deployment 创建 RBAC 均拒绝。
从 node01 缓存导出相同镜像，SHA-256 校验后导入 master、node02；两节点导入退出码均 0。0.8.1 Metrics Server 镜像已分发三节点。
Metrics Server 原 0.9.0 与 Kubernetes 1.32 版本不匹配，改为官方 0.8.1，并补建缺失 APIService；top nodes 三节点均返回指标，HPA 恢复伸缩。
三节点 Docker Hub /v2/ 均连接失败；registry.k8s.io、华为云 /v2/ 均收到 401 认证挑战。后者仅证明 TLS/端点连通，不保证每层镜像可下载。华为云 Kuboard etcd 镜像实际拉取成功。
NFS 服务及 provisioner 正常；5 PVC Bound，Released 的旧 PV 保留。nfs-deploy Endpoints 是 leader 锁，不是缺失后端的业务 Service。
Kuboard 缺失 etcd DaemonSet/Service，原 hostPath 数据存在。先备份，再按官方部署结构恢复；直接运行 etcd，避免镜像入口脚本打印 Token，关闭该容器 SA Token 挂载。
Kuboard 与其 etcd 均 Ready，页面版本接口 HTTP 200。保留原数据，未执行 etcd restore、force-new-cluster 或删除旧目录。
最终集群快照 23 Pod 容器全部 Ready，readyz/livez ok；控制平面重启计数与前次修复后相同。
业务限制：WordPress HTTP 302 跳安装页，其已配置数据库连接通过但表数 0；检查到的旧 wordpress 数据目录也只有 db.opt，不能视为可用内容备份。
MySQL 主从 Pod 虽 Ready，从库 Slave_IO_Running=No、SQL=Yes、Last_IO_Errno=13114；具体原因为 source 已清理所需 GTID/binlog（1236）。未重置复制、未跳过事务、未覆盖数据库。
下一项为独立数据恢复任务：先保存两库一致性备份并比对 GTID/业务内容，再用新卷验证从库重建；WordPress 需区分全新站点初始化与旧站点恢复，不能直接运行安装器覆盖历史意图。
证据 outputs/residual-environment-audit.json、kubernetes-live-renewal.json、kubernetes-renewal-check.json 和残留问题核查与凭据修复报告.md。
本轮运行真实环境检查，没有修改应用代码，也未重跑 pytest；此前 93 passed 不作为本次新测试结果。未提交或推送 Git。


## MySQL 数据恢复评估与隔离验证（2026-11-06）

对 mysql-0/mysql-1 分别执行 test_repl 一致性逻辑备份；single-transaction、gzip 校验和 SHA-256 均通过，备份目录权限 0700、文件 0600。
实测两端 t1 样例行相同，但 binlog 位置不同；主库 GTID 1-12，从库缺 1-5 并包含自身 UUID 1-5。复制原状仍 IO=No、SQL=Yes、错误 13114/1236。
在独立 opspilot-recovery Namespace 动态创建 statefu-nfs 新 1Gi PVC 和 MySQL 8.0.39 Pod，SA Token 自动挂载关闭；未连接原从库数据目录。
导入 mysql-0 备份后，独立 UUID、GTID 基线、表数及样例行均符合预期；Pod 1/1 Ready，PVC Bound。原从库复制状态复查未变。
证明演示数据库备份可恢复、NFS 新卷供给正常；不构成完整集群恢复或原从库追平验收。WordPress 数据仍为空，未初始化。
报告 outputs/MySQL数据恢复评估与隔离验证.md、mysql-recovery-validation.json。两份 test_repl 逻辑备份保存在 outputs/mysql-0-test_repl.sql.gz 与 mysql-1-test_repl.sql.gz；运维原件位于 master /var/backups/opspilot-mysql-20261106，禁止公开提交。
隔离命名空间/PVC/Pod保留供复核；删除 namespace 前须注意 statefu-nfs Retain 回收策略会保留 PV 和 NFS 目录。
本次实际运行备份、gzip、哈希和隔离实例恢复检查；没有应用代码改动，不涉及 pytest。未重置原复制或覆盖 PVC。
下一步：在另一个新卷上演练从主库备份重建 Replica、验证 GTID 自动定位和追平；WordPress 单独确认全新初始化还是从备份恢复。之后再进入阶段 8。


### 隔离 Replica 的 GTID 自动定位续验（2026-11-06）

隔离实例 server-id=3，read_only/super_read_only 均开启；用绑定隔离 Pod IP 的随机短期账户配置 SOURCE_AUTO_POSITION=1。
实际线程 IO/SQL=Yes，Seconds_Behind_Source=0，GTID 集合双方相同 e3b2df33-8712-11f1-b1a3-2e435783c21e:1-25，t1 行一致。
清理账户时在复制在线状态删除账户，待该事务复制且 GTID 相等后停止并清空隔离实例复制通道；主库、隔离实例均无临时账户。
原 mysql-1 仍 IO=No、SQL=Yes、错误 13114，未触碰原 PVC/配置。报告 outputs/mysql-replication-probe.json 与更新后的 mysql-recovery-validation.json。
故新卷重建/GTID 自动定位的隔离演练通过，不代表原从库修复。下一步仍需 WordPress 恢复决策与阶段 8。


## WordPress 恢复评估（2026-11-06）

当前 Bound WP 卷与旧 Released 副本均为默认 WordPress 文件树；两者 wp-content 清单摘要一致，431 文件 14.6 MB，uploads 0。
当前 MariaDB 连接成功但目标库 0 表；检查到的 Released MariaDB 卷 wordpress schema 目录只有 db.opt 或为空。搜索节点数据库归档未发现 WordPress SQL/归档备份。
没有发现可恢复的既有站点内容，证据支持站点尚未首次安装，但不能排除其他位置备份。没有运行安装向导或修改卷。
详见 outputs/WordPress恢复评估.md。WordPress 数据恢复评估完成；可将后续任务推进到阶段 8，独立的演示站初始化另计，不伪装成数据恢复。


## 阶段 8.1：Linux 指标告警后端（2026-11-06）

新增按 MySQL 指标样本计算的 CPU/内存/磁盘告警规则，默认 80/85/90，可用 ALERT_*_THRESHOLD 环境变量配置并校验 0..100。
在同一主机行锁保护下评估；同规则活动告警去重，指标恢复后自动关闭并保留历史。无数据库事务外通知。
新增认证告警列表/状态筛选 API；admin/operator 可确认或关闭，操作进入 AuditLog；viewer 只读。
Alert 已有表结构，无迁移；无新增依赖。新增 tests/test_alerts.py 与 docs/ALERTS.md。
首次定向运行因测试夹具局部作用域报错，改为文件内隔离 SQLite fixture 后通过。最终完整 pytest 95 passed；compileall 与 app.js 语法检查通过。
真实 Flask 5000 + MySQL/Redis 登录、告警列表 HTTP 200、非法筛选 400、退出 200；当时真实告警为 0 条，没有对业务主机注入测试指标。
进度报告 outputs/stage8-alert-backend.json。下一项：告警页面及处理交互，再补齐 Agent 离线/Kubernetes 事件告警与巡检，不将本模块宣称为完整阶段 8。

## 阶段 8 后续实现与验收（2026-11-06）

告警管理页面已接入状态筛选、确认与关闭；人工关闭记录用户并抑制持续异常一小时，自动恢复后再次越线可重新告警。`closed_by_user_id` 由第二次迁移加入。
自动化只读巡检覆盖三台主机指标与心跳、Node、Pod 和最近一小时 Warning Events，生成持久报告与告警，支持页面、API、CLI；Kubernetes 查询失败明确标记 partial，保留既有集群告警。后台定时器由 Compose inspector 服务每五分钟调用一次 CLI。审计页面仅 admin 可见，显示用户、操作、对象、结果、IP 与时间。
新增 Dockerfile、compose.yaml、Nginx TLS 反向代理、Waitress WSGI、部署说明和 Mermaid 架构图。页面截图和真实浏览器录屏保存在本机 outputs/，未携带密钥。
本机 MySQL 三次迁移已执行并通过 `db check`；第三次将告警关联对象字段扩大至 512 字符，以保存完整 Namespace/Pod 名。真实 CLI 巡检 #1 完整，3 台主机、3 Node、24 Pod、5 条发现；加入一小时事件过滤后巡检 #2 完整、2 条近期 Warning Event。真实 HTTP 登录、告警、巡检列表/详情、审计、退出均 200；Edge 页面与退出自动化通过，0 JS 错误。Waitress 本地独立端口健康接口 200。97 项 pytest 通过，JS 语法和依赖检查通过。
本机没有 Docker 守护进程；官方 Compose v5.6.0 独立程序在忽略的 work/ 下执行 `config --quiet` 通过，但未完成容器实际启动验收。Git 仓库无远程地址且无 GitHub CLI，GitHub 连接尚未建立；`git add` 创建 `.git/index.lock` 被系统拒绝，故未提交、推送或创建 Release。本机生成按 Git 忽略规则筛选的源码压缩包。原 MySQL 副本复制故障和 WordPress 无历史内容仍独立存在，不标为已恢复。

## 宿主机睡眠后复验（2026-11-07）

三台 VM SSH 可达，运行时间约两天，未见本次实际重启证据。kubelet、containerd、Agent 全部 active；master Redis active，本机 Flask5000/Agent5443/MySQL3307 监听。真实 MySQL SELECT 1、Redis PING 成功。
Kubernetes readyz ok、3 Node Ready、24 Pod 均 1/1 Running；Metrics Server `top nodes` 返回三台指标，六类资源查询、Pod 日志与审计共 9 条新增记录通过。三台 Agent 在线、Docker API 连接成功。巡检 #3 complete，0 条发现，告警当前 0 条。
node02 独立 Docker Engine 原为 disabled/active，已启用 systemd 开机启动；引擎继续使用独立目录与双向 TLS，未修改 kubelet/containerd。启用后 Docker API 200、Node Ready。
只读 Kubernetes Token 原定当日 16:52 到期；先续签 24 小时，再确认 API Server 实际接受 720 小时申请，将 master 脚本单行时长调整并备份原件。重新签发、校验并原子更新后实际到期北京时间 2026-12-07 13:53:23；运行中的 HTTP Kubernetes 概览、完整六类查询与审计通过，Secret 列表仍被 403 拒绝。当前仍是人工轮换，不宣称自动续期。
最新巡检 #4 complete，0 条发现；三台 Agent 在线，Docker 状态 connected。原 mysql-1 复制问题未修改。
原 mysql-1 复制仍为 IO=No、SQL=Yes、错误 13114/1236，未触碰原副本数据。Compose 实际启动和 GitHub 发布仍按用户选择保留本地发布包，未宣称完成。

## Windows 登录后自动恢复（2026-11-07）

新增 deploy/windows/start-opspilot.ps1 和 install-autostart.ps1；为当前用户注册 OpsPilot-AI-Start，登录时启动 MySQL 3307、Flask 5000、TLS Agent 接收端 5443。脚本校验端口使用者、避免重复启动，等待 VMnet8 地址，缺少原数据库目录时拒绝初始化。任务允许电池供电并配置失败重试。虚拟机仍须在 VMware 中启动，Redis 和 Kubernetes 要等待 master 就绪；Token 仍需轮换。
两次直接运行保留原监听 PID；任务计划程序手动触发返回 0。停止 Flask 5000 和接收端 5443 后，脚本实际重新启动，MySQL 进程保持原 PID；登录、3 Agent 在线、3 Ready Node、24 Pod 和 Docker 连接均返回正常。最后按更严格 MySQL 数据目录匹配复验脚本成功。尚未进行 Windows 关机或重启验收，不假称完成真实开机试验。

## Compose 配置复核（2026-11-07）

发现此前 Compose 没有向容器传递可配置的告警阈值、Agent 离线/Pending 超时、诊断配额和指标保留天数。已补充 compose.yaml 和 .env.compose.example，并说明更改后需重新创建容器。
实际运行 Compose config JSON 检查，默认值和自定义值在 app、inspector、migrate 三个服务中一致；独立运行 Python 配置加载器验证自定义值生效。pytest 97 passed。
本机 Docker 守护进程不可用，WSL 无已安装发行版。node02 专用 Docker Engine mTLS 连接正常，但仅有 host/none 网络且使用 vfs，Docker Hub hello-world 拉取实测因连接超时失败；未修改该 Kubernetes 工作节点的网络配置。Compose 镜像构建和整套服务启动仍待合适的 Docker 环境与镜像源，GitHub 发布按用户要求暂缓。

## 独立 CentOS Compose 真实验收及 Dify 清理（2026-11-07）

临时调整 VMware 内存交换策略并将用户指定的 CentOS 7 虚拟机内存设为 2196 MB，启动 192.168.209.100；原 VMX 已备份。Compose 5.1.4 + Docker 26.1.4 + Buildx 0.14.1；Compose build 要求 Buildx >=0.17，改用 Docker 兼容构建并按服务打标签。
首次 `nginx:stable-alpine` 在 Linux 3.10 上 PID 写入 EPERM、反复重启；对照 Debian nginx 在隔离网络中启动正常，改用 `nginx:stable` 并补充实际 HTTP 健康检查。重新部署后 MySQL/Redis/app/nginx 健康，迁移退出 0，巡检进程运行。
通过可信测试 CA 验证 HTTPS，登录、真实容器 Agent 样本、告警确认/关闭、3 Ready Node/24 Pod、巡检、审计与退出均成功；隔离环境为触发告警将内存阈值临时设为 0%。重启隔离 MySQL 与 app 前后用户2、指标1、告警1、巡检4、定时巡检审计3均保留。未在该 Compose 环境调用付费 AI 或连接 Docker 管理引擎，阶段 7 已在原环境真实验收。
用户随后要求删除 Dify；按 Compose 标签及工作目录核对后停止并移除 12 个 Dify 容器，保留其配置、21 个挂载来源、镜像和网络；未删除数据。VMware 配置文件 `prefvmx.minVmMemPct` 已从 25 调回原有“部分交换”对应的 50，当前四台 VM 与 OpsPilot 接口仍正常；由于 VMware GUI 控件未响应，正在运行进程是否已读取该文件未独立验证，且下次四台 VM 是否能在原策略下同时启动未测试。GitHub 发布按用户要求暂缓。

## 项目收尾复核（2026-11-07）

重新执行 `work/stage8_live_check.py`：登录、服务器、Kubernetes、Docker、告警、巡检、审计和退出均 HTTP 200；3 台 Agent 在线、3 Node Ready、24 Pod、Docker connected；最新巡检 complete，0 findings。OpsPilot-AI-Start 登录任务仍注册，最近运行结果 0；MySQL 3307、Web 5000、Agent TLS 接收端 5443 正在监听。
Dify Compose 标签下容器 0 个，原清单中的 21/21 挂载来源仍存在；Docker 上 OpsPilot 隔离验收容器 6 个均停止，MySQL/Redis 两个验收卷保留。Dify 服务已卸载，持久数据、配置、镜像和网络为避免不可逆数据丢失而保留；`/opt/dify` 代码目录约 1.1 GiB。所有四台 VM 仍运行，宿主机可用物理内存约 1.2 GiB。
VMware 全局配置文件已设为 `prefvmx.minVmMemPct=50`；目标 CentOS VMX 仍是临时的 2196 MiB，原配置 8780 MiB 有本机备份。由于正在运行的集群和本机资源余量，不为冷启动验证而重启 VM/宿主机，故 VMware 进程加载该策略、四台 VM 冷启动能力及 Windows 整机重启恢复仍未验收。不要据此宣称开机自恢复全部完成。
本机源码包已随本次文档更新重新生成并扫描常见密钥标记；GitHub 发布仍按用户选择暂缓。Kubernetes 只读凭据当前有效，记录的到期时间为北京时间 2026-12-07 13:53:23，尚未自动轮换。CentOS 7 已停止维护；原 MySQL 副本复制故障及 WordPress 历史内容缺失仍是独立环境遗留项。用户曾把 DeepSeek API Key 发在聊天中，应在 DeepSeek 控制台撤销旧 Key 并将新 Key 仅写回本机被忽略的 `.env`；本代理无 DeepSeek 控制台访问，未代用户轮换。

## 四台 VM 重启与 Kubernetes Token 自动续期（2026-11-07）

在真实关机前，OpsPilot 登录、三 Agent、3 Node/24 Pod、Docker 和巡检均正常。按 CentOS、两个工作节点、控制平面的顺序发送 systemd 正常关机；VMware 最终确认 0 台运行，控制平面 VMX 以退出码 0 结束。
按“控制平面→工作节点→CentOS”顺序使用 `vmrun start ... nogui`。已验证 VMware 全局配置文件的 UTF-8 编码。策略 `prefvmx.minVmMemPct=50` 实际拒绝第四台：CentOS `vmware.log` 记录 `minmempct 50`、`minalloc 3195734`、`admitted 0`；此时主机可用约 2.2 GiB。使用此前已允许且已验证的 `25`（允许更多虚拟机内存交换）后，四台全部启动；CentOS 记录 `minmempct 25`、`minalloc 1622870`、`admitted 1`。最终四台均在 `vmrun list` 中，所有 Kubernetes Node Ready、24 Pod、三 Agent 在线，Web/Docker/Kubernetes 检查成功，活动告警 0。Windows 宿主机未重启；这是 VM 级关机/启动实测，不是整机冷启动。
为自动续期新增 `deploy/windows/renew_kubernetes_token.py`、Windows 任务安装器及 master 端固定命令/权限安装脚本。master 上建立锁定密码的 `opspilot-renewer` 账户；SSH key 限定到 wrapper，wrapper 在 sudo 前拒绝任何用户命令；sudo 仅能以 root 执行固定的 TokenRequest 脚本。Windows 私钥和 kubeconfig ACL 仅给当前用户、SYSTEM、Administrators。
Windows 任务 `OpsPilot-Kubernetes-Token-Renewal` 已注册：每周一 09:00 与用户登录时检查，并配置系统补运行和失败重试。余额超过 21 天则不轮换；轮换时通过 HTTPS 验证指定 ServiceAccount subject/时长、真实 Node API 和 Secret 403，再原子替换本机 kubeconfig。执行不会记录 Token；Flask 每次请求重新读取 kubeconfig，无需重启。
实际 `--force` 续期成功，新凭据到期北京时间 2026-12-07 23:17:23；API 只读验证通过、Secret 返回 403。对 SSH 任意命令的边界测试得到退出码 126；任务计划手动执行 `not_due` 返回 0。新测试 4 项，完整 pytest **101 passed**；compileall 与 pip check 通过。验收报告见 `outputs/VM重启与Kubernetes Token自动续期验收.md`。

## 学习与求职文档（2026-11-07）

新增 `docs/BEGINNER_USER_GUIDE.md`，说明当前 VM/Windows 启动步骤、页面用法、Token 自动续期、常见错误和安全边界；新增 `docs/PROJECT_WORKFLOW_AND_ARCHITECTURE_GUIDE.md`，讲解阶段 0–8 制作过程、代码分层、真实数据流、关键设计取舍、验收证据、限制及简历/面试讲法。README 已增加入口链接。内容依据开发规范、源代码和真实验收记录撰写，不含口令或 Token。本地源码包随后重建并做常见凭据扫描。
