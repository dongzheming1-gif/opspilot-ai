# OpsPilot AI 架构

```mermaid
flowchart LR
    Browser[浏览器] -->|HTTPS| Nginx[Nginx 反向代理]
    Agent[三台 Linux Agent] -->|HTTPS + 独立 Token| Nginx
    Nginx --> App[Flask / Waitress API 与页面]
    App --> MySQL[(MySQL: 指标 / 告警 / 巡检 / 审计 / 诊断)]
    App --> Redis[(Redis: 登录限流 / 短期缓存)]
    App -->|只读凭据| K8s[Kubernetes API]
    App -->|双向 TLS| Docker[独立 Docker Engine]
    App -->|受限证据| AI[DeepSeek API]
    Inspector[每五分钟只读巡检] --> MySQL
    Inspector -->|只读| K8s
    Inspector --> Redis
```

浏览器只访问 Nginx；数据库、Redis、应用进程和巡检进程只在 Compose 内部网络。Agent 使用每台主机不同的 Token，上报采样数据。Kubernetes 客户端只允许查询规定资源，巡检不调用集群写接口。告警、诊断和审计保存在 MySQL，Redis 故障不会丢失已落库的记录。

从底层看，Flask 将 HTTP 请求映射到 Python 函数；SQLAlchemy 把 Python 模型映射到 MySQL 表；Alembic 迁移让数据库结构随代码版本演进。Nginx 终止 TLS 后把请求转给 Waitress，应用只信任这一层代理传来的客户端地址。
