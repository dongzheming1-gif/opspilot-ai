# 页面与验证

运行 Flask 后访问 http://127.0.0.1:5000/，使用本地生成的 admin 凭据登录，凭据文件为 work/initial-login.json。
JWT 只在当前页面内存中保存，不写入 localStorage；刷新或令牌过期后需重新登录。
浏览器使用 Fetch 发送 Authorization 头，后端验证身份，再查询真实数据库或 Kubernetes。
Bootstrap 5.3.8 与 Chart.js 4.5.1 存于 static/vendor，不依赖用户浏览器联网加载 CDN。

页面动态数据使用 textContent，日志中的 HTML 不会执行；响应包含 CSP、禁止嵌入和 MIME 检查保护头。
登录表单明确使用 POST，即使 JS 加载失败也不将密码拼进 URL。
前端 JS 语法验收：`node --check backend/static/js/app.js`；Node 只用于开发检查，不是应用运行依赖。

主机指标按 15 秒刷新；历史曲线默认最近 120 条。Kubernetes 资源采用只读接口，Namespace 可筛选。
Events 按时间倒序，页面最多展示 200 条，明确显示截断和总数。Pod 日志最多 200 行 / 32 KiB，可选择容器和上次退出实例。
