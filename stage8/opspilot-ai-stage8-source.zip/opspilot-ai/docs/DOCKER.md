# 独立 Docker Engine 模块

2026-11-06 已接入 node02 上的专用 Docker Engine 29.9.3，通过 HTTPS 双向 TLS 访问，配置位于忽略的 .env。
历史阶段 6 的未配置分支仍保留；当前实际容器列表、日志与 AI 诊断成功。

## 当前测试环境

服务名 opspilot-docker；根目录 /opt/opspilot-docker，运行目录 /run/opspilot-docker，独立内置 containerd，不连接 /run/containerd/containerd.sock。
bridge=none，iptables/ip6tables/ip-forward/ip-masq=false；使用独立 vfs 数据存储，未替换集群的运行时二进制。
HTTPS 仅绑定 node02 内网地址 2377，要求客户端证书。实测不提供客户端证书被 TLS 拒绝。私钥仅在远端受限目录及本机忽略的 work/docker-tls 保存。
证书有效期 30 天，后续需要轮换；这是验收用静态二进制安装，不具有自动安全更新，不作为生产部署方案。
2026-11-07 已执行 `systemctl enable opspilot-docker`，复验为 enabled/active、项目 Docker 状态接口 200、Kubernetes Node 仍 Ready。该引擎使用独立数据与运行目录，关闭桥接、iptables 与 IP 转发，双向 TLS 保持开启。节点重启后由 systemd 自动启动；如需临时停止，执行 `systemctl stop opspilot-docker`。
保留一个已退出的 opspilot-missing-file 测试容器供演示，无自动重启，无网络，32 MiB 内存、0.25 CPU、16 PID、只读根文件系统、非 root、丢弃全部 capability。
镜像从本机 /usr/bin/cat 及运行库构建，访问不存在的文件真实返回退出码 1；没有通过手工日志或伪造 ExitCode 模拟成功。
管理启停开关仍关闭。现有 Kubernetes containerd PID=890，kubelet/Agent 在部署后仍 active；master API Server 另有反复重启问题，见阶段 7 报告。

官方依据：https://docs.docker.com/engine/install/binaries/ 和 https://docs.docker.com/reference/cli/dockerd/ 。
下载使用官方 HTTPS 且保留 TLS 验证；本机归档 SHA256：3fb5d1f13014c18cc54945bc177c58a9056a482dada031e17d12cf2e6922c973（本地校验值，不声称是官方签名）。

## 数据流与文件

浏览器 → JWT 认证和权限校验 → Flask API → Docker SDK → 独立 Engine。

- backend/integrations/docker_client.py：明确配置连接目标，只允许本地 unix/npipe 或带客户端证书的 HTTPS，超时 10 秒。
- backend/services/docker_service.py：容器摘要、日志读取和受控启停。
- backend/api/docker.py：API、错误分类、管理员校验、审计。
- backend/static/js/docker.js：待接入状态、容器、镜像和日志页面；只为管理员显示已授权容器的操作按钮。
- tests/test_docker.py：使用明确的 Mock 测试边界，不代替真实 Engine 验收。

依赖 docker 7.2.0 是 Docker SDK；Windows 自动安装的 pywin32 支持本机命名管道连接。

## 配置

本地 Engine 可设置 DOCKER_HOST=npipe:////./pipe/docker_engine（Windows）或 unix:///var/run/docker.sock（Linux）。
远程连接必须设置 HTTPS 地址及 DOCKER_CA_FILE、DOCKER_CERT_FILE、DOCKER_KEY_FILE；不支持明文 TCP。
配置只由部署者在 .env 中提供，HTTP 请求无法指定任意 Docker 目标。
默认 DOCKER_ACTIONS_ENABLED=false。不要将 Docker Socket 或未认证 TCP API 暴露到网络。

## 接口

- GET /api/v1/docker/status
- GET /api/v1/docker/containers：最多 200 个容器。
- GET /api/v1/docker/images：最多返回 200 个镜像，超出明确标记 truncated。
- GET /api/v1/docker/containers/<id>/logs：最近 200 行，最多 32 KiB，关闭读取流。
- POST /api/v1/docker/containers/<完整ID>/start 或 stop。

启停要求：管理员、开启配置开关、请求 JSON 的 confirm_container_id 与路径完整 ID 相同、容器标签 opspilot.managed=true。
先提交操作意图审计，再调用 Engine；最终查询/操作结果另行记录。失败只返回安全错误，不返回 SDK 原始异常内容。
界面请求会进行容器确认。当前没有实际执行任何 Docker 启停操作。

## 验收

```powershell
.\.venv\Scripts\python.exe -m pytest tests/test_docker.py -q
.\.venv\Scripts\python.exe -m flask --app backend.app:create_app run --host 127.0.0.1 --port 5000
```

当前全部项目测试为 55 passed；实际状态接口 503 not_configured、未认证请求 401、真实 MySQL 中存在对应审计。
受控启停、容器列表及日志成功路径中的模拟只用于单元测试。真实 Engine 接入后还需用专用测试容器补测成功查询、日志和启停。
