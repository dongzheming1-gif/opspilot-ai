# OpsPilot AI 制作流程、整体架构与求职理解

更新日期：2026-11-07。本指南适合学习实现逻辑、梳理项目讲解和准备简历/面试。测试数量和集群对象数是验收时快照，不能包装成持续 SLA 或生产规模指标。

## 1. 项目是什么

OpsPilot AI 是面向学习和演示的云原生运维平台。它用自建 Linux Agent 收集主机指标，用 Kubernetes 只读 API 查看集群，用独立 Docker Engine 展示容器状态，再把观测结果放入告警、巡检和 AI 诊断流程。

它不是“接上大模型就完成”的聊天机器人：AI 输入来自实际采集的指标/资源上下文；系统保存请求、证据和诊断结果；RBAC、权限校验和人工操作边界仍由普通后端代码实施。

项目选择**模块化单体**：一个 Flask 应用内部按 API、服务、集成、数据模型分层，而不是拆成多个网络微服务。这样对个人项目更易运行和排错，同时保留了清楚的边界。

## 2. 整体架构图

```mermaid
flowchart LR
  Browser[浏览器 Bootstrap / Chart.js]
  subgraph Windows[Windows 学习开发环境]
    FlaskDev[Flask 开发服务器 :5000]
    MySQLDev[(项目 MySQL :3307)]
  end
  subgraph Compose[独立 Compose 验收部署]
    Nginx[Nginx TLS :5443 / loopback :8080]
    Waitress[Flask API + Waitress]
    MySQLC[(Compose MySQL)]
    RedisC[(Compose Redis)]
    Inspector[只读巡检进程]
    Nginx --> Waitress
    Waitress --> MySQLC
    Waitress --> RedisC
    Inspector --> MySQLC
  end
  Agents[三台 Rocky Linux Agent]
  Master[Kubernetes API Server]
  Engine[独立 Docker Engine / node02]
  DeepSeek[DeepSeek API]
  Browser --> FlaskDev
  Browser --> Nginx
  Agents -->|HTTPS + 每机独立 Token| FlaskDev
  Agents -->|HTTPS| Nginx
  FlaskDev --> MySQLDev
  FlaskDev -->|只读 ServiceAccount Token| Master
  Waitress -->|只读 ServiceAccount Token| Master
  FlaskDev -->|mTLS| Engine
  Waitress -->|mTLS| Engine
  FlaskDev -->|筛选后的证据| DeepSeek
  Waitress -->|筛选后的证据| DeepSeek
```

图中两条运行路径代表不同部署方式，不能把它们误认为同时共享一个数据库：

- **Windows 本机开发：**浏览器 → Flask `127.0.0.1:5000` → 本机项目 MySQL `127.0.0.1:3307`、master 上 TLS Redis、Kubernetes API、node02 Docker Engine。三台 Linux Agent 通过 HTTPS 上报到 Windows VMnet8 接收端 `192.168.209.1:5443`。
- **Compose 隔离验收：**浏览器/Agent → Nginx TLS → Waitress/Flask；MySQL、Redis、迁移和巡检容器在 Compose 网络中。验收 MySQL 与 Windows MySQL 不共享数据。

## 3. 每个请求如何走过系统

### 3.1 指标采集到监控曲线

```text
Linux 内核统计
  → psutil 采样
  → Agent 配置身份与 Token
  → HTTPS POST /api/v1/metrics
  → 服务端认证 / 字段与时间校验
  → MySQL Metric + Server 心跳
  → 默认阈值告警评估
  → 前端 Fetch 定时读取并用 Chart.js 绘图
```

Agent 每约 15 秒采一次样。它只有采集和上报能力，没有远程 Shell 执行接口。三台机器各有独立 agent_id/Token；服务端根据认证身份确定主机，拒绝伪造或超范围的数值。指标的 `(server_id, collected_at)` 有唯一约束，重试同一个样本不会造成重复记录。网络字节是累计计数，图表若想表示速率，要用相邻样本差除以时间差，不能直接把累计值称为带宽。

MySQL 才是指标、诊断、告警、巡检和审计的持久化来源。Redis 负责短期缓存和登录限流等易失状态；Redis 失效时不能把未落库数据伪称持久化。指标默认保留 7 天，清理任务分批删除。

### 3.2 Kubernetes 资源查询

```text
浏览器带用户 JWT
  → Flask API 验用户与角色
  → kubernetes_client 加载独立只读 kubeconfig
  → HTTPS / TLS CA 验证
  → API Server 执行 RBAC
  → Python Client 分页读取真实对象
  → 输出受限列表/异常摘要并写审计
```

项目使用 `opspilot-reader` ServiceAccount，只读 Node、Pod、Deployment、Service、Namespace、Events 和日志；不能读 Secret，不能修改 Pod/Deployment。列表带页数、时间和数量上限；日志限制 200 行/32 KiB。上游 401 表示 Token 无效/到期，403 表示身份缺少权限；两者不应被翻译成“用户应用登录失败”。

Kubernetes 的实际运行时是 containerd。系统另接 node02 的独立 Docker Engine，避免把 Kubernetes 节点运行时误当作普通 Docker 管理目标。

### 3.3 AI 诊断

```text
操作者选择主机 / Pod / Node / 独立 Docker 容器
  → 后端按资源类型读取最新状态
  → 生成白名单上下文与本地证据编号
  → HTTPS 调用 DeepSeek，要求结构化 JSON
  → 后端校验字段、类型、长度和证据引用
  → 保存 Diagnosis 与审计
  → 页面把事实证据和可能原因分开显示
```

主机诊断只用最新指标；Pod/Node 诊断读取只读状态、有限 Events 和一个容器的有限日志。原始日志文本、Token、密码、环境变量不会发送给模型；本地提取固定错误特征计数。模型的 `possible_causes` 仍然只是推测，不会因 JSON 合法就自动成为事实。

AI 不执行 Shell、kubectl、Docker 操作。每用户有每小时限额；失败尝试也计入限额，调用不自动重试，以免重复付费。超时后先查历史，避免重复请求。

### 3.4 告警与只读巡检

新指标写入事务中同步检查 CPU 80%、内存 85%、磁盘 90% 默认阈值；同一资源/规则避免重复活动告警，恢复后自动关闭。人工确认/关闭会记录操作者并写审计；持续故障在人工关闭后有一小时抑制期。

巡检每五分钟核对 Agent 心跳、Node Ready、CrashLoopBackOff、超时 Pending 和最近一小时 Warning Events。巡检只读集群；写入的是本项目的报告/告警，不是 Kubernetes 资源。某次 API 查询失败时报告应为 `partial`，并保留既有集群告警，不用失败结果自动清除真实告警。

### 3.5 Docker 管理

Docker SDK 连接的是 node02 上独立 Docker Engine 29.9.3，HTTPS 双向 TLS 绑定内网地址。未提供客户端证书会被拒绝。管理启停默认关闭；即使将来开启，也要求 admin、配置开关、完整容器 ID、明确二次确认和 `opspilot.managed=true` 标签。Kubernetes containerd/socket 不作为 Docker 管理入口。

## 4. 代码目录如何读

```text
agent/                         Linux Agent：配置、采集、重试、上报
backend/app.py                 Flask 应用工厂、蓝图注册、CLI 与健康接口
backend/api/                   HTTP 路由、JWT/角色验证、请求参数和响应
backend/services/              监控、Kubernetes、Docker、AI、巡检等业务规则
backend/integrations/          Kubernetes / Docker / DeepSeek 客户端边界
backend/ai_engine/             Prompt 和模型结构化响应处理
backend/models/                SQLAlchemy 数据表模型
backend/static/js/              浏览器 Fetch 与页面交互
backend/static/vendor/          本地 Bootstrap 和 Chart.js，浏览器无需 CDN
backend/templates/              Jinja2 页面
migrations/                     Alembic/Flask-Migrate 数据库迁移
deploy/kubernetes/              最小只读 RBAC 与 Token 续期 helper
deploy/windows/                 本机服务开机任务和 Token 续期程序
deploy/                         Compose/Nginx 与 Agent/Redis service 配置
tests/                          pytest 单元和边界测试
docs/                           模块说明、验收、用户和架构指南
outputs/                        本机验收报告/源码包；按 .gitignore 排除
work/                           凭据、测试工具、数据库与环境产物；不应发布
```

路由层负责 HTTP 和权限，不应把所有业务塞进 route 函数；`services/` 实现规则；`integrations/` 负责外部系统协议；`models/` 定义持久数据。这样的边界使错误处理和 Mock 测试可定位，也允许把 Flask 本地运行切换到 Waitress/Nginx，而不重写业务逻辑。

核心数据模型：

| 表 | 记什么 | 为什么存在 |
|---|---|---|
| User / RevokedToken | 用户角色、密码哈希、退出 Token 的撤销标识 | 登录认证与退出后失效 |
| Server | Agent 资产和最后心跳 | 把采样关联到具体主机 |
| Metric | CPU、内存、磁盘、网络累计值和采样时间 | 历史曲线、阈值计算 |
| Alert | 规则、对象、状态、创建/恢复和处理用户 | 告警生命周期与去重 |
| Diagnosis | 故障对象、结构化结果和时间 | 可回看的 AI 诊断历史 |
| InspectionRun | `complete/partial` 及巡检 JSON 报告 | 追溯一次检查覆盖情况 |
| AuditLog | 用户、操作、资源、结果、来源 IP、时间 | 重要动作可审计 |

## 5. 项目是怎样分阶段制作的

| 阶段 | 先解决的问题 | 交付和验证 |
|---|---|---|
| 0：骨架和环境 | 项目能否可靠启动、依赖是否隔离 | Python venv、配置、Flask health、错误响应、pytest 基线 |
| 1：Kubernetes 连接 | 真实 API、TLS、权限边界是否正确 | 建立 `opspilot-reader`，验证允许列表、拒绝 Secret/写操作 |
| 2：Linux Agent | 如何安全采集而不提供远程命令 | 三台 Rocky Linux systemd Agent，psutil 真实采样、HTTPS/独立身份 |
| 3：数据库和认证 | 数据如何跨进程/重启保存，谁能登录 | MySQL 3307、TLS Redis、模型、迁移、JWT、撤销与角色 |
| 4：监控 Dashboard | 用户如何看真实主机状态 | Bootstrap、Chart.js、Fetch、15 秒刷新与真实历史曲线 |
| 5：Kubernetes 页面 | 如何把集群只读数据安全呈现 | Node/Pod/Deployment/Service/Namespace/Events、筛选、有限日志 |
| 6：Docker 管理 | Kubernetes 用 containerd，独立 Docker 如何区分 | Docker SDK、远端 mTLS、操作防护和审计；专用 Engine 实测 |
| 7：AI 诊断 | 如何让模型基于证据，而不是自由猜测 | 主机/Pod/Node/Docker 诊断、特征提取、JSON 校验、历史页、限流 |
| 8：告警/巡检/部署 | 如何从观察走向可运营记录 | 生命周期告警、只读巡检、审计、Compose/Nginx/TLS/Waitress |

开发遵循“先一个明确模块、再验收”的节奏：先用 Mock/隔离数据库验证规则边界，再打到真实环境验证实际 API、数据和页面；真实验收不通过时修复后重测，不把测试替身写成真实成功。

## 6. 关键设计为什么这样做

### 为什么选择模块化单体

这是个人学习项目，先保持一个可部署的 Flask 进程，减少服务发现、网络调试和多服务部署成本。API、业务、集成和模型仍独立分层；未来有明确负载/团队边界时再拆，不为了简历关键词一开始堆微服务。

### 为什么 Agent 自己采集，而不是只调用云 API

Linux 节点本地 psutil 能直接读取主机 OS 视角的指标。Agent 有独立身份、TLS 和有限重试，无接收服务端命令的能力；指标经过校验并由 MySQL 保存，前端才能画真实曲线。

### 为什么 Kubernetes 使用只读 Token

监控和诊断的需求是观察，不是集群管理员控制。单独 ServiceAccount + RBAC 把损害范围限制在列出规定资源；TLS 校验证书证明 API Server 身份；Token 证明客户端身份；RBAC 决定它能做什么。查询 Secret 应返回 403。

### 为什么独立 Docker Engine 与 Kubernetes 分开

该集群运行时为 containerd。Docker SDK 的目标是单独 Engine；混淆目标会导致“看起来有 Docker 操作，实际上管理了错误运行时”。远程 Engine 使用双向 TLS，受控启停还有角色、标签和确认门槛。

### 为什么模型不直接修复

模型输出可能包含错误假设或不安全建议。先将“观察到的事实”和“模型推测”分开展示，运维人员核实后自行决定，避免 prompt injection 或错误诊断直接修改生产资源。

### 为什么保留 `partial`

如果控制平面暂时不通，巡检只能说明“某些检查没有完成”，不能把空结果误当成无异常。把不确定性显式写入报告，是避免误报“集群健康”的可靠性设计。

## 7. 真实验收与可证明的结果

- 最新完整 Python 测试：**101 passed**；Python `compileall` 和 `pip check` 通过。
- Kubernetes 实测快照：3 Node Ready、24 Pod；重启四台 VM 后再次查询仍通过。
- 三台 Agent 在重启后在线；本机 Flask、MySQL、Kubernetes 与独立 Docker 检查返回成功。
- 独立 Docker 测试用隔离容器真实得到退出码 1 与错误特征；不是手工伪造日志。
- AI 实测覆盖主机、CrashLoopBackOff、隔离文件系统 93.6% 占用、Docker 容器退出场景；不代表每种生产故障或自动修复都已验证。
- Compose 在独立 CentOS 7 VM 实际构建并启动 MySQL/Redis/应用/巡检/Nginx，验证 TLS、Agent 上报、告警处理、Kubernetes 查询、审计和数据库重启持久化。
- Compose 为隔离验收配置，触发告警的阈值曾临时设置为 0%；未拿该人工设置伪装生产默认阈值。
- Dify 服务容器已移除，但配置、数据、镜像和代码目录保留。验收 Compose 的 6 个容器停止，MySQL/Redis 数据卷保留。

## 8. 仍要诚实说明的限制

1. Windows 整机重启后自动恢复还未验收。Windows 登录任务启动本机服务，但不会启动 VMware VM；四台 VM 的关机/启动已验收。
2. VMware 的 `50` 内存策略下第四台 VM 启动失败；当前使用允许更多交换的 `25`，可能变慢。当前 VM 内存配置需按实际资源管理，不能宣称硬件资源充足。
3. CentOS Linux 7 已停止维护，不应作为长期生产底座。
4. Kubernetes 原 `mysql-1` 复制故障和 WordPress 历史数据缺失是集群业务遗留问题，不是 OpsPilot 已修复的内容。隔离副本重建试验成功，不代表原副本已经修复。
5. DeepSeek Key 曾出现在聊天中，需在供应商控制台撤销并更换；GitHub 上传按用户计划暂缓。当前本地源码包排除了 `.env`/Token/私钥。
6. Dify 容器被删除，但其数据和代码仍留在 CentOS；这不是完整擦盘卸载。

## 9. 简历怎么写才准确

### 一句话项目介绍

> 独立设计并实现 OpsPilot AI 云原生运维平台，使用 Python/Flask 和 Linux Agent 汇集主机指标，结合 Kubernetes 只读观测、独立 Docker Engine 管理、证据约束的 AI 故障诊断、告警巡检及审计，并在 VMware 多节点环境完成真实 API 与 Compose 部署验收。

### 简历项目要点（按你实际负责内容调整）

- **监控链路：**基于 psutil 编写 Linux Agent，以每机独立身份通过 HTTPS 上报 CPU/内存/磁盘/网络和心跳；Flask 校验后持久化 MySQL，构建实时主机列表和历史曲线。
- **云原生观测：**基于 Kubernetes Python Client 与最小只读 RBAC 查询 3 节点集群中的 Pod、Deployment、Service、Namespace 和 Events；实现 Namespace 过滤、异常识别、有限日志读取、分页预算及错误分类。
- **安全与运维控制：**实现用户 JWT、admin/operator/viewer 授权、退出 Token 撤销、关键操作审计；独立 Docker Engine 通过双向 TLS 接入，管理动作默认关闭并限制标签与完整容器 ID。
- **AI 故障分析：**将指标/状态/固定日志特征整理为白名单上下文，调用 DeepSeek 后进行 JSON、字段和证据引用校验，事实与推测分开展示；加入调用限额，不提供自动命令执行。
- **可靠性和部署：**实现 MySQL 告警生命周期、只读集群巡检、`partial` 状态与 Compose/Nginx/Waitress 部署；真实环境验收覆盖 3 Node/24 Pod 与四台 VM 重启后的服务恢复，测试套件 101 项通过。

简历应把“我写了什么”“我真实验收了什么”“我没有做什么”说清楚。不要写成生产级 HA、自动修复、集群全量自动恢复、100% 无故障或 GitHub 已发布；这些都没有对应事实支撑。

## 10. 面试时可以这样讲（约 90 秒）

> 我做的 OpsPilot AI 是一个模块化 Flask 运维平台，不是单纯的 AI 聊天页。数据入口有两类：Linux Agent 用 psutil 采样后通过 HTTPS 上报；Kubernetes 由 Flask 使用单独的只读 ServiceAccount 查询，和集群的 containerd 保持边界。指标和告警等写 MySQL，Redis 只做缓存和限流。页面用 Bootstrap、Fetch 和 Chart.js 展示真实状态。AI 诊断先做白名单上下文和日志特征提取，再校验模型 JSON，把事实证据和推测原因分开展示，不允许模型执行命令。项目还包含独立 Docker Engine 的双向 TLS、告警巡检和审计。我用三节点 Kubernetes 和独立 Compose VM 做过真实验收，当前测试套件 101 项通过；也记录了 VMware 内存策略、CentOS 7 已停止维护和原业务数据库复制问题等限制，没有把这些说成已修复。

## 11. 常见追问练习

### Q1：为什么不直接用 Prometheus/Grafana？

**答题思路：**正式手册限定用 Agent + Flask 完成端到端学习，所以实现了采集、认证、落库和展示链路。Prometheus/Grafana 是可行的生产方案，但没有冒称本项目已集成；后续可作为指标规模增长后的扩展。

### Q2：怎样防止项目读取 Kubernetes Secret？

**答题思路：**运行凭据来自独立 ServiceAccount，只授予特定资源 list/watch/get 所需权限；程序也拒绝关闭 TLS 验证或运行 exec 插件。实测 Secret 返回 403。不能只依赖前端隐藏按钮，服务端 RBAC 才是边界。

### Q3：AI 输出错了怎么办？

**答题思路：**后端检查结构和证据引用，页面区分事实与推测；日志用有限特征计数减少敏感信息发送；模型建议不自动执行。验证正确性仍由值班人员结合 Kubernetes/主机真实状态完成。

### Q4：为什么巡检失败不能关闭旧告警？

**答题思路：**API 超时只能表示未知，不代表异常消失。报告标为 `partial`、保留已有活动告警，能避免一次控制平面故障把真实告警误清除。

### Q5：事务和唯一索引解决什么问题？

**答题思路：**网络重试可能重复送同一指标，`server_id + collected_at` 唯一约束负责去重；指标写入和阈值评估放在同一事务，避免指标已保存而告警判断被意外丢失的状态不一致。

### Q6：502 和 403 有什么区别？

**答题思路：**项目中的 upstream 401 表示发给 Kubernetes 的凭据无效/过期；403 表示已识别身份但 RBAC 不允许该动作。两者都不等于用户的 OpsPilot JWT 失效。Secret 403 是预期拒绝。

### Q7：自动续期安全吗？

**答题思路：**Windows 计划任务只运行本地脚本；SSH 私钥 ACL 受限，master 专用账户被强制到固定命令，sudo 仅允许签发指定只读 ServiceAccount Token。新 Token 先做真实 Node 查询和 Secret 403 验证，再原子替换 kubeconfig。它仍依赖 Windows 用户配置文件和 master 在线；不是凭空自动化，也不是外部付费续期产品。

## 12. 建议学习顺序

1. 从 `agent/collector.py` 读采集，再看 `agent/reporter.py` 如何发 HTTP。
2. 跟踪 `backend/api/metrics.py`、`backend/services/monitoring_service.py`、`backend/models/metric.py`，看一条样本如何认证、持久化和评估阈值。
3. 看 `backend/api/auth.py`、模型 `User` 与 `RevokedToken`，理解密码哈希、JWT 和角色。
4. 看 `backend/integrations/kubernetes_client.py`、`backend/services/k8s_service.py` 和 RBAC YAML，理解 TLS、ServiceAccount、分页和错误。
5. 看 `backend/services/diagnosis_service.py`、`cluster_diagnosis.py`、`backend/ai_engine/`，理解证据筛选与模型输出验证。
6. 最后看 alerts/inspection/audit API、`compose.yaml` 和 `docs/STAGE8.md`，理解运维闭环及部署。

配套资料：[用户手册](BEGINNER_USER_GUIDE.md)、[正式开发规范](../PROJECT_DEVELOPMENT_MANUAL.md)、[架构图](ARCHITECTURE.md)、[Agent](AGENT.md)、[数据库](DATABASE.md)、[Kubernetes](KUBERNETES.md)、[AI 诊断](AI_DIAGNOSIS.md)、[Docker](DOCKER.md)、[告警与巡检](STAGE8.md)、[完整进度](DEVELOPMENT_PROGRESS.md)。
