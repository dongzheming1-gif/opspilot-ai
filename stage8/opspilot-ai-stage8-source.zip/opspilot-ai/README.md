# OpsPilot AI

一个用于学习云原生运维的 Flask 平台：三台 Linux Agent 的真实指标、Kubernetes 只读查询、独立 Docker 管理、基于真实证据的 AI 诊断，以及告警、巡检和审计。正式需求见 `PROJECT_DEVELOPMENT_MANUAL.md`，架构见 `docs/ARCHITECTURE.md`。

初学者日常操作见 [`docs/BEGINNER_USER_GUIDE.md`](docs/BEGINNER_USER_GUIDE.md)；项目制作阶段、代码结构、数据流和简历/面试讲解见 [`docs/PROJECT_WORKFLOW_AND_ARCHITECTURE_GUIDE.md`](docs/PROJECT_WORKFLOW_AND_ARCHITECTURE_GUIDE.md)。

## 从空环境部署（Linux + Docker Compose）

1. 准备 Docker Engine、Compose 插件和可达的 Kubernetes API，若使用 AI 还需 DeepSeek Key。Compose 构建需兼容的 Buildx；本次 Compose 5.1.4 要求 Buildx 0.17 或更新，现有 0.14.1 无法执行 `compose build`。至少为数据库和 Redis 准备持久化磁盘。不要把此项目的 Compose MySQL 当作原 Kubernetes `mysql-1` 的恢复目标。
2. 在项目根目录准备配置和私有目录：

   ```bash
   cp .env.compose.example .env.compose
   mkdir -p deploy/secrets/docker deploy/certs
   chmod 600 .env.compose
   ```

   在 `.env.compose` 中填入长随机 `SECRET_KEY`、`MYSQL_ROOT_PASSWORD`、`MYSQL_PASSWORD`、`REDIS_PASSWORD` 和每台 Agent 的 `AGENT_TOKENS` JSON。两个服务密码使用 URL 安全字符，因为它们会进入数据库与 Redis 连接 URL。需要 AI 时填 `DEEPSEEK_API_KEY`；告警阈值、心跳超时、Pending 超时、诊断配额和指标保留天数也可在此调整。`.env.compose` 已被 Git 忽略。
3. 把专用 **只读** Kubernetes kubeconfig 放在 `deploy/secrets/readonly-kubeconfig`。该身份的 RBAC 见 `deploy/kubernetes/readonly-rbac.yaml` 和 `docs/KUBERNETES.md`。将生产 TLS 证书与私钥分别放在 `deploy/certs/server.crt` 和 `server.key`，证书的 SAN 必须匹配 Agent 和浏览器访问的地址。若连接独立 Docker Engine，把客户端 CA、证书、私钥放在 `deploy/secrets/docker/ca.pem`、`cert.pem`、`key.pem`，并设置 `DOCKER_HOST`。若暂不使用 Docker 连接，目录仍应存在，`DOCKER_HOST` 留空。
4. 让容器用户 UID 10001 可读取 kubeconfig、客户端证书和密钥；私钥不要设为全局可读。限制 `.env.compose` 和 `deploy/secrets/` 的本机权限。Agent 必须信任 Nginx 所用证书或其 CA。Compose 对外开放 HTTPS 5443（用于 Agent）和仅回环地址 HTTP 8080（用于本机页面）；MySQL、Redis、应用端口没有对外映射。如果同机已有 Agent 接收器占用 5443，先完成切换计划并释放该端口。
5. 启动并检查：

   ```bash
   docker compose --env-file .env.compose up -d --build
   docker compose --env-file .env.compose ps
   curl -fsS http://127.0.0.1:8080/api/v1/health
   docker compose --env-file .env.compose logs --tail=50 app inspector nginx
   ```

   `health` 只验证应用存活。Compose 的 `migrate` 服务先执行 `flask db upgrade`，成功后应用与每五分钟一次的巡检进程才启动。首次运行生成空数据库，不会自动导入本机开发数据。

   如果旧主机的 Buildx 版本不足，可参考本次验证使用的兼容构建方式；以下命令采用固定项目名 `opspilot`，镜像标签须与项目名一致：

   ```bash
   DOCKER_BUILDKIT=0 docker build -t opspilot-app .
   docker tag opspilot-app opspilot-migrate
   docker tag opspilot-app opspilot-inspector
   docker compose --env-file .env.compose -p opspilot up -d --no-build --wait
   ```
6. 创建管理员，交互输入至少 12 位的密码，不把密码放在命令行：

   ```bash
   docker compose --env-file .env.compose exec app python -m flask --app backend.app:create_app create-user --username admin --role admin
   ```

   然后访问 `http://127.0.0.1:8080/` 或配置好可信证书后的 `https://<服务器地址>:5443/`。若 Agent 在另一台主机上，必须使用 HTTPS 地址，不能使用仅本机的 8080。
7. 首次验收：登录、主机曲线、Node/Pod、AI 页面、告警、巡检、审计和退出；运行 `docker compose --env-file .env.compose exec app python -m flask --app backend.app:create_app inspect`，再到页面查看该报告。Kubernetes 凭据到期时查询会失败，续期步骤见 `docs/KUBERNETES.md`。

## Windows 本机开发

已有开发环境使用 `.venv`，基础解释器保存在忽略的 `work/python/`。新电脑需要 Python 3.12、MySQL、Redis 和正确的 `.env`。现有本机凭据只在忽略的文件中。

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-lock.txt
.\.venv\Scripts\python.exe -m flask --app backend.app:create_app db upgrade
.\.venv\Scripts\python.exe -m flask --app backend.app:create_app run --host 127.0.0.1 --port 5000
```

打开 `http://127.0.0.1:5000/`。本机 Flask 开发服务与 Compose 部署是两套独立进程；正式部署由 Nginx 与 Waitress 提供服务。Agent、数据库和 Redis 的单独配置分别见 `docs/AGENT.md`、`docs/DATABASE.md`。

### 本机登录后自动启动

当前电脑已为当前 Windows 用户注册 `OpsPilot-AI-Start` 计划任务：登录 Windows 后依次启动项目 MySQL 3307、网页 5000 和 Agent 接收端 5443。它会识别已运行的项目进程、等待 VMnet8 地址，并将状态写入 `work/startup.log`。虚拟机需另外在 VMware 中启动；master 的 Redis、Kubernetes 等服务就绪后，登录和集群查询才能正常使用。网络地址变化、证书到期或凭据到期时仍需维护。此任务在用户登录后运行，不会启动 VMware 虚拟机。

手动检查或重新运行：

```powershell
Get-ScheduledTaskInfo -TaskName OpsPilot-AI-Start
powershell.exe -NoProfile -ExecutionPolicy Bypass -File deploy/windows/start-opspilot.ps1
Get-Content work/startup.log -Tail 20
```

重新安装到另一台 Windows 电脑前，需调整脚本中的 MySQL 安装路径、数据目录和 VMnet8 IP，并配置 Python 虚拟环境及证书；注册命令为 `powershell.exe -NoProfile -ExecutionPolicy Bypass -File deploy/windows/install-autostart.ps1`。当前设置已通过计划任务手动触发及网页和接收端停止后的恢复测试；完整 Windows 重启后自动登录流程尚未实测。

### Kubernetes 只读 Token 自动续期

当前 Windows 开发环境已注册 `OpsPilot-Kubernetes-Token-Renewal` 计划任务，每周一 09:00 和用户登录时检查，只在 Token 剩余不超过 21 天时轮换。任务通过受限 SSH key 在 master 上请求 30 天只读 Token，并在验证 Node 可读、Secret 仍被拒绝后原子替换本机 kubeconfig。该功能只使用本机 Task Scheduler、OpenSSH 和现有 Kubernetes API，不需购买续期服务；master VM 必须已启动且可达。查看任务状态、手动补跑和故障处理见 `docs/KUBERNETES.md`。

## 测试

```powershell
.\.venv\Scripts\python.exe -m compileall -q backend tests
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m pip check
node --check backend/static/js/app.js
node --check backend/static/js/stage8.js
```

测试用隔离 SQLite 和模拟 Kubernetes 响应检查规则及权限；真实环境验收必须另外执行。阶段 8 的功能、边界和实际验证记录见 `docs/STAGE8.md` 与 `docs/DEVELOPMENT_PROGRESS.md`。

## 安全与已知环境限制

不要提交 `.env`、`.env.compose`、Token、kubeconfig、证书私钥、数据库备份或真实日志。Docker Engine 仅使用双向 TLS，不公开无认证 TCP 或 Docker Socket。AI 诊断只发送受限的指标/日志特征，不允许执行命令。

Windows 本机没有 Docker 守护进程；2026-11-07 已在独立 CentOS 虚拟机实际完成 Compose 构建、启动、HTTPS、告警、巡检和数据库持久化验收。该次未在 Compose 内重新调用付费 AI，也未连接独立 Docker 管理引擎，相关功能此前在本机真实环境验证。CentOS Linux 7 已于 2024-06-30 [停止维护](https://www.centos.org/centos-linux/)，本次仅用于学习验收，长期部署应使用受维护的系统。原 Kubernetes MySQL 副本复制仍需修复；WordPress 旧内容无可用备份，这两项不属于本平台应用部署。
