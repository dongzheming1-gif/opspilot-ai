#!/usr/bin/env bash
set -euo pipefail

if [[ -n "${SSH_ORIGINAL_COMMAND:-}" || $# -ne 0 ]]; then
  echo 'Only the fixed token renewal command is allowed.' >&2
  exit 126
fi

exec /usr/bin/env KUBECONFIG=/etc/kubernetes/admin.conf \
  /usr/bin/kubectl -n opspilot-system create token opspilot-reader --duration=720h
