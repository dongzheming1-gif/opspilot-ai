#!/usr/bin/env bash
set -euo pipefail

if [[ -n "${SSH_ORIGINAL_COMMAND:-}" || $# -ne 0 ]]; then
  echo 'Only the fixed token renewal command is allowed.' >&2
  exit 126
fi

exec /usr/bin/sudo -n /usr/local/sbin/opspilot-issue-reader-token
