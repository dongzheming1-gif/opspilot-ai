#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo 'Run this installer as root on the Kubernetes control plane.' >&2
  exit 1
fi
if [[ $# -ne 1 ]]; then
  echo 'Usage: install-token-renewer.sh "ssh-ed25519 PUBLIC_KEY"' >&2
  exit 2
fi
if [[ -f "$1" ]]; then
  read -r key_type key_data key_comment < "$1"
else
  read -r key_type key_data key_comment <<< "$1"
fi
if [[ "$key_type" != ssh-ed25519 || ! "$key_data" =~ ^[A-Za-z0-9+/]+={0,2}$ ]]; then
  echo 'Expected one valid Ed25519 public key.' >&2
  exit 2
fi
if [[ ! -x /usr/bin/kubectl || ! -r /etc/kubernetes/admin.conf ]]; then
  echo 'Kubernetes admin client is unavailable.' >&2
  exit 1
fi
/usr/bin/env KUBECONFIG=/etc/kubernetes/admin.conf /usr/bin/kubectl \
  -n opspilot-system get serviceaccount opspilot-reader >/dev/null

if ! id opspilot-renewer >/dev/null 2>&1; then
  useradd --system --create-home --home-dir /var/lib/opspilot-renewer \
    --shell /bin/bash opspilot-renewer
fi
if [[ "$(getent passwd opspilot-renewer | cut -d: -f6)" != /var/lib/opspilot-renewer ]]; then
  echo 'Existing opspilot-renewer account has an unexpected home directory.' >&2
  exit 1
fi
passwd -l opspilot-renewer >/dev/null 2>&1 || true

install -o root -g root -m 0755 "$(dirname "$0")/opspilot-issue-reader-token.sh" \
  /usr/local/sbin/opspilot-issue-reader-token
install -o root -g root -m 0755 "$(dirname "$0")/opspilot-token-renewer-wrapper.sh" \
  /usr/local/bin/opspilot-token-renewer-wrapper
cat > /etc/sudoers.d/opspilot-token-renewer <<'SUDOERS'
Defaults:opspilot-renewer !requiretty
opspilot-renewer ALL=(root) NOPASSWD: /usr/local/sbin/opspilot-issue-reader-token ""
SUDOERS
chown root:root /etc/sudoers.d/opspilot-token-renewer
chmod 0440 /etc/sudoers.d/opspilot-token-renewer
/usr/sbin/visudo -cf /etc/sudoers.d/opspilot-token-renewer >/dev/null

ssh_dir=/var/lib/opspilot-renewer/.ssh
install -d -o opspilot-renewer -g opspilot-renewer -m 0700 "$ssh_dir"
auth_file="$ssh_dir/authorized_keys"
touch "$auth_file"
chown opspilot-renewer:opspilot-renewer "$auth_file"
chmod 0600 "$auth_file"
key_line="command=\"/usr/local/bin/opspilot-token-renewer-wrapper\",restrict $key_type $key_data opspilot-token-renewal"
tmp_file=$(mktemp "$ssh_dir/authorized_keys.XXXXXX")
trap 'rm -f "$tmp_file"' EXIT
grep -v 'opspilot-token-renewal$' "$auth_file" > "$tmp_file" || true
printf '%s\n' "$key_line" >> "$tmp_file"
chown opspilot-renewer:opspilot-renewer "$tmp_file"
chmod 0600 "$tmp_file"
mv -f "$tmp_file" "$auth_file"
trap - EXIT

# Verify the account can obtain only the intended read-only ServiceAccount token;
# suppress the credential itself from this setup command's output.
runuser -u opspilot-renewer -- sudo -n /usr/local/sbin/opspilot-issue-reader-token >/dev/null
echo 'Restricted token renewal account installed and validated.'
