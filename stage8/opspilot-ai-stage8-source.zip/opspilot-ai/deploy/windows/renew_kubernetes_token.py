"""Renew OpsPilot's read-only Kubernetes token through a forced SSH command."""
from __future__ import annotations

import argparse
import base64
import json
import os
import re
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

TOKEN_DIR = ROOT / "work" / "token-renewal"
KUBECONFIG = ROOT / "work" / "readonly-kubeconfig.json"
SSH = Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32" / "OpenSSH" / "ssh.exe"
MASTER = "opspilot-renewer@192.168.209.144"
KEY_PATH = TOKEN_DIR / "id_ed25519"
KNOWN_HOSTS = TOKEN_DIR / "known_hosts"
LOG_PATH = TOKEN_DIR / "renewal.log"
RENEW_BEFORE = timedelta(days=21)


def claims(token: str) -> dict:
    if not re.fullmatch(r"[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+", token):
        raise ValueError("token_format")
    segment = token.split(".")[1]
    segment += "=" * (-len(segment) % 4)
    value = json.loads(base64.urlsafe_b64decode(segment))
    if value.get("sub") != "system:serviceaccount:opspilot-system:opspilot-reader":
        raise ValueError("token_subject")
    issued = datetime.fromtimestamp(value["iat"], timezone.utc)
    expiry = datetime.fromtimestamp(value["exp"], timezone.utc)
    lifetime = expiry - issued
    if not timedelta(days=27) <= lifetime <= timedelta(days=31):
        raise ValueError("token_lifetime")
    if expiry <= datetime.now(timezone.utc) + timedelta(days=20):
        raise ValueError("token_expiry")
    return {"issued": issued, "expiry": expiry}


def write_log(message: str) -> None:
    TOKEN_DIR.mkdir(parents=True, exist_ok=True)
    with LOG_PATH.open("a", encoding="utf-8") as output:
        output.write(f"{datetime.now(timezone.utc).isoformat()} {message}\n")


def run(force: bool = False) -> int:
    stage = "initialization"
    candidate: Path | None = None
    try:
        if not all(path.is_file() for path in (KUBECONFIG, KEY_PATH, KNOWN_HOSTS, SSH)):
            raise FileNotFoundError("renewal_prerequisite")
        config = json.loads(KUBECONFIG.read_text(encoding="utf-8"))
        users = config.get("users", [])
        if len(users) != 1 or users[0].get("name") != "opspilot-reader":
            raise ValueError("unexpected_kubeconfig_identity")
        old_token = users[0].get("user", {}).get("token", "")
        old_claims = claims(old_token)
        if not force and old_claims["expiry"] > datetime.now(timezone.utc) + RENEW_BEFORE:
            write_log("status=not_due")
            return 0

        stage = "ssh_request"
        result = subprocess.run(
            [str(SSH), "-i", str(KEY_PATH), "-o", "IdentitiesOnly=yes",
             "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
             "-o", f"UserKnownHostsFile={KNOWN_HOSTS}", "-o", "ConnectTimeout=15",
             "-o", "ClearAllForwardings=yes", MASTER],
            cwd=ROOT, stdin=subprocess.DEVNULL, capture_output=True, text=True,
            timeout=45, check=False,
        )
        if result.returncode != 0:
            raise RuntimeError("ssh_request_failed")
        new_token = result.stdout.strip()
        new_claims = claims(new_token)

        stage = "candidate_validation"
        config["users"][0]["user"] = {"token": new_token}
        TOKEN_DIR.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=KUBECONFIG.parent,
            prefix="readonly-kubeconfig.", suffix=".tmp", delete=False,
        ) as output:
            candidate = Path(output.name)
            json.dump(config, output)
            output.flush()
            os.fsync(output.fileno())

        from backend.integrations.kubernetes_client import open_client
        from kubernetes import client
        from kubernetes.client.exceptions import ApiException

        stage = "api_and_rbac_validation"
        with open_client(str(candidate)) as api:
            core = client.CoreV1Api(api)
            nodes = core.list_node(limit=1, _request_timeout=(3, 10)).items
            if not nodes:
                raise RuntimeError("empty_node_response")
            try:
                core.list_namespaced_secret("default", limit=1, _request_timeout=(3, 10))
            except ApiException as error:
                if error.status != 403:
                    raise
            else:
                raise RuntimeError("secret_permission_not_denied")

        stage = "atomic_replace"
        os.replace(candidate, KUBECONFIG)
        candidate = None
        write_log(f"status=renewed expires_utc={new_claims['expiry'].isoformat()} api=ok secrets=forbidden")
        return 0
    except Exception as error:  # Never log subprocess output, exception text, or token material.
        write_log(f"status=failed stage={stage} error_type={type(error).__name__}")
        return 1
    finally:
        if candidate is not None:
            candidate.unlink(missing_ok=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--force", action="store_true", help="renew now for a manual validation")
    sys.exit(run(force=parser.parse_args().force))
