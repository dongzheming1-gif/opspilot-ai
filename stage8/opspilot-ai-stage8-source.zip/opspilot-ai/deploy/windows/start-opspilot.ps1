param([int]$NetworkWaitSeconds = 300)

$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Set-Location -LiteralPath $projectRoot
$workDir = Join-Path $projectRoot 'work'
$python = Join-Path $projectRoot '.venv/Scripts/python.exe'
$mysql = 'C:\mysql-8.0.29-winx64\bin\mysqld.exe'
$log = Join-Path $workDir 'startup.log'
New-Item -ItemType Directory -Force -Path $workDir | Out-Null

function Write-StartupLog([string]$Message) {
    Add-Content -LiteralPath $log -Value ("{0} {1}" -f (Get-Date -Format o), $Message)
}
function Get-Listener([int]$Port) {
    Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue | Select-Object -First 1
}
function Ensure-Service([string]$Name, [int]$Port, [string]$Pattern, [string]$Executable, [string]$Arguments) {
    $listener = Get-Listener $Port
    if ($listener) {
        $process = Get-CimInstance Win32_Process -Filter "ProcessId=$($listener.OwningProcess)"
        if (-not $process.CommandLine -or $process.CommandLine -notmatch $Pattern) {
            throw "Port $Port is already occupied by an unexpected process; refusing to start $Name."
        }
        Write-StartupLog "$Name already listening on $Port"
        return
    }
    $existing = @(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -and $_.CommandLine -match $Pattern })
    if ($existing.Count -gt 0) {
        Write-StartupLog "$Name already has a process; waiting for its listener"
    } else {
        if (-not (Test-Path -LiteralPath $Executable -PathType Leaf)) { throw "$Name executable not found" }
        Start-Process -FilePath $Executable -ArgumentList $Arguments -WorkingDirectory $projectRoot -WindowStyle Hidden `
            -RedirectStandardOutput (Join-Path $workDir "$Name.stdout.log") `
            -RedirectStandardError (Join-Path $workDir "$Name.stderr.log")
        Write-StartupLog "$Name process started"
    }
    for ($i = 0; $i -lt 60; $i++) {
        Start-Sleep -Seconds 1
        $listener = Get-Listener $Port
        if ($listener) {
            $process = Get-CimInstance Win32_Process -Filter "ProcessId=$($listener.OwningProcess)"
            if ($process.CommandLine -and $process.CommandLine -match $Pattern) {
                Write-StartupLog "$Name listening on $Port"
                return
            }
            throw "Unexpected process occupied port $Port while starting $Name."
        }
    }
    throw "$Name did not start listening on $Port within 60 seconds."
}

try {
    $dataDir = (Join-Path $workDir 'mysql-data').Replace('\', '/')
    if (-not (Test-Path -LiteralPath (Join-Path $dataDir 'mysql') -PathType Container)) {
        throw 'Existing MySQL data directory is missing; initialization is not performed.'
    }
    Ensure-Service 'mysql3307' 3307 'mysqld\.exe.*work[\\/]mysql-data.*--port=3307' $mysql "--no-defaults --basedir=C:/mysql-8.0.29-winx64 --datadir=`"$dataDir`" --bind-address=127.0.0.1 --port=3307 --mysqlx=OFF --console"
    Ensure-Service 'web5000' 5000 'flask.*backend\.app:create_app.*--port 5000' $python '-m flask --app backend.app:create_app run --host 127.0.0.1 --port 5000'

    $deadline = (Get-Date).AddSeconds($NetworkWaitSeconds)
    while (-not (Get-NetIPAddress -AddressFamily IPv4 -IPAddress '192.168.209.1' -ErrorAction SilentlyContinue)) {
        if ((Get-Date) -ge $deadline) { throw 'VMnet8 address 192.168.209.1 was not available in time.' }
        Start-Sleep -Seconds 5
    }
    Ensure-Service 'receiver5443' 5443 'flask.*backend\.app:create_app.*--port 5443' $python '-m flask --app backend.app:create_app run --host 192.168.209.1 --port 5443 --cert work/agent-secrets/ca.pem --key work/agent-secrets/server.key'
    $health = Invoke-RestMethod -Uri 'http://127.0.0.1:5000/api/v1/health' -TimeoutSec 5
    if ($health.status -ne 'ok') { throw 'Web liveness check failed.' }
    Write-StartupLog 'Startup checks passed; liveness does not verify MySQL, Redis, or Kubernetes.'
} catch {
    Write-StartupLog "Startup failed: $($_.Exception.Message)"
    Write-Error $_
    exit 1
}
