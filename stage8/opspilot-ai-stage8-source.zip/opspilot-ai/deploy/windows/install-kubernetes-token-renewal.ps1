$ErrorActionPreference = 'Stop'
$taskName = 'OpsPilot-Kubernetes-Token-Renewal'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$python = Join-Path $projectRoot '.venv/Scripts/python.exe'
$script = Join-Path $PSScriptRoot 'renew_kubernetes_token.py'
$tokenDir = Join-Path $projectRoot 'work/token-renewal'
$identity = "$env:USERDOMAIN\$env:USERNAME"

foreach ($path in @($python, $script, (Join-Path $tokenDir 'id_ed25519'),
                     (Join-Path $tokenDir 'known_hosts'))) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Required renewal file is missing: $path"
    }
}
if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
    throw "Task $taskName already exists; inspect it before replacing it."
}

$action = New-ScheduledTaskAction -Execute $python `
    -Argument "`"$script`"" -WorkingDirectory $projectRoot
$weekly = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday -At '9:00 AM'
$atLogon = New-ScheduledTaskTrigger -AtLogOn -User $identity
$principal = New-ScheduledTaskPrincipal -UserId $identity -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew `
    -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 3) `
    -RestartCount 3 -RestartInterval (New-TimeSpan -Hours 1)
Register-ScheduledTask -TaskName $taskName -Action $action `
    -Trigger @($weekly, $atLogon) -Principal $principal -Settings $settings `
    -Description 'Renew and validate the OpsPilot read-only Kubernetes token before expiry.' | Out-Null
Write-Output "Registered $taskName (weekly and at user logon)."

