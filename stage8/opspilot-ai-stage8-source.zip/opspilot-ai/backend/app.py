"""Application factory and minimal liveness endpoint."""

from flask import Flask, jsonify, request, render_template
import click
from collections import deque
from werkzeug.exceptions import HTTPException

from backend.config import load_config


def create_app(test_config: dict | None = None) -> Flask:
    """Create independent app instances for development and tests."""
    app = Flask(__name__)
    app.config.from_mapping(load_config())
    if test_config is not None:
        app.config.from_mapping(test_config)
    if app.config["TRUST_PROXY_COUNT"]:
        from werkzeug.middleware.proxy_fix import ProxyFix
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=app.config["TRUST_PROXY_COUNT"],
                                x_proto=app.config["TRUST_PROXY_COUNT"])
    from backend.api.metrics import bp as metrics_bp
    app.register_blueprint(metrics_bp)
    app.extensions["metric_spool"] = deque(maxlen=1000)
    from backend.extensions import db, migrate, jwt
    from backend.models import User, RevokedToken, Metric
    from sqlalchemy.exc import SQLAlchemyError
    from redis import Redis
    from redis.exceptions import RedisError
    from datetime import datetime, timezone, timedelta
    from werkzeug.security import generate_password_hash
    if app.config["SQLALCHEMY_DATABASE_URI"]:
        db.init_app(app)
        migrate.init_app(app, db)
    jwt.init_app(app)
    if app.config["REDIS_URL"]:
        cache_options = {}
        if app.config["REDIS_URL"].startswith("rediss://"):
            cache_options = {"ssl_ca_certs":app.config["REDIS_CA_FILE"], "ssl_cert_reqs":"required", "ssl_check_hostname":True}
        app.extensions["redis"] = Redis.from_url(app.config["REDIS_URL"], socket_timeout=3, socket_connect_timeout=3, decode_responses=True, **cache_options)
    from backend.api.auth import bp as auth_bp
    from backend.api.servers import bp as servers_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(servers_bp)
    from backend.api.kubernetes import bp as k8s_bp
    app.register_blueprint(k8s_bp)
    from backend.api.docker import bp as docker_bp
    app.register_blueprint(docker_bp)
    from backend.api.diagnosis import bp as diagnosis_bp
    app.register_blueprint(diagnosis_bp)
    from backend.api.alerts import bp as alerts_bp
    app.register_blueprint(alerts_bp)
    from backend.api.inspection import bp as inspection_bp
    from backend.api.audit_logs import bp as audit_logs_bp
    app.register_blueprint(inspection_bp)
    app.register_blueprint(audit_logs_bp)
    from backend.validation import register_validation
    register_validation(app)

    @app.before_request
    def require_database_for_business_routes():
        if request.path.startswith(("/api/v1/auth/", "/api/v1/servers", "/api/v1/kubernetes", "/api/v1/docker", "/api/v1/diagnosis", "/api/v1/alerts", "/api/v1/inspections", "/api/v1/audit-logs")) and "sqlalchemy" not in app.extensions:
            return jsonify(error="Database not configured"), 503

    @jwt.token_in_blocklist_loader
    def revoked(_header, payload):
        return db.session.get(RevokedToken, payload["jti"]) is not None or db.session.get(User, int(payload["sub"])) is None

    @app.errorhandler(SQLAlchemyError)
    def database_error(_error):
        db.session.rollback()
        app.logger.error("Database operation failed")
        return jsonify(error="Database unavailable"), 503

    @app.errorhandler(RedisError)
    def redis_error(_error):
        return jsonify(error="Cache service unavailable"), 503

    @app.cli.command("create-user")
    @click.option("--username", prompt=True)
    @click.option("--password", prompt=True, hide_input=True, confirmation_prompt=True)
    @click.option("--role", type=click.Choice(["admin", "operator", "viewer"]), default="viewer")
    def create_user(username, password, role):
        """Create a local user; password is never printed or stored in plaintext."""
        if not 1 <= len(username) <= 80 or len(password) < 12:
            raise click.ClickException("Username must be 1-80 characters; password at least 12 characters")
        if db.session.execute(db.select(User.id).filter_by(username=username)).scalar_one_or_none():
            raise click.ClickException("Username already exists")
        db.session.add(User(username=username, password_hash=generate_password_hash(password), role=role))
        db.session.commit()
        click.echo("User created")

    @app.cli.command("prune-metrics")
    def prune_metrics():
        """Delete expired metrics in batches; keep seven days by default."""
        days = app.config["METRIC_RETENTION_DAYS"]
        if days < 1:
            raise click.ClickException("Retention must be at least one day")
        cutoff = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=days)
        total = 0
        while True:
            ids = list(db.session.execute(db.select(Metric.id).where(Metric.collected_at < cutoff).limit(1000)).scalars())
            if not ids:
                break
            db.session.execute(db.delete(Metric).where(Metric.id.in_(ids)))
            db.session.commit()
            total += len(ids)
        click.echo(f"Removed {total} expired metrics")

    @app.cli.command("check-kubernetes")
    def check_kubernetes():
        """Query the real cluster using a dedicated read-only identity."""
        from backend.integrations.kubernetes_client import open_client
        from backend.services.k8s_service import connection_report, ClusterReadLimitError
        from kubernetes.client.exceptions import ApiException
        from urllib3.exceptions import HTTPError
        from kubernetes.config.config_exception import ConfigException
        try:
            with open_client(app.config["K8S_KUBECONFIG"]) as api_client:
                click.echo(app.json.dumps(connection_report(api_client), ensure_ascii=False))
        except ApiException as error:
            # Do not include response bodies, headers or tokens in CLI errors.
            raise click.ClickException(f"Kubernetes API rejected request (HTTP {error.status})") from None
        except (ValueError, OSError, HTTPError, ConfigException, ClusterReadLimitError) as error:
            raise click.ClickException(f"Kubernetes configuration/TLS/network failure ({type(error).__name__})") from None

    @app.cli.command("inspect")
    def inspect_command():
        """Run one scheduled read-only inspection and persist its report."""
        from backend.models import AuditLog
        from backend.services.inspection_service import run_inspection
        run = run_inspection()
        db.session.add(AuditLog(action="inspection_scheduled", resource=f"inspection:{run.id}",
                                result=run.status))
        db.session.commit()
        click.echo(app.json.dumps({"id": run.id, "status": run.status,
                                   "finding_count": run.report["finding_count"]}))

    @app.get("/api/v1/health")
    def health():
        # Liveness only: this does not claim external dependencies are healthy.
        return jsonify(status="ok", service="opspilot-ai", scope="application")

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.after_request
    def security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
        if request.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.errorhandler(HTTPException)
    def http_error(error: HTTPException):
        response = error.get_response()
        response.data = app.json.dumps({"error": error.name, "status": error.code})
        response.content_type = "application/json"
        return response

    return app
