from backend.extensions import db
from backend.models.user import utcnow


class Server(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    agent_id = db.Column(db.String(128), nullable=False, unique=True)
    hostname = db.Column(db.String(128), nullable=False)
    ip_address = db.Column(db.String(45), nullable=False)
    last_heartbeat = db.Column(db.DateTime, nullable=False, index=True)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)
