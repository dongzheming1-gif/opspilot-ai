from backend.extensions import db


class Metric(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    server_id = db.Column(db.Integer, db.ForeignKey("server.id"), nullable=False)
    cpu_usage = db.Column(db.Float, nullable=False)
    memory_usage = db.Column(db.Float, nullable=False)
    disk_usage = db.Column(db.Float, nullable=False)
    network_in = db.Column(db.BigInteger, nullable=False)
    network_out = db.Column(db.BigInteger, nullable=False)
    uptime_seconds = db.Column(db.Float, nullable=False)
    collected_at = db.Column(db.DateTime, nullable=False, index=True)
    __table_args__ = (db.UniqueConstraint("server_id", "collected_at", name="uq_metric_sample"),)
