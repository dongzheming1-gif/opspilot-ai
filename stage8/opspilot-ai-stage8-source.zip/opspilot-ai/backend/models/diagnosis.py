from backend.extensions import db
from backend.models.user import utcnow


class Diagnosis(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    fault_type = db.Column(db.String(128), nullable=False)
    severity = db.Column(db.String(20), nullable=False)
    summary = db.Column(db.Text, nullable=False)
    resource = db.Column(db.String(255), nullable=False)
    result = db.Column(db.JSON, nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow, index=True)
