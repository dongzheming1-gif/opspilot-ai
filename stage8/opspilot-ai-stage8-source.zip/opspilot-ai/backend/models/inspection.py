from backend.extensions import db
from backend.models.user import utcnow


class InspectionRun(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow, index=True)
    status = db.Column(db.String(20), nullable=False)
    report = db.Column(db.JSON, nullable=False)
