from backend.extensions import db
from backend.models.user import utcnow


class Alert(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    alert_type = db.Column(db.String(64), nullable=False)
    severity = db.Column(db.String(20), nullable=False)
    source = db.Column(db.String(32), nullable=False)
    resource_name = db.Column(db.String(512), nullable=False)
    message = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), nullable=False, default="open", index=True)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)
    resolved_at = db.Column(db.DateTime)
    closed_by_user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
