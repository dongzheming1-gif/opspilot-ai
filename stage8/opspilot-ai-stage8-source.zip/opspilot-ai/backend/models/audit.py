from backend.extensions import db
from backend.models.user import utcnow


class AuditLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    action = db.Column(db.String(80), nullable=False)
    resource = db.Column(db.String(255), nullable=False)
    result = db.Column(db.String(32), nullable=False)
    source_ip = db.Column(db.String(45))
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow, index=True)
