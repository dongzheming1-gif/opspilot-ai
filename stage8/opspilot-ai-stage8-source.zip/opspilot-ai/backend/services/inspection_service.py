"""Bounded, read-only health inspection; database changes are reports and alerts only."""

from datetime import datetime, timedelta, timezone

from flask import current_app
from kubernetes.client.exceptions import ApiException
from kubernetes.config.config_exception import ConfigException
from urllib3.exceptions import HTTPError
from yaml import YAMLError

from backend.extensions import db
from backend.integrations.kubernetes_client import open_client
from backend.models import Alert, InspectionRun, Metric, Server
from backend.models.user import utcnow
from backend.services.k8s_service import ClusterReadLimitError, resources


def _sync_alerts(source, observations, kinds):
    """Resolve disappeared conditions and create one active alert per observed condition."""
    now = utcnow()
    active = db.session.execute(db.select(Alert).where(
        Alert.source == source, Alert.alert_type.in_(kinds),
        Alert.status.in_(("open", "acknowledged"))
    ).with_for_update()).scalars().all()
    observed = {(kind, name) for kind, name, _, _ in observations}
    existing = {(row.alert_type, row.resource_name) for row in active}
    for row in active:
        if (row.alert_type, row.resource_name) not in observed:
            row.status = "closed"
            row.resolved_at = now
    for kind, name, severity, message in observations:
        if (kind, name) in existing:
            continue
        # A manual close should not create a fresh alert on every scheduled run.
        recent = db.session.execute(db.select(Alert.id).where(
            Alert.source == source, Alert.alert_type == kind,
            Alert.resource_name == name, Alert.closed_by_user_id.is_not(None),
            Alert.created_at >= now - timedelta(hours=1)
        ).order_by(Alert.id.desc()).limit(1)).scalar_one_or_none()
        if recent is None:
            db.session.add(Alert(alert_type=kind, source=source, resource_name=name,
                                 severity=severity, message=message))


def run_inspection():
    """Return a persisted snapshot; never claim cluster health after a failed query."""
    findings = []
    linux_alerts = []
    servers = db.session.execute(db.select(Server).order_by(Server.id)).scalars().all()
    now = utcnow()
    thresholds = (("cpu_high", "cpu_usage", current_app.config["ALERT_CPU_THRESHOLD"]),
                  ("memory_high", "memory_usage", current_app.config["ALERT_MEMORY_THRESHOLD"]),
                  ("disk_high", "disk_usage", current_app.config["ALERT_DISK_THRESHOLD"]))
    for server in servers:
        age = (now - server.last_heartbeat).total_seconds()
        if age > current_app.config["AGENT_OFFLINE_SECONDS"]:
            message = f"Agent heartbeat missing for {int(age)} seconds"
            linux_alerts.append(("agent_offline", server.agent_id, "critical", message))
            findings.append({"source": "linux", "resource": server.hostname,
                             "kind": "agent_offline", "message": message})
        latest = db.session.execute(db.select(Metric).where(Metric.server_id == server.id)
            .order_by(Metric.collected_at.desc()).limit(1)).scalar_one_or_none()
        if latest is None:
            findings.append({"source": "linux", "resource": server.hostname,
                             "kind": "no_metrics", "message": "No metric samples received"})
            continue
        for kind, field, threshold in thresholds:
            value = getattr(latest, field)
            if value > threshold:
                findings.append({"source": "linux", "resource": server.hostname,
                                 "kind": kind, "message": f"{value:.1f}% > {threshold}%"})
    _sync_alerts("linux", linux_alerts, ("agent_offline",))

    cluster = {"status": "unavailable", "nodes": 0, "pods": 0, "warning_events": 0}
    k8s_alerts = []
    try:
        with open_client(current_app.config["K8S_KUBECONFIG"]) as api_client:
            nodes = resources(api_client, "nodes")
            pods = resources(api_client, "pods")
            events = resources(api_client, "events")
        recent_warnings = []
        for event in events:
            if event["type"] != "Warning" or not event["time"]:
                continue
            stamp = datetime.fromisoformat(event["time"].replace("Z", "+00:00"))
            if stamp.tzinfo is None:
                stamp = stamp.replace(tzinfo=timezone.utc)
            if timedelta(0) <= datetime.now(timezone.utc) - stamp <= timedelta(hours=1):
                recent_warnings.append(event)
        cluster = {"status": "ok", "nodes": len(nodes), "pods": len(pods),
                   "warning_events": len(recent_warnings)}
        for node in nodes:
            if not node["ready"]:
                k8s_alerts.append(("node_not_ready", node["name"], "critical", "Node Ready condition is false"))
                findings.append({"source": "kubernetes", "resource": node["name"],
                                 "kind": "node_not_ready", "message": "Node Ready condition is false"})
        for pod in pods:
            name = f"{pod['namespace']}/{pod['name']}"
            if "CrashLoopBackOff" in pod["anomalies"]:
                k8s_alerts.append(("pod_crash_loop", name, "critical", "Container is in CrashLoopBackOff"))
                findings.append({"source": "kubernetes", "resource": name,
                                 "kind": "pod_crash_loop", "message": "Container is in CrashLoopBackOff"})
            if pod["phase"] == "Pending" and pod["created_at"]:
                created = datetime.fromisoformat(pod["created_at"].replace("Z", "+00:00"))
                age = (datetime.now(timezone.utc) - created).total_seconds()
                if age > current_app.config["POD_PENDING_SECONDS"]:
                    k8s_alerts.append(("pod_pending", name, "warning", f"Pod Pending for {int(age)} seconds"))
                    findings.append({"source": "kubernetes", "resource": name,
                                     "kind": "pod_pending", "message": f"Pending for {int(age)} seconds"})
        for event in recent_warnings:
            findings.append({"source": "kubernetes", "resource": f"{event['namespace']}/{event['resource']}",
                             "kind": "warning_event", "message": f"{event['reason']}: {event['message'][:200]}"})
        _sync_alerts("kubernetes", k8s_alerts,
                     ("node_not_ready", "pod_crash_loop", "pod_pending"))
    except (ApiException, ConfigException, ClusterReadLimitError, HTTPError, YAMLError, OSError, ValueError) as error:
        cluster["error_category"] = type(error).__name__
        current_app.logger.warning("Inspection Kubernetes query unavailable: %s", type(error).__name__)

    report = {"status": "complete" if cluster["status"] == "ok" else "partial",
              "checked_at": now.isoformat() + "Z", "servers": len(servers),
              "cluster": cluster, "finding_count": len(findings), "findings": findings[:500],
              "findings_truncated": len(findings) > 500}
    run = InspectionRun(status=report["status"], report=report)
    db.session.add(run)
    db.session.flush()
    return run
