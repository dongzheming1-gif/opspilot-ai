"""Build a deliberately narrow, secret-free snapshot from persisted metrics."""

from datetime import datetime, timezone
import math

from backend.extensions import db
from backend.models import Metric, Server
from backend.integrations.deepseek_client import DiagnosisError


def server_context(server_id):
    if type(server_id) is not int or server_id < 1:
        raise DiagnosisError("invalid_server_id", 400)
    if db.session.get(Server, server_id) is None:
        raise DiagnosisError("server_not_found", 404)
    metric = db.session.execute(db.select(Metric).where(Metric.server_id == server_id)
                                .order_by(Metric.collected_at.desc()).limit(1)).scalar_one_or_none()
    if metric is None:
        raise DiagnosisError("metrics_unavailable", 409)
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    age = (now - metric.collected_at).total_seconds()
    if age < -30 or age > 120:
        raise DiagnosisError("metrics_stale", 409)
    values = {name: getattr(metric, name) for name in ("cpu_usage", "memory_usage", "disk_usage")}
    if any(not math.isfinite(v) or not 0 <= v <= 100 for v in values.values()):
        raise DiagnosisError("invalid_stored_metrics", 409)
    return {"source": "linux_agent", "collected_at": metric.collected_at.isoformat() + "Z",
            "limitations": ["single_sample", "no_process_details", "no_raw_logs"],
            "evidence": [{"id": "E1", "observation": values, "unit": "percent"}]}
