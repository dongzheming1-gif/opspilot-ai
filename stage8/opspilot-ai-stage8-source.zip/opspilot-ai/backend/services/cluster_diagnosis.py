"""Read-only cluster snapshots; arbitrary resource text never goes to the model."""
from datetime import datetime, timezone
import re

from kubernetes import client
from kubernetes.client.exceptions import ApiException
from kubernetes.config.config_exception import ConfigException
from urllib3.exceptions import HTTPError
from yaml import YAMLError

from backend.integrations.kubernetes_client import open_client
from backend.integrations.deepseek_client import DiagnosisError
from backend.services.k8s_service import pod_summary, pod_logs, TIMEOUT

REASONS = {"Pending", "Failed", "Unknown", "CrashLoopBackOff", "ImagePullBackOff", "ErrImagePull",
           "OOMKilled", "FailedScheduling", "BackOff", "FailedMount", "FailedAttachVolume",
           "Unhealthy", "Killing", "Pulled", "Pulling", "Created", "Started", "Scheduled",
           "Error", "Completed", "ContainerCreating", "CreateContainerConfigError", "NodeNotReady"}
SIGNALS = {"connection_refused": "connection refused", "permission_denied": "permission denied",
           "disk_full": "no space left on device", "out_of_memory": "out of memory",
           "file_not_found": "no such file or directory", "nginx_502": "502 bad gateway"}


def log_signals(text):
    """Return fixed labels/counts, never excerpts or arbitrary regex capture groups."""
    lowered = text.lower()
    return {label: lowered.count(pattern) for label, pattern in SIGNALS.items() if pattern in lowered}


def validate_selection(data):
    if not isinstance(data, dict) or data.get("source") not in ("pod", "node"):
        raise DiagnosisError("invalid_diagnosis_source", 400)
    fields = {"source", "name", "namespace"} if data["source"] == "pod" else {"source", "name"}
    if set(data) != fields:
        raise DiagnosisError("invalid_resource_selection", 400)
    for field in fields - {"source"}:
        value = data[field]
        if not isinstance(value, str) or not 1 <= len(value) <= (63 if field == "namespace" else 253):
            raise DiagnosisError("invalid_resource_name", 400)
        if any(not re.fullmatch(r"[a-z0-9](?:[-a-z0-9]*[a-z0-9])?", label) for label in value.split('.')):
            raise DiagnosisError("invalid_resource_name", 400)
    resource = ':'.join(data[field] for field in (['source', 'namespace', 'name'] if data['source'] == 'pod' else ['source', 'name']))
    if len(resource) > 255:
        raise DiagnosisError("resource_reference_too_long", 400)
    return resource


def collect_events(core, obj, source):
    selector = f"involvedObject.uid={obj.metadata.uid}"
    method = core.list_namespaced_event if source == "pod" else core.list_event_for_all_namespaces
    kwargs = {"namespace": obj.metadata.namespace} if source == "pod" else {}
    page = method(field_selector=selector, limit=100, _request_timeout=TIMEOUT, **kwargs)
    # Match UID locally as well: never associate events from a deleted same-name Pod.
    items = [event for event in page.items if event.involved_object.uid == obj.metadata.uid]
    reasons = {}
    unknown = 0
    for event in items:
        if event.reason in REASONS:
            reasons[event.reason] = reasons.get(event.reason, 0) + (event.count or 1)
        else:
            unknown += 1
    return {"reason_counts": reasons, "unknown_reason_records": unknown,
            "records": len(items), "truncated": bool(page.metadata._continue),
            "historical_events_not_current_state": True}


def cluster_context(settings, data):
    validate_selection(data)
    source = data['source']
    context = {"source": f"kubernetes_{source}", "collected_at": datetime.now(timezone.utc).isoformat(),
               "limitations": ["single_snapshot", "raw_text_omitted", "events_may_be_historical"], "evidence": []}

    def evidence(observation):
        context['evidence'].append({'id': f"E{len(context['evidence']) + 1}", 'observation': observation})

    try:
        with open_client(settings['K8S_KUBECONFIG']) as api:
            core = client.CoreV1Api(api)
            if source == 'pod':
                obj = core.read_namespaced_pod(data['name'], data['namespace'], _request_timeout=TIMEOUT)
                summary = pod_summary(obj)
                evidence({'phase': summary['phase'] if summary['phase'] in {'Pending', 'Running', 'Succeeded', 'Failed', 'Unknown'} else 'Unknown',
                          'restarts': summary['restarts'],
                          'anomalies': [r for r in summary['anomalies'] if r in REASONS],
                          'unknown_anomaly_count': sum(r not in REASONS for r in summary['anomalies']),
                          'ready_app_containers': sum(bool(c.ready) for c in obj.status.container_statuses or []),
                          'app_status_count': len(obj.status.container_statuses or []),
                          'init_status_count': len(obj.status.init_container_statuses or [])})
            else:
                obj = core.read_node(data['name'], _request_timeout=TIMEOUT)
                conditions = {c.type: c.status if c.status in {'True', 'False', 'Unknown'} else 'Unknown'
                              for c in obj.status.conditions or []
                              if c.type in {'Ready', 'MemoryPressure', 'DiskPressure', 'PIDPressure', 'NetworkUnavailable'}}
                conditions.setdefault('Ready', 'Unknown')
                evidence({'conditions': conditions})
            try:
                evidence({'events': collect_events(core, obj, source)})
            except (ApiException, HTTPError, OSError):
                context['limitations'].append('events_unavailable')
            if source == 'pod':
                # A bounded single-container sample; select the abnormal container first.
                statuses = (obj.status.init_container_statuses or []) + (obj.status.container_statuses or [])
                abnormal = [s for s in statuses if s.state and
                            (s.state.waiting or (s.state.terminated and s.state.terminated.reason != 'Completed'))]
                selected = next(iter(abnormal or statuses), None)
                if selected is None:
                    context['limitations'].append('container_logs_unavailable')
                else:
                    context['limitations'].extend(['one_container_only', 'logs_tail_200_lines_32KiB', 'log_signals_not_root_cause'])
                    for previous in ([False, True] if selected.restart_count else [False]):
                        stream = 'previous' if previous else 'current'
                        try:
                            text = pod_logs(api, data['namespace'], data['name'], selected.name, previous)
                            evidence({'logs': {'stream': stream, 'signals': log_signals(text), 'empty': not bool(text)}})
                        except (ApiException, HTTPError, OSError):
                            context['limitations'].append(f'{stream}_logs_unavailable')
            # Detect deletion/recreation while collecting evidence before mixing snapshots.
            final = (core.read_namespaced_pod(data['name'], data['namespace'], _request_timeout=TIMEOUT)
                     if source == 'pod' else core.read_node(data['name'], _request_timeout=TIMEOUT))
            if final.metadata.uid != obj.metadata.uid:
                raise DiagnosisError('resource_recreated_during_collection', 409)
    except ApiException as error:
        codes = {401: 'kubernetes_credentials_invalid', 403: 'kubernetes_permission_denied', 404: 'resource_not_found'}
        raise DiagnosisError(codes.get(error.status, 'kubernetes_request_failed'), 404 if error.status == 404 else 502) from None
    except (ValueError, OSError, ConfigException, HTTPError, YAMLError):
        raise DiagnosisError('kubernetes_configuration_or_network_error', 503) from None
    return context
