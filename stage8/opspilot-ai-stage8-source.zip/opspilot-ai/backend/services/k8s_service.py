"""Read-only cluster connection verification, with bounded API requests."""

from kubernetes import client
from time import monotonic

TIMEOUT = (3, 10)


class ClusterReadLimitError(RuntimeError):
    """The query cannot complete within the bounded resource/page budget."""


def pod_summary(pod):
    statuses = (pod.status.init_container_statuses or []) + (pod.status.container_statuses or [])
    reasons = set()
    containers = []
    if pod.status.phase in ("Pending", "Failed", "Unknown"):
        reasons.add(pod.status.phase)
    for status in statuses:
        detail = {"name":status.name, "ready":status.ready, "restarts":status.restart_count}
        for state_name in ("waiting", "terminated"):
            current = getattr(status.state, state_name, None) if status.state else None
            if current and current.reason:
                detail["reason"] = current.reason
                if current.reason != "Completed":
                    reasons.add(current.reason)
        previous = status.last_state.terminated if status.last_state else None
        if previous and previous.reason == "OOMKilled":
            reasons.add("OOMKilled")
            detail["previous_reason"] = "OOMKilled"
        containers.append(detail)
    for condition in pod.status.conditions or []:
        if condition.type == "PodScheduled" and condition.status == "False":
            reasons.add("FailedScheduling")
    return {"name":pod.metadata.name, "namespace":pod.metadata.namespace,
            "node":pod.spec.node_name, "ip":pod.status.pod_ip,
            "phase":pod.status.phase, "restarts":sum(s.restart_count for s in statuses),
            "containers":containers, "anomalies":sorted(reasons),
            "created_at":pod.metadata.creation_timestamp.isoformat() if pod.metadata.creation_timestamp else None}


def node_summary(node):
    ready = any(c.type == "Ready" and c.status == "True" for c in (node.status.conditions or []))
    return {"name":node.metadata.name, "ready":ready,
            "ip":next((a.address for a in node.status.addresses or [] if a.type == "InternalIP"), None),
            "roles":[key.split("/",1)[1] for key in (node.metadata.labels or {}) if key.startswith("node-role.kubernetes.io/")],
            "version":node.status.node_info.kubelet_version, "runtime":node.status.node_info.container_runtime_version,
            "capacity":node.status.capacity, "allocatable":node.status.allocatable,
            "anomalies":[] if ready else ["Node NotReady"]}


def resources(api_client, kind, namespace=None):
    core = client.CoreV1Api(api_client)
    apps = client.AppsV1Api(api_client)
    if kind == "nodes":
        return [node_summary(n) for n in all_items(core.list_node)]
    if kind == "namespaces":
        return [{"name":n.metadata.name,"status":n.status.phase} for n in all_items(core.list_namespace)]
    methods = {
        "pods":(core.list_namespaced_pod,core.list_pod_for_all_namespaces),
        "services":(core.list_namespaced_service,core.list_service_for_all_namespaces),
        "events":(core.list_namespaced_event,core.list_event_for_all_namespaces),
        "deployments":(apps.list_namespaced_deployment,apps.list_deployment_for_all_namespaces),
    }
    scoped, global_list = methods[kind]
    items = all_items(scoped,namespace=namespace) if namespace else all_items(global_list)
    if kind == "pods":
        return [pod_summary(p) for p in items]
    if kind == "deployments":
        return [{"name":d.metadata.name,"namespace":d.metadata.namespace,"desired":d.spec.replicas or 0,
                 "available":d.status.available_replicas or 0,"ready":d.status.ready_replicas or 0,
                 "conditions":[{"type":c.type,"status":c.status,"reason":c.reason} for c in d.status.conditions or []]} for d in items]
    if kind == "services":
        return [{"name":s.metadata.name,"namespace":s.metadata.namespace,"type":s.spec.type,"cluster_ip":s.spec.cluster_ip,
                 "ports":[{"port":p.port,"target_port":p.target_port,"protocol":p.protocol,"node_port":p.node_port} for p in s.spec.ports or []]} for s in items]
    if kind == "events":
        events=[]
        for event in items:
            stamp=event.last_timestamp or event.event_time or event.metadata.creation_timestamp
            events.append({"name":event.metadata.name,"namespace":event.metadata.namespace,"type":event.type,
                           "reason":event.reason,"message":event.message,"resource":event.involved_object.name,
                           "time":stamp.isoformat() if stamp else "","count":event.count or 1})
        return sorted(events,key=lambda e:e["time"],reverse=True)


def pod_logs(api_client, namespace, pod, container=None, previous=False):
    return client.CoreV1Api(api_client).read_namespaced_pod_log(
        pod, namespace, container=container, previous=previous, tail_lines=200,
        limit_bytes=32768, timestamps=True, _request_timeout=TIMEOUT)


def all_items(method, **kwargs):
    items = []
    token = None
    seen_tokens = set()
    deadline = monotonic() + 12
    while True:
        remaining = deadline - monotonic()
        if remaining <= 0 or len(items) >= 20000:
            raise ClusterReadLimitError("Query limit reached; narrow the namespace filter")
        page = method(limit=200, _continue=token,
                      _request_timeout=(min(3, remaining / 2), min(10, remaining / 2)), **kwargs)
        items.extend(page.items)
        token = page.metadata._continue
        if not token:
            return items
        if token in seen_tokens:
            raise ClusterReadLimitError("API returned a repeated pagination token")
        seen_tokens.add(token)


def connection_report(api_client):
    core = client.CoreV1Api(api_client)
    nodes = all_items(core.list_node)
    pods = all_items(core.list_pod_for_all_namespaces)
    version = client.VersionApi(api_client).get_code(_request_timeout=TIMEOUT)
    return {
        "version": version.git_version,
        "nodes": [{"name": n.metadata.name,
                   "ready": any(c.type == "Ready" and c.status == "True"
                                for c in (n.status.conditions or [])),
                   "runtime": n.status.node_info.container_runtime_version} for n in nodes],
        "pod_count": len(pods),
        "pods": [{"name": p.metadata.name, "namespace": p.metadata.namespace,
                  "phase": p.status.phase} for p in pods],
    }
