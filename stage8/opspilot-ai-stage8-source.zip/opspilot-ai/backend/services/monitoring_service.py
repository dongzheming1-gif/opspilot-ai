import json
from datetime import datetime, timezone, timedelta

from flask import current_app
from sqlalchemy.exc import IntegrityError
from backend.extensions import db
from backend.models import Server, Metric, Alert
from backend.models.user import utcnow


def store_metric(data, source_ip):
    timestamp = datetime.fromisoformat(data["collected_at"]).astimezone(timezone.utc).replace(tzinfo=None)
    server = db.session.execute(db.select(Server).filter_by(agent_id=data["agent_id"]).with_for_update()).scalar_one_or_none()
    if server is None:
        server = Server(agent_id=data["agent_id"], hostname=data["hostname"], ip_address=source_ip, last_heartbeat=utcnow())
        db.session.add(server)
        db.session.flush()
    server.last_heartbeat = utcnow()
    server.hostname = data["hostname"]
    server.ip_address = source_ip
    existing = db.session.execute(db.select(Metric.id).filter_by(server_id=server.id, collected_at=timestamp)).scalar_one_or_none()
    if existing is None:
        fields = {key:data[key] for key in ("cpu_usage","memory_usage","disk_usage","network_in","network_out","uptime_seconds")}
        db.session.add(Metric(server_id=server.id, collected_at=timestamp, **fields))
        evaluate_metric_alerts(server, fields)
    db.session.commit()
    cache = current_app.extensions.get("redis")
    cached = False
    if cache:
        from redis.exceptions import RedisError
        try:
            cache.set(f"metric:{server.id}", json.dumps(data), ex=90)
            cached = True
        except RedisError:
            current_app.logger.warning("Latest metric cache unavailable; MySQL write succeeded")
    return cached


def evaluate_metric_alerts(server, metric):
    rules = (("cpu_high", "cpu_usage", current_app.config["ALERT_CPU_THRESHOLD"]),
             ("memory_high", "memory_usage", current_app.config["ALERT_MEMORY_THRESHOLD"]),
             ("disk_high", "disk_usage", current_app.config["ALERT_DISK_THRESHOLD"]))
    for alert_type, field, threshold in rules:
        active = db.session.execute(db.select(Alert).filter_by(
            alert_type=alert_type, source="linux", resource_name=server.agent_id
        ).where(Alert.status.in_(("open", "acknowledged"))).with_for_update()).scalar_one_or_none()
        value = metric[field]
        if value > threshold:
            if active is None:
                recent = db.session.execute(db.select(Alert.id).where(
                    Alert.alert_type == alert_type, Alert.source == "linux",
                    Alert.resource_name == server.agent_id,
                    Alert.closed_by_user_id.is_not(None),
                    Alert.created_at >= utcnow() - timedelta(hours=1)
                ).order_by(Alert.id.desc()).limit(1)).scalar_one_or_none()
                if recent is None:
                    db.session.add(Alert(alert_type=alert_type, severity="warning", source="linux",
                        resource_name=server.agent_id,
                        message=f"{field} is {value:.1f}%, above the {threshold}% threshold"))
        elif active is not None:
            active.status = "closed"
            active.resolved_at = utcnow()
