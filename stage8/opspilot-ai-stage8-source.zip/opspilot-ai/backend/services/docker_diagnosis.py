"""Allowlisted state and log features from an independent Docker Engine."""
from datetime import datetime, timezone
import re
from docker.errors import DockerException, NotFound
from backend.integrations.docker_client import open_docker, DockerNotConfigured
from backend.integrations.deepseek_client import DiagnosisError
from backend.services.docker_service import read_logs
from backend.services.cluster_diagnosis import log_signals


def validate_docker_selection(data):
    if set(data) != {'source', 'container_id'} or not isinstance(data.get('container_id'), str) or not re.fullmatch(r'[a-f0-9]{64}', data['container_id']):
        raise DiagnosisError('invalid_container_id', 400)
    return 'docker:' + data['container_id']


def docker_context(settings, data):
    validate_docker_selection(data)
    context = {'source': 'docker_engine', 'collected_at': datetime.now(timezone.utc).isoformat(),
               'limitations': ['single_snapshot', 'raw_text_omitted', 'logs_tail_200_lines_32KiB', 'log_signals_not_root_cause'],
               'evidence': []}
    try:
        with open_docker(settings) as engine:
            container = engine.containers.get(data['container_id'])
            state = container.attrs['State']
            status = state.get('Status')
            observation = {'status': status if status in {'created','running','paused','restarting','removing','exited','dead'} else 'unknown',
                           'oom_killed': bool(state.get('OOMKilled')), 'restart_count': container.attrs.get('RestartCount',0)}
            # ExitCode while running is not an observed process exit.
            if status in {'exited', 'dead'}:
                observation['exit_code'] = state.get('ExitCode')
            context['evidence'].append({'id':'E1','observation':observation})
            try:
                logs = read_logs(container)
                context['evidence'].append({'id':'E2','observation':{'logs':{'signals':log_signals(logs['logs']),
                    'empty':not bool(logs['logs']), 'truncated':logs['truncated']}}})
            except DockerException:
                context['limitations'].append('container_logs_unavailable')
    except DockerNotConfigured:
        raise DiagnosisError('docker_not_configured',503) from None
    except NotFound:
        raise DiagnosisError('container_not_found',404) from None
    except (DockerException, ValueError, OSError):
        raise DiagnosisError('docker_connection_failed',502) from None
    return context
