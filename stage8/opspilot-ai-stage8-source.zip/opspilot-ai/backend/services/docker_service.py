"""Bounded queries and explicitly opted-in container lifecycle operations."""

MANAGEMENT_LABEL = "opspilot.managed"


def container_summary(container):
    return {"id":container.id,"name":container.name,"status":container.status,
            "image":container.attrs.get("Config",{}).get("Image", ""),
            "managed":container.labels.get(MANAGEMENT_LABEL)=="true"}


def list_containers(connection):
    return [container_summary(c) for c in connection.containers.list(all=True,limit=200)]


def read_logs(container):
    stream=container.logs(tail=200,stream=True,follow=False,timestamps=True)
    chunks=[]
    remaining=32768
    truncated=False
    try:
        for chunk in stream:
            if len(chunk)>remaining:
                truncated=True
            chunks.append(chunk[:remaining])
            remaining-=min(len(chunk),remaining)
            if remaining==0:
                truncated=True
                break
    finally:
        if hasattr(stream,"close"):
            stream.close()
    return {"logs":b"".join(chunks).decode("utf-8",errors="replace"),"truncated":truncated,"max_bytes":32768}


def change_state(container, action):
    if container.labels.get(MANAGEMENT_LABEL)!="true":
        raise PermissionError("Container must have opspilot.managed=true")
    if action=="start":
        container.start()
    elif action=="stop":
        container.stop(timeout=5)
    else:
        raise ValueError("Unsupported action")
    container.reload()
    return container_summary(container)
