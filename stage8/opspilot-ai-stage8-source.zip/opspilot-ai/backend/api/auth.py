from datetime import datetime, timezone
from functools import wraps

from flask import Blueprint, current_app, jsonify, request
from flask_jwt_extended import create_access_token, get_jwt, get_jwt_identity, jwt_required
from werkzeug.security import check_password_hash

from backend.extensions import db
from backend.models import AuditLog, RevokedToken, User

bp = Blueprint("auth", __name__)


def audit(action, resource, result="success", user_id=None):
    db.session.add(AuditLog(user_id=user_id, action=action, resource=resource,
                            result=result, source_ip=request.remote_addr))


def roles_required(*roles):
    def decorate(func):
        @wraps(func)
        @jwt_required()
        def wrapped(*args, **kwargs):
            user = db.session.get(User, int(get_jwt_identity()))
            if not user or user.role not in roles:
                return jsonify(error="Permission denied"), 403
            return func(*args, **kwargs)
        return wrapped
    return decorate


@bp.post("/api/v1/auth/login")
def login():
    data = request.get_json(silent=True) or {}
    if not isinstance(data, dict) or not isinstance(data.get("username"), str) or not isinstance(data.get("password"), str):
        return jsonify(error="Username and password required"), 400
    if len(data["username"]) > 80 or len(data["password"]) > 256:
        return jsonify(error="Invalid credentials"), 401
    cache = current_app.extensions.get("redis")
    if cache is None:
        return jsonify(error="Authentication rate limiter unavailable"), 503
    import hashlib
    key = "login:" + hashlib.sha256((request.remote_addr or "local").encode()).hexdigest()
    attempts = cache.incr(key)
    if attempts == 1:
        cache.expire(key, 60)
    if attempts > 10:
        return jsonify(error="Too many login attempts; try again in one minute"), 429
    user = db.session.execute(db.select(User).filter_by(username=data["username"])).scalar_one_or_none()
    if user is None or not check_password_hash(user.password_hash, data["password"]):
        audit("login", "user", "denied")
        db.session.commit()
        return jsonify(error="Invalid credentials"), 401
    audit("login", "user", user_id=user.id)
    db.session.commit()
    return jsonify(access_token=create_access_token(identity=str(user.id)), username=user.username, role=user.role)


@bp.post("/api/v1/auth/logout")
@jwt_required()
def logout():
    token = get_jwt()
    db.session.add(RevokedToken(jti=token["jti"], expires_at=datetime.fromtimestamp(token["exp"], timezone.utc).replace(tzinfo=None)))
    audit("logout", "user", user_id=int(get_jwt_identity()))
    db.session.commit()
    return jsonify(status="logged_out")


@bp.get("/api/v1/auth/me")
@jwt_required()
def me():
    user = db.session.get(User, int(get_jwt_identity()))
    if user is None:
        return jsonify(error="User no longer exists"), 401
    return jsonify(username=user.username, role=user.role)
