from flask import Blueprint, jsonify

from backend.api.auth import roles_required
from backend.extensions import db
from backend.models import AuditLog, User

bp = Blueprint("audit_logs", __name__, url_prefix="/api/v1/audit-logs")


@bp.get("")
@roles_required("admin")
def list_logs():
    rows = db.session.execute(db.select(AuditLog, User.username).outerjoin(
        User, AuditLog.user_id == User.id).order_by(AuditLog.id.desc()).limit(200)).all()
    return jsonify(items=[{"id": log.id, "user": username,
                           "action": log.action, "resource": log.resource,
                           "result": log.result, "source_ip": log.source_ip,
                           "created_at": log.created_at.isoformat() + "Z"}
                          for log, username in rows], limit=200)
