from functools import wraps
import re

from flask import Blueprint, current_app, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from docker.errors import DockerException, NotFound
from requests.exceptions import RequestException

from backend.extensions import db
from backend.models import User
from backend.api.auth import audit
from backend.integrations.docker_client import open_docker, DockerNotConfigured
from backend.services.docker_service import list_containers, read_logs, change_state

bp=Blueprint("docker",__name__)


def docker_operation(func):
    @wraps(func)
    @jwt_required()
    def wrapped(*args,**kwargs):
        result="failed"
        try:
            response=func(*args,**kwargs)
            result="failed" if isinstance(response,tuple) and response[1]>=400 else "success"
            return response
        except DockerNotConfigured:
            return jsonify(state="not_configured",error="独立 Docker Engine 待接入；Kubernetes 使用 containerd，不属于本模块"),503
        except PermissionError:
            return jsonify(error="Container is not opted in for management"),403
        except ValueError:
            return jsonify(error="Invalid Docker configuration or action"),400
        except NotFound:
            return jsonify(error="Docker container not found"),404
        except (DockerException,RequestException,OSError):
            return jsonify(state="unavailable",error="Docker Engine connection or operation failed"),502
        finally:
            audit("docker_"+request.method.lower(),request.path,result,int(get_jwt_identity()))
            db.session.commit()
    return wrapped


@bp.get("/api/v1/docker/status")
@docker_operation
def status():
    with open_docker(current_app.config) as connection:
        if not connection.ping():
            return jsonify(state="unavailable",error="Docker Engine did not respond"),502
        return jsonify(state="connected",version=connection.version().get("Version"),actions_enabled=current_app.config["DOCKER_ACTIONS_ENABLED"])


@bp.get("/api/v1/docker/containers")
@docker_operation
def containers():
    with open_docker(current_app.config) as connection:
        return jsonify(items=list_containers(connection),limit=200)


@bp.get("/api/v1/docker/images")
@docker_operation
def images():
    with open_docker(current_app.config) as connection:
        items=connection.images.list()
        return jsonify(items=[{"id":image.id,"tags":image.tags} for image in items[:200]],truncated=len(items)>200)


@bp.get("/api/v1/docker/containers/<container_id>/logs")
@docker_operation
def logs(container_id):
    if not re.fullmatch(r"[a-f0-9]{12,64}",container_id):
        return jsonify(error="Invalid container ID"),400
    with open_docker(current_app.config) as connection:
        return jsonify(read_logs(connection.containers.get(container_id)))


@bp.post("/api/v1/docker/containers/<container_id>/<action>")
@docker_operation
def action(container_id,action):
    user=db.session.get(User,int(get_jwt_identity()))
    if not user or user.role!="admin":
        return jsonify(error="Administrator role required"),403
    if not current_app.config["DOCKER_ACTIONS_ENABLED"]:
        return jsonify(error="Docker management actions are disabled"),403
    data=request.get_json(silent=True)
    if action not in {"start","stop"} or not re.fullmatch(r"[a-f0-9]{64}",container_id):
        return jsonify(error="Explicit full container ID and start/stop action required"),400
    if not isinstance(data,dict) or data.get("confirm_container_id")!=container_id:
        return jsonify(error="Container confirmation is required"),400
    with open_docker(current_app.config) as connection:
        container=connection.containers.get(container_id)
        # Persist intent before the external side effect; DB failure prevents action.
        audit("docker_action_requested",request.path,"requested",user.id)
        db.session.commit()
        return jsonify(change_state(container,action))
