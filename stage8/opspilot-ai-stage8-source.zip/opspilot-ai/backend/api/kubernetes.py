from functools import wraps
import re

from flask import Blueprint, current_app, jsonify, request
from flask_jwt_extended import get_jwt_identity, jwt_required
from kubernetes.client.exceptions import ApiException
from kubernetes.config.config_exception import ConfigException
from urllib3.exceptions import HTTPError
from yaml import YAMLError

from backend.extensions import db
from backend.api.auth import audit
from backend.integrations.kubernetes_client import open_client
from backend.services.k8s_service import resources, pod_logs, ClusterReadLimitError

bp = Blueprint("kubernetes", __name__)
KINDS = {"nodes", "pods", "deployments", "services", "namespaces", "events"}


def valid_name(value):
    return isinstance(value,str) and len(value)<=253 and re.fullmatch(r"[a-z0-9](?:[-a-z0-9.]*[a-z0-9])?",value)


def cluster_operation(func):
    @wraps(func)
    @jwt_required()
    def wrapped(*args, **kwargs):
        result="failed"
        try:
            with open_client(current_app.config["K8S_KUBECONFIG"]) as api_client:
                response=func(api_client,*args,**kwargs)
                result="failed" if isinstance(response,tuple) and response[1]>=400 else "success"
                return response
        except ApiException as error:
            messages = {400:"Kubernetes rejected the request; verify container and previous-log selection",
                        401:"Kubernetes credential expired or invalid",403:"Kubernetes RBAC permission denied",
                        404:"Kubernetes resource no longer exists",429:"Kubernetes API rate limit reached"}
            status = error.status if error.status in (400,404,429) else 502
            return jsonify(error=messages.get(error.status,"Kubernetes API request failed"), upstream_status=error.status), status
        except ClusterReadLimitError:
            return jsonify(error="Kubernetes query exceeded its time or resource limit; select a narrower namespace"),504
        except (ValueError, OSError, ConfigException, HTTPError, YAMLError) as error:
            return jsonify(error="Kubernetes configuration, TLS or network unavailable", category=type(error).__name__),503
        finally:
            audit("kubernetes_query", request.path, result, int(get_jwt_identity()))
            db.session.commit()
    return wrapped


@bp.get("/api/v1/kubernetes/<kind>")
@cluster_operation
def list_resources(api_client, kind):
    if kind not in KINDS:
        return jsonify(error="Unknown resource type"),404
    namespace=request.args.get("namespace") or None
    if namespace and not valid_name(namespace):
        return jsonify(error="Invalid namespace"),400
    items=resources(api_client,kind,namespace)
    total=len(items)
    if kind=="events":
        items=items[:200]
    return jsonify(items=items,total=total,truncated=len(items)<total)


@bp.get("/api/v1/kubernetes/summary")
@cluster_operation
def summary(api_client):
    nodes=resources(api_client,"nodes")
    pods=resources(api_client,"pods")
    return jsonify(nodes=len(nodes), ready_nodes=sum(n["ready"] for n in nodes),
                   pods=len(pods), abnormal_pods=sum(bool(p["anomalies"]) for p in pods))


@bp.get("/api/v1/kubernetes/pods/<namespace>/<pod>/logs")
@cluster_operation
def logs(api_client,namespace,pod):
    container=request.args.get("container") or None
    if not all(valid_name(name) for name in [namespace,pod]+([container] if container else [])):
        return jsonify(error="Invalid resource name"),400
    text=pod_logs(api_client,namespace,pod,container,request.args.get("previous")=="true")
    return jsonify(logs=text, max_lines=200, max_bytes=32768)
