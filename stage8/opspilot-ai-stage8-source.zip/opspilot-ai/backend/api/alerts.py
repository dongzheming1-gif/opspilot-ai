from flask import Blueprint, jsonify, request
from flask_jwt_extended import get_jwt_identity

from backend.api.auth import audit, roles_required
from backend.extensions import db
from backend.models import Alert
from backend.models.user import utcnow

bp = Blueprint("alerts", __name__, url_prefix="/api/v1/alerts")


def serialize(alert):
    return {"id": alert.id, "alert_type": alert.alert_type, "severity": alert.severity,
            "source": alert.source, "resource_name": alert.resource_name, "message": alert.message,
            "status": alert.status, "created_at": alert.created_at.isoformat() + "Z",
            "resolved_at": alert.resolved_at.isoformat() + "Z" if alert.resolved_at else None}


@bp.get("")
@roles_required("admin", "operator", "viewer")
def list_alerts():
    status = request.args.get("status")
    if status and status not in {"open", "acknowledged", "closed"}:
        return jsonify(error="Invalid status filter"), 400
    query = db.select(Alert).order_by(Alert.created_at.desc(), Alert.id.desc()).limit(200)
    if status:
        query = query.where(Alert.status == status)
    rows = db.session.execute(query).scalars()
    return jsonify(items=[serialize(row) for row in rows], limit=200)


def update_status(alert_id, status):
    alert = db.get_or_404(Alert, alert_id)
    if alert.status == "closed":
        return jsonify(error="Alert is already closed"), 409
    user_id = int(get_jwt_identity())
    alert.status = status
    if status == "closed":
        alert.resolved_at = utcnow()
        alert.closed_by_user_id = user_id
    audit("alert_acknowledged" if status == "acknowledged" else "alert_closed",
          f"alert:{alert.id}", user_id=user_id)
    db.session.commit()
    return jsonify(item=serialize(alert))


@bp.post("/<int:alert_id>/acknowledge")
@roles_required("admin", "operator")
def acknowledge(alert_id):
    return update_status(alert_id, "acknowledged")


@bp.post("/<int:alert_id>/close")
@roles_required("admin", "operator")
def close(alert_id):
    return update_status(alert_id, "closed")
