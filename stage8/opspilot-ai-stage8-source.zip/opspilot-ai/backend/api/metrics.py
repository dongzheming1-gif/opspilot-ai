import hmac
import math
from datetime import datetime, timezone

from flask import Blueprint, current_app, jsonify, request

bp = Blueprint("metrics", __name__)


def validate_metric(data):
    if not isinstance(data, dict):
        raise ValueError("Expected JSON object")
    for field in ("agent_id", "hostname"):
        if not isinstance(data.get(field), str) or not 1 <= len(data[field]) <= 128:
            raise ValueError(f"Invalid {field}")
    for field in ("cpu_usage", "memory_usage", "disk_usage", "network_in", "network_out", "uptime_seconds"):
        value = data.get(field)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError(f"Invalid {field}")
        if field.endswith("usage") and value > 100:
            raise ValueError(f"Invalid {field}")
        if field.startswith("network_") and (not isinstance(value, int) or value > 2**63-1):
            raise ValueError(f"Invalid {field}")
    timestamp = datetime.fromisoformat(data.get("collected_at", ""))
    if timestamp.tzinfo is None or abs((datetime.now(timezone.utc) - timestamp).total_seconds()) > 300:
        raise ValueError("Collection timestamp must be within five minutes of server time")


@bp.post("/api/v1/metrics")
def receive_metrics():
    data = request.get_json(silent=True)
    agent_id = data.get("agent_id") if isinstance(data, dict) else None
    expected = current_app.config["AGENT_TOKENS"].get(agent_id) if isinstance(agent_id, str) else None
    supplied = request.headers.get("Authorization", "")
    if not expected or not hmac.compare_digest(supplied, "Bearer " + expected):
        return jsonify(error="Agent authentication failed"), 401
    try:
        validate_metric(data)
    except (ValueError, TypeError):
        return jsonify(error="Invalid metric payload"), 400
    if current_app.config["METRICS_MEMORY_ONLY"] and current_app.testing:
        current_app.extensions["metric_spool"].append({**data, "received_at": datetime.now(timezone.utc).isoformat()})
        return jsonify(status="accepted", persistence="memory"), 202
    if "sqlalchemy" not in current_app.extensions:
        return jsonify(error="Database not configured"), 503
    from backend.services.monitoring_service import store_metric
    cached = store_metric(data, request.remote_addr or "unknown")
    return jsonify(status="accepted", persistence="mysql", cached=cached), 202
