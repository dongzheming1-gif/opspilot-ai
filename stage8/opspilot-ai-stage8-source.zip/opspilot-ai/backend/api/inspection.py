from flask import Blueprint, jsonify
from flask_jwt_extended import get_jwt_identity

from backend.api.auth import audit, roles_required
from backend.extensions import db
from backend.models import InspectionRun
from backend.services.inspection_service import run_inspection

bp = Blueprint("inspection", __name__, url_prefix="/api/v1/inspections")


def summary(run):
    report = run.report
    return {"id": run.id, "created_at": run.created_at.isoformat() + "Z",
            "status": run.status, "servers": report["servers"],
            "cluster": report["cluster"], "finding_count": report["finding_count"]}


@bp.get("")
@roles_required("admin", "operator", "viewer")
def list_runs():
    rows = db.session.execute(db.select(InspectionRun).order_by(
        InspectionRun.id.desc()).limit(50)).scalars().all()
    return jsonify(items=[summary(row) for row in rows])


@bp.get("/<int:run_id>")
@roles_required("admin", "operator", "viewer")
def detail(run_id):
    run = db.get_or_404(InspectionRun, run_id)
    return jsonify(item=summary(run), report=run.report)


@bp.post("")
@roles_required("admin", "operator")
def create_run():
    run = run_inspection()
    audit("inspection_run", f"inspection:{run.id}", run.status,
          int(get_jwt_identity()))
    db.session.commit()
    return jsonify(item=summary(run), report=run.report), 201
