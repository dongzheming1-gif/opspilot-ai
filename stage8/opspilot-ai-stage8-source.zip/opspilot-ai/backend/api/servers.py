from flask import Blueprint, current_app, jsonify, request
from flask_jwt_extended import jwt_required
from backend.extensions import db
from backend.models import Server, Metric
from backend.models.user import utcnow

bp = Blueprint("servers", __name__)


def metric_json(metric):
    return {"collected_at":metric.collected_at.isoformat()+"Z", **{key:getattr(metric,key) for key in
        ("cpu_usage","memory_usage","disk_usage","network_in","network_out","uptime_seconds")}}


@bp.get("/api/v1/servers")
@jwt_required()
def servers():
    rows = db.session.execute(db.select(Server).order_by(Server.id)).scalars().all()
    result = []
    for row in rows:
        metric = db.session.execute(db.select(Metric).filter_by(server_id=row.id).order_by(Metric.collected_at.desc()).limit(1)).scalar_one_or_none()
        result.append({"id":row.id, "agent_id":row.agent_id, "hostname":row.hostname, "ip_address":row.ip_address,
            "status":"online" if (utcnow()-row.last_heartbeat).total_seconds() < current_app.config["AGENT_OFFLINE_SECONDS"] else "offline",
            "last_heartbeat":row.last_heartbeat.isoformat()+"Z", "latest":metric_json(metric) if metric else None})
    return jsonify(items=result)


@bp.get("/api/v1/servers/<int:server_id>/metrics")
@jwt_required()
def metrics(server_id):
    db.get_or_404(Server, server_id)
    try:
        limit = min(max(int(request.args.get("limit", "240")), 1), 1000)
    except ValueError:
        return jsonify(error="limit must be an integer"), 400
    rows = db.session.execute(db.select(Metric).filter_by(server_id=server_id).order_by(Metric.collected_at.desc()).limit(limit)).scalars().all()
    return jsonify(items=[metric_json(row) for row in reversed(rows)])
