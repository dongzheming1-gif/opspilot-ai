"""Authenticated on-demand analysis and persistent history."""

from flask import Blueprint, current_app, jsonify, request
from flask_jwt_extended import get_jwt_identity, jwt_required

from backend.api.auth import audit, roles_required
from backend.extensions import db
from backend.models import Diagnosis
from backend.integrations.deepseek_client import analyze, DiagnosisError
from backend.services.diagnosis_service import server_context
from backend.services.cluster_diagnosis import cluster_context, validate_selection
from backend.services.docker_diagnosis import docker_context, validate_docker_selection

bp = Blueprint("diagnosis", __name__, url_prefix="/api/v1/diagnosis")


def serialize(record, detail=False):
    value = {"id": record.id, "resource": record.resource, "fault_type": record.fault_type,
             "severity": record.severity, "summary": record.summary,
             "created_at": record.created_at.isoformat() + "Z"}
    if detail:
        value["result"] = record.result
    return value


@bp.post("")
@roles_required("admin", "operator")
def create():
    data = request.get_json(silent=True)
    user_id = int(get_jwt_identity())
    resource = "diagnosis"
    try:
        if isinstance(data, dict) and data.get('source') == 'server':
            if set(data) != {'source', 'server_id'}:
                raise DiagnosisError('invalid_server_selection', 400)
            context = server_context(data["server_id"])
            resource = f"server:{data['server_id']}"
        elif isinstance(data, dict) and data.get('source') == 'docker':
            resource = validate_docker_selection(data)
            context = None
        else:
            resource = validate_selection(data)
            context = None
        if not current_app.config["DEEPSEEK_API_KEY"]:
            raise DiagnosisError("deepseek_not_configured", 503)
        cache = current_app.extensions.get("redis")
        if cache is None:
            raise DiagnosisError("diagnosis_rate_limiter_unavailable", 503)
        # Atomic counter + expiry; no immortal quota if the process dies between commands.
        count = cache.eval("local n=redis.call('INCR',KEYS[1]); if n==1 then redis.call('EXPIRE',KEYS[1],3600) end; return n",
                           1, f"diagnosis:quota:{user_id}")
        if count > current_app.config['DIAGNOSIS_HOURLY_LIMIT']:
            raise DiagnosisError("diagnosis_hourly_limit", 429)
        audit("diagnosis_requested", resource, user_id=user_id)
        db.session.commit()  # Establish an audit trail before the paid external call.
        if context is None:
            context = docker_context(current_app.config, data) if data['source'] == 'docker' else cluster_context(current_app.config, data)
        result = analyze(current_app.config, context)
        record = Diagnosis(fault_type=result["fault_type"], severity=result["severity"],
                           summary=result["summary"], resource=resource,
                           result={**result, "context": context, "model": current_app.config["DEEPSEEK_MODEL"]})
        db.session.add(record)
        audit("diagnosis", resource, user_id=user_id)
        db.session.commit()
        return jsonify(serialize(record, True)), 201
    except DiagnosisError as error:
        audit("diagnosis", resource, "failed", user_id=user_id)
        db.session.commit()
        return jsonify(error=error.code), error.status


@bp.get("")
@jwt_required()
def history():
    records = db.session.execute(db.select(Diagnosis).order_by(Diagnosis.id.desc()).limit(50)).scalars()
    return jsonify(items=[serialize(row) for row in records], limit=50)


@bp.get('/quota')
@jwt_required()
def quota():
    cache = current_app.extensions.get('redis')
    if cache is None:
        return jsonify(error='diagnosis_rate_limiter_unavailable'), 503
    key = f'diagnosis:quota:{get_jwt_identity()}'
    count = int(cache.get(key) or 0)
    limit = current_app.config['DIAGNOSIS_HOURLY_LIMIT']
    return jsonify(limit=limit, remaining=max(0,limit-count), retry_seconds=max(0,cache.ttl(key)))


@bp.get("/<int:record_id>")
@jwt_required()
def detail(record_id):
    record = db.session.get(Diagnosis, record_id)
    if record is None:
        return jsonify(error="diagnosis_not_found"), 404
    return jsonify(serialize(record, True))
