"use strict";
pages.docker={title:"Docker 独立引擎",render:renderDocker};
const dockerNav=element("button","▣　Docker 管理");
dockerNav.dataset.page="docker";
$("navigation").append(dockerNav);

async function renderDocker(){
  destroyCharts();
  const root=$("page-content");root.replaceChildren();
  const section=panel("独立 Docker Engine");root.append(section);
  section.append(element("p","Kubernetes 集群使用 containerd，请在集群页面查看 Pod。","muted"));
  let status;
  try{status=await api("/api/v1/docker/status");}
  catch(error){section.append(element("p",error.message,"alert alert-warning"));return;}
  section.append(element("p",`引擎版本 ${status.version} · ${status.actions_enabled?"受控管理已启用":"管理操作已关闭"}`,"muted"));
  const containers=(await api("/api/v1/docker/containers")).items;
  section.append(element("p","最多显示 200 个容器。只有明确授权的容器允许启停。","muted"));
  const output=element("pre",undefined,"resource-output");
  const rows=containers.map(container=>{
    const actions=element("div");
    const logs=element("button","日志","btn btn-sm btn-outline-secondary");
    logs.addEventListener("click",async()=>{try{const data=await api(`/api/v1/docker/containers/${container.id}/logs`);output.textContent=data.logs||"暂无日志";if(data.truncated)output.textContent+="\n[达到显示上限]";}catch(error){output.textContent=error.message;}});
    actions.append(logs);
    if(status.actions_enabled&&container.managed&&state.role==="admin"){
      for(const [action,label] of [["start","启动"],["stop","停止"]]){
        const button=element("button",label,"btn btn-sm btn-outline-secondary ms-2");
        button.addEventListener("click",async()=>{
          if(!window.confirm(`确认${label}容器 ${container.name}？`))return;
          button.disabled=true;
          try{await api(`/api/v1/docker/containers/${container.id}/${action}`,{method:"POST",body:JSON.stringify({confirm_container_id:container.id})});await refresh();}
          catch(error){output.textContent=error.message;}
          finally{button.disabled=false;}
        });actions.append(button);
      }
    }
    return [container.name,container.id.slice(0,12),container.image,container.status,container.managed?"已授权":"只读",actions];
  });
  section.append(table(["名称","ID","镜像","状态","管理范围","操作"],rows),output);
  const images=(await api("/api/v1/docker/images")).items;
  const imagePanel=panel("镜像列表");
  imagePanel.append(table(["镜像 ID","标签"],images.map(i=>[i.id,i.tags.join(", ")||"无标签"])));
  root.append(imagePanel);
}
