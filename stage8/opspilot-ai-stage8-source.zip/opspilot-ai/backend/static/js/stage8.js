"use strict";

const stage8State = {alertStatus: "", inspectionId: null};
const stage8Pages = [
  ["alerts", "告警管理", renderAlerts],
  ["inspections", "自动巡检", renderInspections],
  ["audit", "操作审计", renderAudit],
];
for (const [key, title, render] of stage8Pages) {
  pages[key] = {title, render};
  const button = element("button", `◇　${title}`);
  button.dataset.page = key;
  if (key === "audit") button.hidden = true;
  $("navigation").append(button);
}

function stage8Date(value) {
  return value ? new Date(value).toLocaleString() : "—";
}
function stage8Status(value) {
  return ({open: "未处理", acknowledged: "已确认", closed: "已关闭",
           complete: "完整", partial: "部分完成"})[value] || value;
}
function stage8Action(label, callback) {
  const button = element("button", label, "btn btn-sm btn-outline-secondary me-2");
  button.addEventListener("click", async () => {
    button.disabled = true;
    try { await callback(); await refresh(); }
    catch (error) { showError(error); button.disabled = false; }
  });
  return button;
}

async function renderAlerts() {
  destroyCharts();
  const root = $("page-content"); root.replaceChildren();
  const section = panel("告警历史（最近 200 条）"); root.append(section);
  const filter = element("select", undefined, "form-select mb-3");
  filter.setAttribute("aria-label", "告警状态筛选");
  for (const [value, label] of [["", "全部状态"], ["open", "未处理"],
                               ["acknowledged", "已确认"], ["closed", "已关闭"]]) {
    const option = element("option", label); option.value = value;
    option.selected = value === stage8State.alertStatus; filter.append(option);
  }
  filter.addEventListener("change", () => {stage8State.alertStatus = filter.value; refresh();});
  section.append(filter);
  const suffix = stage8State.alertStatus ? `?status=${stage8State.alertStatus}` : "";
  const items = (await api(`/api/v1/alerts${suffix}`)).items;
  section.append(table(["时间", "级别", "来源", "对象", "类型", "说明", "状态", "处理"],
    items.map(a => {
      const actions = element("span");
      if (["admin", "operator"].includes(state.role) && a.status !== "closed") {
        if (a.status === "open") actions.append(stage8Action("确认", () =>
          api(`/api/v1/alerts/${a.id}/acknowledge`, {method: "POST"})));
        actions.append(stage8Action("关闭", () =>
          api(`/api/v1/alerts/${a.id}/close`, {method: "POST"})));
      }
      return [stage8Date(a.created_at), a.severity, a.source, a.resource_name,
              a.alert_type, a.message, stage8Status(a.status), actions];
    })));
}

async function renderInspections() {
  destroyCharts();
  const root = $("page-content"); root.replaceChildren();
  const section = panel("只读巡检报告"); root.append(section);
  section.append(element("p", "检查主机指标、Agent 心跳、Node、Pod 与 Warning Events；不执行集群写入。", "muted"));
  if (["admin", "operator"].includes(state.role)) {
    section.append(stage8Action("立即巡检", async () => {
      const response = await api("/api/v1/inspections", {method: "POST", timeoutMs: 60000});
      stage8State.inspectionId = response.item.id;
    }));
  }
  const items = (await api("/api/v1/inspections")).items;
  section.append(table(["执行时间", "结果", "主机", "Node / Pod", "异常条目", "报告"],
    items.map(item => [stage8Date(item.created_at), stage8Status(item.status), item.servers,
      `${item.cluster.nodes} / ${item.cluster.pods}`, item.finding_count,
      stage8Action("查看", async () => {stage8State.inspectionId = item.id;})])));
  if (stage8State.inspectionId) {
    const detail = await api(`/api/v1/inspections/${stage8State.inspectionId}`);
    const report = detail.report;
    const reportPanel = panel(`巡检 #${detail.item.id} · ${stage8Status(report.status)}`);
    reportPanel.append(element("p", `检查时间：${stage8Date(report.checked_at)}；集群查询：${report.cluster.status === "ok" ? "成功" : "不可用"}；检查结果 ${report.finding_count} 条${report.findings_truncated ? "（仅显示前 500 条）" : ""}`));
    if (report.cluster.error_category)
      reportPanel.append(element("p", `集群查询失败类型：${report.cluster.error_category}`, "text-danger"));
    reportPanel.append(table(["来源", "对象", "类型", "检查结果"],
      report.findings.map(f => [f.source, f.resource, f.kind, f.message])));
    root.append(reportPanel);
  }
}

async function renderAudit() {
  destroyCharts();
  const root = $("page-content"); root.replaceChildren();
  const section = panel("最近 200 条操作审计"); root.append(section);
  const items = (await api("/api/v1/audit-logs")).items;
  section.append(table(["时间", "用户", "操作", "对象", "结果", "来源 IP"],
    items.map(a => [stage8Date(a.created_at), a.user || "系统/未识别",
      a.action, a.resource, a.result, a.source_ip || "—"])));
}
