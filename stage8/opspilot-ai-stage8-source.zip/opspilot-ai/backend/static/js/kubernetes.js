"use strict";
const clusterState = { namespace: "", pod: null };
const clusterKinds = {
  nodes: "Node 节点", pods: "Pod 工作负载", deployments: "Deployment", services: "Service 服务",
  namespaces: "Namespace", events: "Events 事件"
};
for (const [kind, title] of Object.entries(clusterKinds)) {
  pages[`k8s-${kind}`] = {title, render: () => renderCluster(kind)};
  const button = element("button", `◇　${title}`);
  button.dataset.page = `k8s-${kind}`;
  $("navigation").append(button);
}
pages.podlogs = {title: "Pod 日志", render: renderPodLogs};

async function appendClusterSummary(root) {
  const section = panel("Kubernetes 集群概况");
  root.prepend(section);
  try {
    const summary = await api("/api/v1/kubernetes/summary");
    const stats = element("div", undefined, "stat-grid");
    for (const [label,value] of [["节点总数",summary.nodes],["Ready 节点",summary.ready_nodes],["Pod 总数",summary.pods],["异常 Pod",summary.abnormal_pods]]) {
      const card=element("div",undefined,"stat");
      card.append(element("div",label,"stat-label"),element("div",value,"stat-value"));
      stats.append(card);
    }
    section.append(stats);
  } catch(error) { section.append(element("p",error.message,"text-danger")); }
}

async function renderCluster(kind) {
  destroyCharts();
  const root=$("page-content");
  root.replaceChildren();
  const section=panel(clusterKinds[kind]);
  root.append(section);
  const filter=element("div",undefined,"filter-bar");
  if (!["nodes","namespaces"].includes(kind)) {
    const namespaces=(await api("/api/v1/kubernetes/namespaces")).items;
    const select=element("select",undefined,"form-select");
    select.setAttribute("aria-label","Namespace 筛选");
    const all=element("option","所有 Namespace");all.value="";select.append(all);
    namespaces.forEach(ns=>{const option=element("option",ns.name);option.value=ns.name;option.selected=ns.name===clusterState.namespace;select.append(option);});
    select.addEventListener("change",()=>{clusterState.namespace=select.value;refresh();});
    filter.append(select);
  }
  filter.append(element("span","只读访问 · 不修改集群资源","muted"));
  section.append(filter);
  const suffix=clusterState.namespace?`?namespace=${encodeURIComponent(clusterState.namespace)}`:"";
  const response=await api(`/api/v1/kubernetes/${kind}${suffix}`);
  const items=response.items;
  if(response.truncated) section.append(element("p",`显示最近 ${items.length} 条，共 ${response.total} 条；可按 Namespace 缩小范围。`,"muted"));
  let headers,rows;
  if(kind==="nodes") {
    headers=["节点","IP","状态","角色","Kubernetes","运行时","容量 / 可分配"];
    rows=items.map(n=>[n.name,n.ip,n.ready?"Ready":"NotReady",n.roles.join(", ")||"worker",n.version,n.runtime,
      `CPU ${n.capacity?.cpu} / ${n.allocatable?.cpu}; 内存 ${n.capacity?.memory} / ${n.allocatable?.memory}; Pod ${n.capacity?.pods} / ${n.allocatable?.pods}`]);
  } else if(kind==="pods") {
    headers=["Pod","Namespace","节点 / IP","阶段","重启","异常 / 容器","日志"];
    rows=items.map(p=>{const button=element("button","查看日志","link-button");button.addEventListener("click",()=>{clusterState.pod=p;state.page="podlogs";refresh();});return[p.name,p.namespace,`${p.node||"未调度"} / ${p.ip||"—"}`,p.phase,p.restarts,p.anomalies.join(", ")||p.containers.map(c=>`${c.name}: ${c.ready?"Ready":"NotReady"}`).join("; "),button];});
  } else if(kind==="deployments") {
    headers=["Deployment","Namespace","期望副本","可用副本","就绪副本","条件"];
    rows=items.map(d=>[d.name,d.namespace,d.desired,d.available,d.ready,d.conditions.map(c=>`${c.type}=${c.status} (${c.reason||""})`).join("; ")]);
  } else if(kind==="services") {
    headers=["Service","Namespace","类型","Cluster IP","端口"];
    rows=items.map(s=>[s.name,s.namespace,s.type,s.cluster_ip,s.ports.map(p=>`${p.port} → ${p.target_port}/${p.protocol}${p.node_port?` NodePort:${p.node_port}`:""}`).join("; ")]);
  } else if(kind==="namespaces") { headers=["Namespace","状态"];rows=items.map(n=>[n.name,n.status]); }
  else {headers=["时间","类型","原因","Namespace / 资源","详情","次数"];rows=items.map(e=>[e.time?new Date(e.time).toLocaleString():"—",element("span",e.type,e.type==="Warning"?"badge status-offline":"badge status-online"),e.reason,`${e.namespace} / ${e.resource}`,e.message,e.count]);}
  section.append(table(headers,rows));
}

async function renderPodLogs() {
  destroyCharts();const root=$("page-content");root.replaceChildren();const p=clusterState.pod;
  if(!p){root.append(element("p","请先选择 Pod","empty"));return;}
  const section=panel(`${p.namespace} / ${p.name}`);root.append(section);
  const filters=element("div",undefined,"filter-bar");const select=element("select",undefined,"form-select");
  select.setAttribute("aria-label","日志容器");
  p.containers.forEach(c=>{const option=element("option",c.name);option.value=c.name;select.append(option);});
  const previous=element("input");previous.type="checkbox";previous.id="previous-log";
  const label=element("label","上一次终止的容器");label.htmlFor="previous-log";
  const load=element("button","读取日志","btn btn-outline-secondary");
  const output=element("pre","正在读取…","resource-output");
  async function read(){load.disabled=true;try {const data=await api(`/api/v1/kubernetes/pods/${encodeURIComponent(p.namespace)}/${encodeURIComponent(p.name)}/logs?container=${encodeURIComponent(select.value)}&previous=${previous.checked}`);output.textContent=data.logs||"容器暂未输出日志";}catch(error){output.textContent=error.message;}finally{load.disabled=false;}}
  load.addEventListener("click",read);filters.append(select,previous,label,load);section.append(filters,element("p","最多显示最近 200 行 / 32 KiB","muted"),output);await read();
}
