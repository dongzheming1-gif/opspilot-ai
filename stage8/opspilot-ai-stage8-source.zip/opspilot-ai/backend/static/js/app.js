"use strict";
const state = {
  token: null,
  page: "overview",
  servers: [],
  selected: null,
  charts: [],
  busy: false,
};
const $ = (id) => document.getElementById(id);
function element(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (className) node.className = className;
  return node;
}
async function api(path, options = {}) {
  const { timeoutMs = 15000, ...fetchOptions } = options;
  const response = await fetch(path, {
    ...fetchOptions,
    headers: {
      "Content-Type": "application/json",
      ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}),
      ...options.headers,
    },
    signal: AbortSignal.timeout(timeoutMs),
  });
  let data;
  try {
    data = await response.json();
  } catch {
    throw Error("服务返回了无法识别的响应");
  }
  if (!response.ok) {
    if (response.status === 401 && state.token) {
      state.token = null;
      showLogin();
    }
    throw Error(data.error || data.msg || `请求失败 (${response.status})`);
  }
  return data;
}
function showLogin() {
  state.token = null;
  if (typeof resetDiagnosis === "function") resetDiagnosis();
  $("workspace").hidden = true;
  $("login-screen").hidden = false;
  destroyCharts();
}
function destroyCharts() {
  state.charts.forEach((c) => c.destroy());
  state.charts = [];
}
function showError(error) {
  $("error-banner").textContent = error.message || String(error);
  $("error-banner").hidden = false;
}
function panel(title) {
  const node = element("section", undefined, "panel");
  const head = element("div", undefined, "panel-heading");
  head.append(element("h2", title));
  node.append(head);
  return node;
}
function table(headers, rows) {
  const wrap = element("div", undefined, "table-responsive");
  const node = element("table", undefined, "table");
  const head = element("thead");
  const tr = element("tr");
  headers.forEach((h) => tr.append(element("th", h)));
  head.append(tr);
  node.append(head);
  const body = element("tbody");
  rows.forEach((row) => {
    const tr = element("tr");
    row.forEach((value) => {
      const td = element("td");
      if (value instanceof Node) td.append(value);
      else td.textContent = value ?? "—";
      tr.append(td);
    });
    body.append(tr);
  });
  node.append(body);
  wrap.append(node);
  if (!rows.length) wrap.append(element("p", "暂无数据", "empty"));
  return wrap;
}
function pct(value) {
  return Number.isFinite(value) ? value.toFixed(1) + "%" : "—";
}
function serverTable() {
  const node = panel("Linux 服务器");
  node.append(
    table(
      ["主机", "状态", "CPU", "内存", "磁盘", "最近心跳", ""],
      state.servers.map((s) => {
        const badge = element(
          "span",
          s.status === "online" ? "在线" : "离线",
          `badge status-${s.status}`,
        );
        const button = element("button", "查看详情 →", "link-button");
        button.addEventListener("click", () => {
          state.selected = s.id;
          state.page = "detail";
          refresh();
        });
        return [
          element("span", s.hostname, "host-name"),
          badge,
          pct(s.latest?.cpu_usage),
          pct(s.latest?.memory_usage),
          pct(s.latest?.disk_usage),
          new Date(s.last_heartbeat).toLocaleTimeString(),
          button,
        ];
      }),
    ),
  );
  return node;
}
async function monitoring() {
  state.servers = (await api("/api/v1/servers")).items;
  const root = $("page-content");
  root.replaceChildren();
  destroyCharts();
  if (state.page === "overview") {
    const stats = element("div", undefined, "stat-grid");
    [
      ["服务器总数", state.servers.length, "已注册的真实主机"],
      [
        "在线主机",
        state.servers.filter((s) => s.status === "online").length,
        "最近一分钟收到心跳",
      ],
      [
        "离线主机",
        state.servers.filter((s) => s.status !== "online").length,
        "请检查 Agent 与网络",
      ],
    ].forEach(([label, value, note]) => {
      const card = element("div", undefined, "stat");
      card.append(
        element("div", label, "stat-label"),
        element("div", value, "stat-value"),
        element("div", note, "stat-note"),
      );
      stats.append(card);
    });
    root.append(stats);
  }
  root.append(serverTable());
  if (state.page === "overview" && typeof appendClusterSummary === "function") {
    await appendClusterSummary(root);
  }
  if (state.page !== "servers" && state.servers.length) {
    if (!state.servers.some((s) => s.id === state.selected))
      state.selected = state.servers[0].id;
    const selected = state.servers.find((s) => s.id === state.selected);
    const chartPanel = panel("主机资源趋势");
    const select = element("select", undefined, "form-select");
    select.setAttribute("aria-label", "选择监控主机");
    state.servers.forEach((s) => {
      const option = element("option", s.hostname);
      option.value = s.id;
      option.selected = s.id === state.selected;
      select.append(option);
    });
    select.addEventListener("change", () => {
      state.selected = Number(select.value);
      refresh();
    });
    chartPanel.firstChild.append(select);
    const grid = element("div", undefined, "charts");
    chartPanel.append(grid);
    root.append(chartPanel);
    const history = (
      await api(`/api/v1/servers/${selected.id}/metrics?limit=120`)
    ).items;
    if (!history.length) {
      grid.append(element("p", "尚无历史指标", "empty"));
      return;
    }
    for (const [field, title, color] of [
      ["cpu_usage", "CPU 使用率", "#4263eb"],
      ["memory_usage", "内存使用率", "#15a58e"],
      ["disk_usage", "根分区使用率", "#b58b35"],
    ]) {
      const box = element("div", undefined, "chart-panel");
      box.append(element("h3", title));
      const chartBox = element("div", undefined, "chart-box");
      const canvas = element("canvas");
      canvas.setAttribute("aria-label", `${selected.hostname} ${title}`);
      chartBox.append(canvas);
      box.append(chartBox);
      grid.append(box);
      state.charts.push(
        new Chart(canvas, {
          type: "line",
          data: {
            labels: history.map((m) =>
              new Date(m.collected_at).toLocaleTimeString(),
            ),
            datasets: [
              {
                data: history.map((m) => m[field]),
                borderColor: color,
                borderWidth: 2,
                pointRadius: 0,
                tension: 0.25,
                fill: false,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            plugins: { legend: { display: false } },
            scales: {
              y: {
                min: 0,
                max: 100,
                ticks: { stepSize: 25 },
                grid: { color: "#edf1f6" },
              },
              x: {
                ticks: { maxTicksLimit: 4, maxRotation: 0 },
                grid: { display: false },
              },
            },
          },
        }),
      );
    }
  }
}
const pages = {
  overview: { title: "监控总览", render: monitoring },
  servers: { title: "Linux 服务器", render: monitoring },
  detail: { title: "服务器详情", render: monitoring },
};
async function refresh() {
  if (!state.token || state.busy || state.diagnosing) return;
  state.busy = true;
  $("refresh").disabled = true;
  $("error-banner").hidden = true;
  try {
    const page = pages[state.page];
    $("page-title").textContent = page.title;
    $("breadcrumb").textContent = page.title;
    $("page-description").textContent = state.page === "diagnosis" ? "从真实采样出发，区分事实证据与待验证的原因。" : "从实时指标开始，掌握基础设施的每一次变化。";
    $("refresh-note").textContent = state.page === "diagnosis" ? "诊断页手动刷新 · 不会自动发起诊断" : "每 15 秒刷新 · 所有时间按本地时区显示";
    document
      .querySelectorAll("nav button")
      .forEach((b) =>
        b.classList.toggle("active", b.dataset.page === state.page),
      );
    await page.render();
    $("updated").textContent = "最后更新 " + new Date().toLocaleString();
  } catch (error) {
    showError(error);
  } finally {
    state.busy = false;
    $("refresh").disabled = false;
  }
}
$("navigation").addEventListener("click", (event) => {
  const button = event.target.closest("button[data-page]");
  if (button && !state.busy && !state.diagnosing) {
    state.page = button.dataset.page;
    refresh();
  }
});
$("refresh").addEventListener("click", refresh);
$("login-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.currentTarget.querySelector("button");
  button.disabled = true;
  $("login-error").textContent = "";
  try {
    const user = await api("/api/v1/auth/login", {
      method: "POST",
      body: JSON.stringify({
        username: $("username").value,
        password: $("password").value,
      }),
    });
    state.token = user.access_token;
    state.role = user.role;
    const auditNav = document.querySelector('nav button[data-page="audit"]');
    if (auditNav) auditNav.hidden = user.role !== "admin";
    $("password").value = "";
    $("current-user").textContent = user.username + " · " + user.role;
    $("login-screen").hidden = true;
    $("workspace").hidden = false;
    await refresh();
  } catch (error) {
    $("login-error").textContent = error.message;
  } finally {
    button.disabled = false;
  }
});
$("logout").addEventListener("click", async () => {
  try {
    await api("/api/v1/auth/logout", { method: "POST" });
    showLogin();
  } catch (error) {
    showError(error);
  }
});
setInterval(() => {
  if (!document.hidden && state.page !== "diagnosis") refresh();
}, 15000);
