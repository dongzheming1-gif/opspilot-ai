"use strict";
pages.diagnosis = { title: "AI 故障诊断", render: renderDiagnosis };
const diagnosisNav = element("button", "◇　AI 故障诊断");
diagnosisNav.dataset.page = "diagnosis";
$("navigation").append(diagnosisNav);
const diagnosisState = { source: "server", selection: "", record: null, generation: 0 };
function resetDiagnosis() {
  diagnosisState.generation++;
  diagnosisState.record = null;
  diagnosisState.selection = "";
  state.diagnosing = false;
  $("navigation").querySelectorAll("button").forEach(b => b.disabled = false);
  $("refresh").disabled = false;
}
const diagnosisErrors = {
  docker_not_configured: "独立 Docker Engine 尚未配置。",
  docker_connection_failed: "Docker 连接失败，请检查服务和 TLS 配置。",
  container_not_found: "容器已不存在，请刷新资源列表。",
  "Kubernetes configuration, TLS or network unavailable": "集群连接暂不可用，请检查网络后点击“刷新数据”重试。",
  "Kubernetes credential expired or invalid": "集群只读凭据已失效，请更新配置。",
  metrics_stale: "指标已过期，请检查 Agent 上报后再诊断。",
  metrics_unavailable: "该主机尚无指标。", resource_not_found: "资源已不存在，请刷新资源列表。",
  diagnosis_hourly_limit: "本小时诊断尝试已达上限，请稍后再试。已有结果仍可查看。",
  deepseek_not_configured: "尚未配置 DeepSeek API Key。",
  deepseek_auth_failed: "DeepSeek 认证失败，请检查服务端 Key 配置。",
  deepseek_insufficient_balance: "DeepSeek 账户余额不足。",
  deepseek_network_error: "模型请求中断，未自动重试。请先刷新历史，确认是否已有结果。",
  deepseek_invalid_response: "模型输出未通过校验，未保存为成功诊断。",
  deepseek_incomplete_response: "模型输出不完整，未保存为成功诊断。",
  kubernetes_credentials_invalid: "集群凭据失效，请更新只读凭据。",
  kubernetes_permission_denied: "只读身份缺少查询权限。",
  kubernetes_configuration_or_network_error: "集群连接不可用，请检查网络与只读配置。",
};
function diagnosisError(error) {
  if (["TimeoutError", "AbortError", "TypeError"].includes(error.name))
    return "请求超时或连接中断，服务端可能仍在处理。请先刷新历史核实，不要立即重复提交。";
  return diagnosisErrors[error.message] || error.message;
}
function diagnosisDetail(record, target) {
  target.replaceChildren();
  const result = record.result;
  const summary = panel("诊断结果");
  summary.append(element("p", `${record.resource} · ${new Date(record.created_at).toLocaleString()} · ${result.model}`, "muted"));
  const levels = { info: "提示", warning: "警告", critical: "严重" };
  summary.append(element("h3", `${levels[record.severity] || record.severity} · ${record.fault_type}`), element("p", record.summary));
  target.append(summary);
  const facts = panel("事实证据 · 采集快照");
  facts.append(element("p", `采集时间：${new Date(result.context.collected_at).toLocaleString()}；模型引用：${result.evidence.join("、")}`, "muted"));
  for (const item of result.context.evidence) {
    facts.append(element("h3", item.id), element("pre", JSON.stringify(item.observation, null, 2), "resource-output"));
  }
  const limits = {
    isolated_test_filesystem_not_host_root: "隔离测试文件系统，不是节点根分区",
    test_already_cleaned_up: "测试资源已清理，此记录为测试时的采样分析",
    single_sample: "仅一个采样点", single_snapshot: "仅一次快照", no_process_details: "无进程明细",
    no_raw_logs: "未提供原始日志", raw_text_omitted: "原始文本已省略", events_may_be_historical: "事件可能为历史记录",
    one_container_only: "仅采集一个容器", logs_tail_200_lines_32KiB: "日志最多 200 行 / 32 KiB",
    log_signals_not_root_cause: "日志特征不能直接证明根因", events_unavailable: "事件未能读取",
    current_logs_unavailable: "当前日志未能读取", previous_logs_unavailable: "上次日志未能读取",
    container_logs_unavailable: "容器日志不可用",
  };
  facts.append(element("p", "证据限制：" + result.context.limitations.map(v => limits[v] || v).join("；"), "alert alert-warning"));
  target.append(facts);
  for (const [key, title] of [["possible_causes", "可能原因 · 尚待验证"], ["troubleshooting_steps", "只读排查步骤"],
    ["recommendations", "处理建议 · 需人工评估"], ["prevention", "预防建议"]]) {
    const section = panel(title), list = element("ol");
    result[key].forEach(text => list.append(element("li", text)));
    section.append(list); target.append(section);
  }
}
async function renderDiagnosis() {
  destroyCharts();
  const generation = ++diagnosisState.generation, token = state.token;
  const root = $("page-content"); root.replaceChildren();
  const current = () => generation === diagnosisState.generation && state.token === token && state.page === "diagnosis";
  const form = panel("发起诊断"), output = element("div"), history = panel("诊断历史 · 最近 50 条");
  root.append(form, output, history);
  form.append(element("p", "仅发送筛选后的指标、状态与日志特征。AI 提供分析建议，不会执行操作。", "muted"));
  const quotaNote = element("p", "正在读取诊断额度…", "muted"); form.append(quotaNote);
  async function loadQuota() {
    try { const quota = await api('/api/v1/diagnosis/quota'); if(current()) quotaNote.textContent = `每小时最多 ${quota.limit} 次尝试 · 剩余 ${quota.remaining} 次`; }
    catch { if(current()) quotaNote.textContent = "诊断额度暂时无法读取，提交时由服务端校验。"; }
  }
  loadQuota();
  const source = element("select", undefined, "form-select mb-3"); source.id = "diagnosis-source";
  for (const [value, label] of [["server", "Linux 主机"], ["pod", "Kubernetes Pod"], ["node", "Kubernetes Node"], ["docker", "Docker 独立容器"]]) {
    const option = element("option", label); option.value = value; source.append(option);
  }
  source.value = diagnosisState.source;
  const resource = element("select", undefined, "form-select mb-3"); resource.id = "diagnosis-resource";
  const label = element("label", "资源类型", "form-label"); label.htmlFor = source.id;
  const resourceLabel = element("label", "诊断对象（Pod 显示命名空间）", "form-label"); resourceLabel.htmlFor = resource.id;
  const submit = element("button", "开始 AI 诊断", "btn btn-primary"); submit.id = "diagnosis-submit";
  const message = element("p", "", "mt-3"); message.setAttribute("role", "status"); message.setAttribute("aria-live", "polite");
  form.append(label, source, resourceLabel, resource, submit, message);
  const allowed = ["admin", "operator"].includes(state.role);
  if (!allowed) form.append(element("p", "当前账号可查看历史；发起诊断需要管理员或操作员权限。", "muted"));
  let choices = [], loading = false, sequence = 0, detailSequence = 0;
  async function loadResources() {
    const request = ++sequence; loading = true; submit.disabled = true; resource.disabled = true;
    resource.replaceChildren(element("option", "正在读取真实资源…")); message.textContent = "";
    const kind = source.value;
    try {
      const path = kind === "server" ? "/api/v1/servers" : kind === "docker" ? "/api/v1/docker/containers" : `/api/v1/kubernetes/${kind === "pod" ? "pods" : "nodes"}`;
      const data = await api(path);
      if (!current() || request !== sequence) return;
      choices = data.items.map(item => ({
        key: ["server", "docker"].includes(kind) ? String(item.id) : `${item.namespace || ""}/${item.name}`,
        label: kind === "server" ? `${item.hostname} · ${item.status === "online" ? "在线" : "离线"}` : `${item.namespace ? item.namespace + " / " : ""}${item.name}`,
        body: kind === "server" ? { source: kind, server_id: item.id } : kind === "docker" ? {source:kind, container_id:item.id} : { source: kind, name: item.name, ...(kind === "pod" ? { namespace: item.namespace } : {}) },
      }));
      resource.replaceChildren();
      choices.forEach(item => { const option = element("option", item.label); option.value = item.key; resource.append(option); });
      if (!choices.length) resource.append(element("option", "没有可诊断的资源"));
      if (choices.some(item => item.key === diagnosisState.selection)) resource.value = diagnosisState.selection;
      resource.disabled = !choices.length;
    } catch (error) {
      if (!current() || request !== sequence) return;
      choices = []; resource.replaceChildren(element("option", "资源读取失败")); message.textContent = diagnosisError(error);
    } finally {
      if (current() && request === sequence) { loading = false; submit.disabled = !allowed || !choices.length; }
    }
  }
  source.addEventListener("change", () => { diagnosisState.source = source.value; diagnosisState.selection = ""; loadResources(); });
  resource.addEventListener("change", () => diagnosisState.selection = resource.value);
  async function loadHistory() {
    const data = await api("/api/v1/diagnosis");
    if (!current()) return;
    history.querySelector(".history-body")?.remove();
    const body = element("div", undefined, "history-body");
    body.append(table(["时间", "资源", "诊断", "等级", ""], data.items.map(item => {
      const button = element("button", "查看详情", "btn btn-sm btn-outline-secondary");
      button.addEventListener("click", async () => {
        if (state.diagnosing) return;
        const detailRequest = ++detailSequence;
        button.disabled = true;
        try { const record = await api(`/api/v1/diagnosis/${item.id}`); if (current() && detailRequest === detailSequence && !state.diagnosing) { diagnosisState.record = record; diagnosisDetail(record, output); } }
        catch (error) { if (current()) message.textContent = diagnosisError(error); }
        finally { button.disabled = false; }
      });
      return [new Date(item.created_at).toLocaleString(), item.resource, item.fault_type, item.severity, button];
    })));
    history.append(body);
  }
  submit.addEventListener("click", async () => {
    if (!allowed || loading || state.diagnosing || !current()) return;
    const selection = choices.find(item => item.key === resource.value); if (!selection) return;
    diagnosisState.selection = resource.value;
    detailSequence++;
    state.diagnosing = true; submit.disabled = source.disabled = resource.disabled = true;
    $("refresh").disabled = true; $("navigation").querySelectorAll("button").forEach(b => b.disabled = true);
    message.textContent = "正在采集证据并分析，可能需要约两分钟。请勿重复提交。";
    try {
      const record = await api("/api/v1/diagnosis", { method: "POST", body: JSON.stringify(selection.body), timeoutMs: 180000 });
      if (!current()) return;
      diagnosisState.record = record; diagnosisDetail(record, output);
      message.textContent = "诊断已保存。请结合事实证据验证推测原因。";
      try { await loadHistory(); } catch { message.textContent += " 历史刷新失败，可稍后刷新查看。"; }
    } catch (error) { if (current()) message.textContent = diagnosisError(error); }
    finally {
      if (current()) {
        loadQuota();
        state.diagnosing = false; submit.disabled = false; source.disabled = resource.disabled = false;
        $("refresh").disabled = false; $("navigation").querySelectorAll("button").forEach(b => b.disabled = false);
      }
    }
  });
  if (diagnosisState.record) diagnosisDetail(diagnosisState.record, output);
  await Promise.all([loadResources(), loadHistory().catch(error => { if (current()) history.append(element("p", diagnosisError(error), "alert alert-warning")); })]);
}
