"""Validate the model's untrusted response before storing it."""

TEXT_FIELDS = {"fault_type": 128, "summary": 1500}
LIST_FIELDS = ("evidence", "possible_causes", "troubleshooting_steps", "recommendations", "prevention")


def validate_result(value, evidence_ids):
    expected = set(TEXT_FIELDS) | set(LIST_FIELDS) | {"severity"}
    if not isinstance(value, dict) or set(value) != expected:
        raise ValueError("Invalid diagnosis fields")
    for field, limit in TEXT_FIELDS.items():
        if not isinstance(value[field], str) or not 1 <= len(value[field].strip()) <= limit:
            raise ValueError("Invalid diagnosis text")
    if not isinstance(value["severity"], str) or value["severity"] not in {"info", "warning", "critical"}:
        raise ValueError("Invalid severity")
    for field in LIST_FIELDS:
        items = value[field]
        if not isinstance(items, list) or not 1 <= len(items) <= 12:
            raise ValueError("Invalid diagnosis list")
        if any(not isinstance(item, str) or not 1 <= len(item.strip()) <= 1500 for item in items):
            raise ValueError("Invalid diagnosis item")
    if not set(value["evidence"]).issubset(evidence_ids):
        raise ValueError("Unknown evidence reference")
    return value
