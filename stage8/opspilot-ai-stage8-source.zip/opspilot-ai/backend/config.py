"""Environment configuration, without credentials in source code."""

import os
import json
import math
from pathlib import Path
from datetime import timedelta

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent


def percentage_setting(name: str, default: float) -> float:
    value = float(os.getenv(name, str(default)))
    if not math.isfinite(value) or not 0 <= value <= 100:
        raise ValueError(f"{name} must be between 0 and 100")
    return value


def load_config() -> dict:
    """Real environment variables take precedence over the local .env file."""
    load_dotenv(ROOT / ".env", override=False)
    return {
        "SECRET_KEY": os.getenv("SECRET_KEY") or None,
        "DEBUG": False,
        "TRUST_PROXY_COUNT": int(os.getenv("TRUST_PROXY_COUNT", "0")),
        "DEEPSEEK_API_KEY": os.getenv("DEEPSEEK_API_KEY", ""),
        "DEEPSEEK_MODEL": os.getenv("DEEPSEEK_MODEL", "deepseek-flash"),
        "DIAGNOSIS_HOURLY_LIMIT": max(1, min(100, int(os.getenv("DIAGNOSIS_HOURLY_LIMIT", "5")))),
        "K8S_KUBECONFIG": os.getenv("K8S_KUBECONFIG", ""),
        "DOCKER_HOST": os.getenv("DOCKER_HOST", ""),
        "DOCKER_CA_FILE": os.getenv("DOCKER_CA_FILE", ""),
        "DOCKER_CERT_FILE": os.getenv("DOCKER_CERT_FILE", ""),
        "DOCKER_KEY_FILE": os.getenv("DOCKER_KEY_FILE", ""),
        "DOCKER_ACTIONS_ENABLED": os.getenv("DOCKER_ACTIONS_ENABLED", "false").lower() == "true",
        "AGENT_TOKENS": json.loads(os.getenv("AGENT_TOKENS", "{}")),
        "SQLALCHEMY_DATABASE_URI": os.getenv("DATABASE_URL") or None,
        "SQLALCHEMY_ENGINE_OPTIONS": {"pool_pre_ping": True},
        "SQLALCHEMY_TRACK_MODIFICATIONS": False,
        "REDIS_URL": os.getenv("REDIS_URL") or None,
        "REDIS_CA_FILE": os.getenv("REDIS_CA_FILE") or None,
        "JWT_ACCESS_TOKEN_EXPIRES": timedelta(minutes=30),
        "JWT_TOKEN_LOCATION": ["headers"],
        "METRICS_MEMORY_ONLY": False,
        "METRIC_RETENTION_DAYS": int(os.getenv("METRIC_RETENTION_DAYS", "7")),
        "AGENT_OFFLINE_SECONDS": int(os.getenv("AGENT_OFFLINE_SECONDS", "60")),
        "POD_PENDING_SECONDS": int(os.getenv("POD_PENDING_SECONDS", "300")),
        "ALERT_CPU_THRESHOLD": percentage_setting("ALERT_CPU_THRESHOLD", 80),
        "ALERT_MEMORY_THRESHOLD": percentage_setting("ALERT_MEMORY_THRESHOLD", 85),
        "ALERT_DISK_THRESHOLD": percentage_setting("ALERT_DISK_THRESHOLD", 90),
        "MAX_CONTENT_LENGTH": 1024 * 1024,
    }
