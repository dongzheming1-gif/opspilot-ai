"""Repeatable real-cluster acceptance. Never prints tokens or log contents."""

from pathlib import Path
import json
import click
from flask_jwt_extended import create_access_token

from backend.extensions import db
from backend.models import User, AuditLog


def register_validation(app):
    @app.cli.command("verify-kubernetes")
    @click.option("--username", default="admin", help="Existing local user used for API acceptance")
    @click.option("--expected-nodes", type=click.IntRange(min=1), default=None)
    @click.option("--output", type=click.Path(path_type=Path), default=None)
    def verify_kubernetes(username, expected_nodes, output):
        """Check authenticated routes, real resources, logs and persisted audit."""
        user=db.session.execute(db.select(User).filter_by(username=username)).scalar_one_or_none()
        if user is None:
            raise click.ClickException("Create the specified local user first")
        client=app.test_client()
        token=create_access_token(identity=str(user.id))
        headers={"Authorization":"Bearer "+token}
        report={"source":"real Kubernetes API via Flask test client", "resources":{}}
        def check(condition, description):
            if not condition:
                raise click.ClickException(description)
        check(client.get("/api/v1/kubernetes/nodes").status_code==401,"Unauthenticated API was not rejected")
        audit_before=db.session.query(AuditLog).filter_by(action="kubernetes_query").count()
        pods=[]
        try:
            for kind in ("nodes","pods","deployments","services","namespaces","events"):
                response=client.get("/api/v1/kubernetes/"+kind,headers=headers)
                check(response.status_code==200,f"{kind} query failed: HTTP {response.status_code}")
                data=response.get_json()
                report["resources"][kind]={"returned":len(data["items"]),"total":data["total"],"truncated":data["truncated"]}
                if kind=="nodes" and expected_nodes:
                    check(data["total"]==expected_nodes,"Unexpected Node count")
                if kind=="pods":
                    pods=data["items"]
                if kind=="events":
                    check(len(data["items"])<=200,"Events response exceeds display limit")
            report["observed_anomalies"]=sorted({reason for pod in pods for reason in pod["anomalies"]})
            selected=next((p for p in pods if p["phase"]=="Running" and p["containers"]),None)
            check(selected is not None,"No running Pod available for real log verification")
            namespace=selected["namespace"]
            scoped=client.get("/api/v1/kubernetes/pods",query_string={"namespace":namespace},headers=headers)
            check(scoped.status_code==200 and all(p["namespace"]==namespace for p in scoped.json["items"]),"Namespace filtering failed")
            container=next((c["name"] for c in selected["containers"] if c["ready"]),selected["containers"][0]["name"])
            logs=client.get(f'/api/v1/kubernetes/pods/{namespace}/{selected["name"]}/logs',query_string={"container":container},headers=headers)
            check(logs.status_code==200,"Real Pod log query failed")
            report["log_characters"]=len(logs.json["logs"])
            check(client.get("/api/v1/kubernetes/pods?namespace=INVALID!",headers=headers).status_code==400,"Invalid namespace was not rejected")
            check(client.post("/api/v1/kubernetes/nodes",headers=headers).status_code==405,"Write method was not rejected")
            db.session.expire_all()
            report["new_audit_records"]=db.session.query(AuditLog).filter_by(action="kubernetes_query").count()-audit_before
            check(report["new_audit_records"]>=9,"Query audit records missing")
            report["result"]="passed"
        finally:
            client.post("/api/v1/auth/logout",headers=headers)
        rendered=json.dumps(report,ensure_ascii=False,indent=2)
        if output:
            output.parent.mkdir(parents=True,exist_ok=True)
            output.write_text(rendered,encoding="utf-8")
        click.echo(rendered)
