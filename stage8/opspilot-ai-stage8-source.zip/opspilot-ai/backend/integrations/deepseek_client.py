"""Bounded HTTPS calls. No automatic retry of a potentially billed request."""

import json
from time import monotonic

import requests

from backend.ai_engine.analyzer import validate_result
from backend.ai_engine.prompts import SYSTEM_PROMPT


class DiagnosisError(RuntimeError):
    def __init__(self, code, status=502):
        self.code = code
        self.status = status
        super().__init__(code)


def analyze(settings, context):
    key = settings.get("DEEPSEEK_API_KEY")
    if not key:
        raise DiagnosisError("deepseek_not_configured", 503)
    payload = {
        "model": settings["DEEPSEEK_MODEL"],
        "messages": [{"role": "system", "content": SYSTEM_PROMPT},
                     {"role": "user", "content": json.dumps(context, ensure_ascii=False, allow_nan=False)}],
        "response_format": {"type": "json_object"},
        "thinking": {"type": "disabled"},
        "temperature": 0, "max_tokens": 2500,
    }
    started = monotonic()
    try:
        # Endpoint is intentionally fixed: callers cannot redirect credentials to another host.
        with requests.post("https://api.deepseek.com/chat/completions", json=payload,
                           headers={"Authorization": f"Bearer {key}"},
                           timeout=(5, 45), allow_redirects=False, stream=True) as response:
            if response.status_code != 200:
                codes = {401: "deepseek_auth_failed", 402: "deepseek_insufficient_balance",
                         429: "deepseek_rate_limited"}
                raise DiagnosisError(codes.get(response.status_code, "deepseek_http_error"))
            body = bytearray()
            for chunk in response.iter_content(chunk_size=8192):
                body.extend(chunk)
                if len(body) > 262144 or monotonic() - started > 60:
                    raise DiagnosisError("deepseek_response_limit")
        envelope = json.loads(body)
        choice = envelope["choices"][0]
        if choice["finish_reason"] != "stop":
            raise DiagnosisError("deepseek_incomplete_response")
        value = json.loads(choice["message"]["content"])
        return validate_result(value, {e["id"] for e in context["evidence"]})
    except requests.RequestException:
        raise DiagnosisError("deepseek_network_error") from None
    except (ValueError, KeyError, IndexError, TypeError):
        raise DiagnosisError("deepseek_invalid_response") from None
