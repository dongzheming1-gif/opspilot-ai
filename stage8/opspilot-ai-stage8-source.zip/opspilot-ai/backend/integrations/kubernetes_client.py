"""A dedicated Kubernetes client; TLS verification is mandatory."""

from pathlib import Path
from urllib.parse import urlsplit

import yaml
from kubernetes import client, config


def open_client(kubeconfig: str) -> client.ApiClient:
    path = Path(kubeconfig)
    if not kubeconfig or not path.is_file():
        raise ValueError("K8S_KUBECONFIG must point to a readable kubeconfig")
    document = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(document, dict):
        raise ValueError("Invalid kubeconfig")
    # Refuse executable authentication plugins and embedded admin certificates.
    for user in document.get("users", []):
        auth = user.get("user", {})
        if set(auth) - {"token", "tokenFile"}:
            raise ValueError("Only ServiceAccount token authentication is supported")
    for cluster in document.get("clusters", []):
        settings = cluster.get("cluster", {})
        if settings.get("insecure-skip-tls-verify"):
            raise ValueError("TLS verification must not be disabled")
        if urlsplit(settings.get("server", "")).scheme != "https":
            raise ValueError("Kubernetes endpoint must use HTTPS")
    configuration = client.Configuration()
    config.load_kube_config(config_file=str(path), client_configuration=configuration,
                          persist_config=False)
    configuration.verify_ssl = True
    configuration.retries = 0
    return client.ApiClient(configuration)
