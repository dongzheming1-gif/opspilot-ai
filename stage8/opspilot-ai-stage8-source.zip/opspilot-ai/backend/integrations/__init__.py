"""External API adapters."""
