"""Explicit Docker Engine connection; never uses a Kubernetes runtime socket."""
from contextlib import contextmanager
from pathlib import Path

import docker


class DockerNotConfigured(ValueError):
    pass


@contextmanager
def open_docker(settings):
    host = settings.get("DOCKER_HOST", "")
    if not host:
        raise DockerNotConfigured("Independent Docker Engine is not configured")
    tls = None
    if host.startswith("https://"):
        paths = [settings.get(key, "") for key in ("DOCKER_CA_FILE", "DOCKER_CERT_FILE", "DOCKER_KEY_FILE")]
        if not all(path and Path(path).is_file() for path in paths):
            raise ValueError("Remote Docker requires CA and client certificates")
        tls = docker.tls.TLSConfig(ca_cert=paths[0],client_cert=(paths[1],paths[2]),verify=True)
    elif not host.startswith(("unix://", "npipe://")):
        raise ValueError("Use a local Docker socket or HTTPS with mutual TLS")
    connection = docker.DockerClient(base_url=host, tls=tls, timeout=10)
    try:
        yield connection
    finally:
        connection.close()
