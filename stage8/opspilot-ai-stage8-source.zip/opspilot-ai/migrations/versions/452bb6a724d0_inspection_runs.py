"""Add persisted read-only inspection reports.

Revision ID: 452bb6a724d0
Revises: 111d95eca79e
"""
from alembic import op
import sqlalchemy as sa

revision = "452bb6a724d0"
down_revision = "111d95eca79e"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table("inspection_run",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("report", sa.JSON(), nullable=False))
    op.create_index("ix_inspection_run_created_at", "inspection_run", ["created_at"])


def downgrade():
    op.drop_index("ix_inspection_run_created_at", table_name="inspection_run")
    op.drop_table("inspection_run")
