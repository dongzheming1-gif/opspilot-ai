"""Record manual alert closure for one-hour re-notification suppression.

Revision ID: 68d9f6c2b85a
Revises: 452bb6a724d0
"""
from alembic import op
import sqlalchemy as sa

revision = "68d9f6c2b85a"
down_revision = "452bb6a724d0"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("alert", sa.Column("closed_by_user_id", sa.Integer(), nullable=True))
    op.create_foreign_key("fk_alert_closed_by_user", "alert", "user",
                          ["closed_by_user_id"], ["id"])


def downgrade():
    op.drop_constraint("fk_alert_closed_by_user", "alert", type_="foreignkey")
    op.drop_column("alert", "closed_by_user_id")
