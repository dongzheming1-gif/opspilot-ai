"""Allow full namespace/pod identity in alert resource names.

Revision ID: 97c7e6597f19
Revises: 68d9f6c2b85a
"""
from alembic import op
import sqlalchemy as sa

revision = "97c7e6597f19"
down_revision = "68d9f6c2b85a"
branch_labels = None
depends_on = None


def upgrade():
    op.alter_column("alert", "resource_name", existing_type=sa.String(length=255),
                    type_=sa.String(length=512), existing_nullable=False)


def downgrade():
    op.alter_column("alert", "resource_name", existing_type=sa.String(length=512),
                    type_=sa.String(length=255), existing_nullable=False)
