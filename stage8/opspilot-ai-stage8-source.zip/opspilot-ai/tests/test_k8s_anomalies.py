from types import SimpleNamespace as N
import pytest
from backend.services.k8s_service import pod_summary, node_summary


def pod(phase="Running", reason=None, previous=None):
    container=N(name="app",ready=False,restart_count=2,
        state=N(waiting=N(reason=reason) if reason else None,terminated=None),
        last_state=N(terminated=N(reason=previous) if previous else None))
    return N(metadata=N(name="test-pod",namespace="test",creation_timestamp=None),
             spec=N(node_name="node",containers=[]),
             status=N(phase=phase,pod_ip="10.0.0.1",container_statuses=[container],init_container_statuses=[],conditions=[]))


@pytest.mark.parametrize("reason",["CrashLoopBackOff","ImagePullBackOff","ErrImagePull"])
def test_running_pod_can_have_container_failure(reason):
    result=pod_summary(pod(reason=reason))
    assert reason in result["anomalies"]
    assert result["phase"]=="Running"


def test_previous_oom_is_not_lost_after_restart():
    assert "OOMKilled" in pod_summary(pod(previous="OOMKilled"))["anomalies"]


def test_pending_and_failed_scheduling_are_both_reported():
    value=pod(phase="Pending")
    value.status.conditions=[N(type="PodScheduled",status="False")]
    assert pod_summary(value)["anomalies"]==["FailedScheduling","Pending"]


def test_unknown_node_condition_is_not_ready():
    node=N(metadata=N(name="node",labels={}),status=N(conditions=[N(type="Ready",status="Unknown")],
        addresses=[],node_info=N(kubelet_version="v1",container_runtime_version="containerd"),capacity={},allocatable={}))
    assert node_summary(node)["anomalies"]==["Node NotReady"]
