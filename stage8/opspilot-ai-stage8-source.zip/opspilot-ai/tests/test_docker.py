from contextlib import nullcontext
from unittest.mock import Mock

import pytest
from flask_jwt_extended import create_access_token
from docker.errors import DockerException

from backend.app import create_app
from backend.extensions import db
from backend.models import User, AuditLog
from backend.api import docker as routes
from backend.integrations.docker_client import open_docker, DockerNotConfigured
from backend.services.docker_service import read_logs

ID="a"*64


@pytest.fixture
def context():
    app=create_app({"TESTING":True,"SQLALCHEMY_DATABASE_URI":"sqlite://","REDIS_URL":None,
                    "DOCKER_HOST":"","DOCKER_ACTIONS_ENABLED":False,
                    "SECRET_KEY":"test-secret-longer-than-thirty-two-characters"})
    with app.app_context():
        db.create_all()
        for role in ("viewer","admin"):
            db.session.add(User(username=role,password_hash="unused-in-tests",role=role))
        db.session.commit()
        headers={u.role:{"Authorization":"Bearer "+create_access_token(identity=str(u.id))} for u in db.session.query(User)}
        yield app,app.test_client(),headers
        db.session.remove()
        db.drop_all()


def test_unconfigured_is_not_a_fake_empty_engine(context):
    _,client,headers=context
    assert client.get('/api/v1/docker/status').status_code==401
    result=client.get('/api/v1/docker/status',headers=headers['viewer'])
    assert result.status_code==503
    assert result.json['state']=='not_configured'
    assert db.session.query(AuditLog).one().result=='failed'


@pytest.mark.parametrize('host',['http://remote:2375','tcp://remote:2375','https://remote:2376','ssh://root@remote'])
def test_insecure_or_incomplete_connection_rejected(host):
    with pytest.raises(ValueError):
        with open_docker({'DOCKER_HOST':host}):
            pytest.fail('Must not connect')


def test_viewer_and_default_switch_cannot_control(context,monkeypatch):
    app,client,headers=context
    connect=Mock()
    monkeypatch.setattr(routes,'open_docker',connect)
    path=f'/api/v1/docker/containers/{ID}/stop'
    assert client.post(path,headers=headers['viewer'],json={'confirm_container_id':ID}).status_code==403
    assert client.post(path,headers=headers['admin'],json={'confirm_container_id':ID}).status_code==403
    connect.assert_not_called()
    app.config['DOCKER_ACTIONS_ENABLED']=True
    assert client.post(path,headers=headers['admin'],json={}).status_code==400
    connect.assert_not_called()


def test_managed_container_and_audit_required(context,monkeypatch):
    app,client,headers=context
    app.config['DOCKER_ACTIONS_ENABLED']=True
    container=Mock(id=ID,status='exited',labels={},attrs={'Config':{'Image':'test-image'}})
    container.name='test-container'
    engine=Mock()
    engine.containers.get.return_value=container
    monkeypatch.setattr(routes,'open_docker',lambda _:nullcontext(engine))
    path=f'/api/v1/docker/containers/{ID}/stop'
    result=client.post(path,headers=headers['admin'],json={'confirm_container_id':ID})
    assert result.status_code==403
    container.stop.assert_not_called()
    container.labels={'opspilot.managed':'true'}
    def stop(**kwargs):
        assert db.session.query(AuditLog).filter_by(action='docker_action_requested').count()>=1
    container.stop.side_effect=stop
    result=client.post(path,headers=headers['admin'],json={'confirm_container_id':ID})
    assert result.status_code==200
    container.stop.assert_called_once_with(timeout=5)
    container.reload.assert_called_once()


def test_connection_error_is_sanitized(context,monkeypatch):
    _,client,headers=context
    monkeypatch.setattr(routes,'open_docker',Mock(side_effect=DockerException('private-host-and-secret')))
    response=client.get('/api/v1/docker/status',headers=headers['admin'])
    assert response.status_code==502
    assert 'private-host-and-secret' not in response.get_data(as_text=True)


def test_log_bytes_are_bounded_and_stream_closed():
    stream=Mock()
    stream.__iter__=Mock(return_value=iter([b'x'*40000]))
    container=Mock()
    container.logs.return_value=stream
    result=read_logs(container)
    assert len(result['logs'])==32768 and result['truncated']
    stream.close.assert_called_once()
