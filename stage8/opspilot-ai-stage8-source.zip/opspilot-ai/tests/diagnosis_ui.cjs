// Real browser/API checks plus explicitly intercepted UI boundary scenarios.
// Optional local test dependency: npm install --prefix work/ui-tests playwright
const { chromium } = require('../work/ui-tests/node_modules/playwright');
const fs = require('node:fs');
const assert = require('node:assert/strict');

(async () => {
  const browser = await chromium.launch({channel:'msedge', headless:true});
  const page = await browser.newPage({viewport:{width:1440,height:1000}});
  const errors = [], checks = [];
  page.on('pageerror', error => errors.push(error.message));
  const login = JSON.parse(fs.readFileSync('work/initial-login.json','utf8'));
  try {
    await page.goto('http://127.0.0.1:5000/');
    await page.locator('#username').fill(login.username);
    await page.locator('#password').fill(login.password);
    await page.locator('#login-form button').click();
    await page.locator('#workspace').waitFor({state:'visible'});
    await page.waitForFunction(() => !state.busy);
    await page.locator('[data-page=diagnosis]').click();
    await page.waitForFunction(() => !state.busy);
    assert.equal(await page.locator('#diagnosis-resource option').count(),3);
    await page.getByRole('button',{name:'查看详情',exact:true}).first().click();
    await page.getByRole('heading',{name:'事实证据 · 采集快照'}).waitFor();
    for (const [source,min] of [['pod',1],['node',3]]) {
      await page.locator('#diagnosis-source').selectOption(source);
      await page.waitForFunction(() => !document.getElementById('diagnosis-resource').disabled);
      assert.ok(await page.locator('#diagnosis-resource option').count() >= min);
    }
    const selection = await page.locator('#diagnosis-resource').inputValue();
    await page.waitForTimeout(16000);
    assert.equal(await page.locator('#diagnosis-resource').inputValue(),selection);
    checks.push('REAL: login, history detail, 3 hosts, Pod/Node lists, selection survives timer');
    const liveResponse = page.waitForResponse(r => r.url().endsWith('/api/v1/diagnosis') && r.request().method() === 'POST', {timeout:190000});
    await page.locator('#diagnosis-submit').click();
    const liveStatus = (await liveResponse).status();
    await page.waitForFunction(() => !state.diagnosing, null, {timeout:190000});
    assert.ok([201,429].includes(liveStatus), `Unexpected real diagnosis status: ${liveStatus}`);
    checks.push(`REAL: browser diagnosis POST returned ${liveStatus} (${liveStatus === 429 ? 'existing hourly quota enforced' : 'new diagnosis saved'})`);
    await page.screenshot({path:'outputs/ai-diagnosis-page.png',fullPage:true});
    await page.setViewportSize({width:390,height:844});
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    await page.screenshot({path:'outputs/ai-diagnosis-mobile.png'});
    await page.setViewportSize({width:1440,height:1000});
    checks.push('REAL: 390px mobile layout has no page overflow');

    // Intercept only the paid diagnosis POST; no synthetic record is written to MySQL.
    const record = JSON.parse(fs.readFileSync('outputs/cluster-diagnosis-acceptance.json','utf8')).checks[0].response;
    record.summary = '<img src=x onerror="window.injected=true"> UI boundary fixture';
    let calls=0, release;
    await page.route('**/api/v1/diagnosis', async route => {
      if (route.request().method() !== 'POST') return route.continue();
      calls++;
      await new Promise(resolve => release=resolve);
      await route.fulfill({status:201,contentType:'application/json',body:JSON.stringify(record)});
    });
    await page.locator('#diagnosis-submit').click();
    await page.waitForFunction(() => state.diagnosing);
    assert.ok(await page.locator('#diagnosis-submit').isDisabled());
    assert.ok(await page.locator('#refresh').isDisabled());
    await page.locator('#diagnosis-submit').dispatchEvent('click');
    while (!release) await new Promise(resolve => setTimeout(resolve,10));
    release();
    await page.waitForFunction(() => !state.diagnosing);
    assert.equal(calls,1);
    assert.ok(await page.getByText(record.summary,{exact:true}).count());
    assert.equal(await page.evaluate(() => window.injected),undefined);
    checks.push('INTERCEPTED: successful render, pending controls, duplicate prevention, HTML rendered as text');
    await page.unroute('**/api/v1/diagnosis');
    await page.route('**/api/v1/diagnosis', route => route.request().method() === 'POST'
      ? route.fulfill({status:429,contentType:'application/json',body:'{"error":"diagnosis_hourly_limit"}'}) : route.continue());
    await page.locator('#diagnosis-submit').click();
    await page.getByText('本小时诊断尝试已达上限，请稍后再试。已有结果仍可查看。',{exact:true}).waitFor();
    checks.push('INTERCEPTED: quota error is readable and previous result remains');
    await page.unroute('**/api/v1/diagnosis');
    // Role UI test only; backend viewer permissions are covered by pytest.
    await page.evaluate(() => { state.role='viewer'; return refresh(); });
    assert.ok(await page.locator('#diagnosis-submit').isDisabled());
    assert.ok(await page.getByRole('button',{name:'查看详情',exact:true}).count());
    checks.push('UI ROLE FIXTURE: viewer cannot submit, history remains accessible');
    assert.deepEqual(errors,[]);
    await page.locator('#logout').click();
    await page.locator('#login-screen').waitFor({state:'visible'});
    assert.equal(await page.evaluate(() => diagnosisState.record),null);
    checks.push('REAL: logout clears diagnosis memory; no browser JS errors');
    fs.writeFileSync('outputs/ai-page-acceptance.json',JSON.stringify({checks,errors},null,2));
    console.log(JSON.stringify({checks,errors},null,2));
  } catch (error) {
    await page.screenshot({path:'work/ai-ui-failure.png',fullPage:true});
    console.log(JSON.stringify({errors,stage:await page.locator('#page-title').textContent(),banner:await page.locator('#error-banner').textContent()}));
    throw error;
  } finally { await browser.close(); }
})().catch(error => { console.error(error.stack); process.exitCode=1; });
