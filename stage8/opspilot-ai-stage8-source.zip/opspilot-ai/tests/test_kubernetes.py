import json
from types import SimpleNamespace

import pytest

from backend.app import create_app
from backend.integrations.kubernetes_client import open_client
from backend.services.k8s_service import all_items


def test_missing_config_is_explicit():
    with pytest.raises(ValueError, match="K8S_KUBECONFIG"):
        open_client("")


@pytest.mark.parametrize("cluster,user", [
    ({"server": "http://example.invalid"}, {"token": "test"}),
    ({"server": "https://example.invalid", "insecure-skip-tls-verify": True}, {"token": "test"}),
    ({"server": "https://example.invalid"}, {"exec": {"command": "never-run"}}),
    ({"server": "https://example.invalid"}, {"client-key-data": "test"}),
])
def test_unsafe_configuration_rejected(tmp_path, cluster, user):
    path = tmp_path / "config.json"
    path.write_text(json.dumps({"clusters": [{"cluster": cluster}], "users": [{"user": user}]}))
    with pytest.raises(ValueError):
        open_client(str(path))


def test_pagination_retains_all_resources():
    calls = []
    def page(**kwargs):
        calls.append(kwargs)
        return SimpleNamespace(items=[len(calls)], metadata=SimpleNamespace(_continue="next" if len(calls) == 1 else ""))
    assert all_items(page) == [1, 2]
    assert calls[1]["_continue"] == "next"
    connect,read=calls[0]["_request_timeout"]
    assert 0 < connect <= 3 and 0 < read <= 10


def test_cli_failure_has_nonzero_exit_and_no_secrets():
    app = create_app({"K8S_KUBECONFIG": ""})
    result = app.test_cli_runner().invoke(args=["check-kubernetes"])
    assert result.exit_code != 0
    assert "configuration/TLS/network failure" in result.output
