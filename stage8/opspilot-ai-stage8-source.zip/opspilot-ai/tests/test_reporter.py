from types import SimpleNamespace
from unittest.mock import Mock

import pytest
import requests
from agent import reporter

CONFIG = {"endpoint": "https://example.invalid/api/v1/metrics", "token": "unit-test", "ca_file": "test-ca"}


def test_network_failure_has_finite_retries(monkeypatch):
    post = Mock(side_effect=requests.Timeout())
    monkeypatch.setattr(reporter.requests, "post", post)
    monkeypatch.setattr(reporter.time, "sleep", lambda _: None)
    with pytest.raises(RuntimeError):
        reporter.report(CONFIG, {})
    assert post.call_count == 3
    assert post.call_args.kwargs["verify"] == "test-ca"
    assert post.call_args.kwargs["allow_redirects"] is False


def test_authentication_error_not_retried(monkeypatch):
    post = Mock(return_value=SimpleNamespace(status_code=401))
    monkeypatch.setattr(reporter.requests, "post", post)
    with pytest.raises(ValueError):
        reporter.report(CONFIG, {})
    assert post.call_count == 1
