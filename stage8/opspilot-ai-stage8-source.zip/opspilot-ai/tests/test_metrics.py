from datetime import datetime, timezone

import pytest

from backend.app import create_app


@pytest.fixture
def setup():
    app = create_app({"TESTING": True, "METRICS_MEMORY_ONLY": True, "AGENT_TOKENS": {"host-a": "test-token-a", "host-b": "test-token-b"}})
    data = {"agent_id": "host-a", "hostname": "unit-test-host", "collected_at": datetime.now(timezone.utc).isoformat(),
            "cpu_usage": 10, "memory_usage": 20, "disk_usage": 30, "network_in": 100, "network_out": 200, "uptime_seconds": 5}
    return app, app.test_client(), data


def test_valid_report_is_explicitly_memory_only(setup):
    app, client, data = setup
    response = client.post("/api/v1/metrics", json=data, headers={"Authorization": "Bearer test-token-a"})
    assert response.status_code == 202
    assert response.json["persistence"] == "memory"
    assert app.extensions["metric_spool"][-1]["agent_id"] == "host-a"


def test_token_cannot_impersonate_another_agent(setup):
    app, client, data = setup
    data["agent_id"] = "host-b"
    assert client.post("/api/v1/metrics", json=data, headers={"Authorization": "Bearer test-token-a"}).status_code == 401
    assert len(app.extensions["metric_spool"]) == 0


@pytest.mark.parametrize("field,value", [("cpu_usage", 101), ("memory_usage", True), ("disk_usage", -1),
    ("network_in", float("nan")), ("collected_at", "2000-01-01T00:00:00+00:00"), ("hostname", "")])
def test_invalid_payload_is_not_stored(setup, field, value):
    app, client, data = setup
    data[field] = value
    assert client.post("/api/v1/metrics", json=data, headers={"Authorization": "Bearer test-token-a"}).status_code == 400
    assert len(app.extensions["metric_spool"]) == 0


def test_missing_auth_is_rejected(setup):
    _, client, data = setup
    assert client.post("/api/v1/metrics", json=data).status_code == 401
