from datetime import datetime, timezone
from unittest.mock import Mock

import pytest
from werkzeug.security import generate_password_hash
from backend.app import create_app
from backend.extensions import db
from backend.models import User, Server, Metric, AuditLog


@pytest.fixture
def database_app():
    # SQLite is only an isolated unit-test database; real acceptance uses MySQL.
    app = create_app({"TESTING":True, "SQLALCHEMY_DATABASE_URI":"sqlite://", "REDIS_URL":None,
                      "SECRET_KEY":"unit-test-secret-at-least-thirty-two-characters", "AGENT_TOKENS":{"test-host":"test-token"}})
    app.extensions["redis"] = Mock(incr=Mock(return_value=1))
    with app.app_context():
        db.create_all()
        db.session.add(User(username="test-user", password_hash=generate_password_hash("test-password-long"), role="viewer"))
        db.session.commit()
        yield app
        db.session.remove()
        db.drop_all()


def login(client):
    result = client.post("/api/v1/auth/login", json={"username":"test-user","password":"test-password-long"})
    assert result.status_code == 200
    return {"Authorization":"Bearer "+result.json["access_token"]}


def test_login_logout_and_audit(database_app):
    client = database_app.test_client()
    assert client.get("/api/v1/servers").status_code == 401
    headers = login(client)
    assert client.get("/api/v1/auth/me",headers=headers).status_code == 200
    assert client.post("/api/v1/auth/logout",headers=headers).status_code == 200
    assert client.get("/api/v1/servers",headers=headers).status_code == 401
    assert db.session.query(AuditLog).count() == 2
    assert db.session.query(User).first().password_hash != "test-password-long"


def test_wrong_password_and_rate_limit(database_app):
    client = database_app.test_client()
    assert client.post("/api/v1/auth/login",json={"username":"test-user","password":"bad"}).status_code == 401
    database_app.extensions["redis"].incr.return_value = 11
    assert client.post("/api/v1/auth/login",json={"username":"test-user","password":"bad"}).status_code == 429


def test_sample_deduplication_and_history(database_app):
    client = database_app.test_client()
    data = {"agent_id":"test-host","hostname":"test-host","collected_at":datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
            "cpu_usage":10,"memory_usage":20,"disk_usage":30,"network_in":100,"network_out":200,"uptime_seconds":30}
    for _ in range(2):
        response = client.post("/api/v1/metrics",json=data,headers={"Authorization":"Bearer test-token"})
        assert response.status_code == 202
    assert db.session.query(Server).count() == 1
    assert db.session.query(Metric).count() == 1
    headers = login(client)
    servers = client.get("/api/v1/servers",headers=headers).json["items"]
    assert servers[0]["status"] == "online"
    history = client.get(f'/api/v1/servers/{servers[0]["id"]}/metrics',headers=headers)
    assert len(history.json["items"]) == 1
    assert client.get(f'/api/v1/servers/{servers[0]["id"]}/metrics?limit=bad',headers=headers).status_code == 400


def test_cache_failure_does_not_lose_database_write(database_app):
    from redis.exceptions import ConnectionError
    database_app.extensions["redis"].set.side_effect = ConnectionError()
    client = database_app.test_client()
    data = {"agent_id":"test-host","hostname":"test-host","collected_at":datetime.now(timezone.utc).isoformat(),
            "cpu_usage":10,"memory_usage":20,"disk_usage":30,"network_in":100,"network_out":200,"uptime_seconds":30}
    response = client.post("/api/v1/metrics",json=data,headers={"Authorization":"Bearer test-token"})
    assert response.status_code == 202
    assert response.json["cached"] is False
    assert db.session.query(Metric).count() == 1
