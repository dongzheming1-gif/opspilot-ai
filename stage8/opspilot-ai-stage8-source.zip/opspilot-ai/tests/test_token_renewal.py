import base64
import json
from datetime import datetime, timedelta, timezone

import pytest

from deploy.windows.renew_kubernetes_token import claims


def make_token(subject="system:serviceaccount:opspilot-system:opspilot-reader",
               lifetime_days=30):
    now = datetime.now(timezone.utc)
    header = base64.urlsafe_b64encode(b'{"alg":"RS256"}').decode().rstrip("=")
    payload = base64.urlsafe_b64encode(json.dumps({
        "sub": subject,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(days=lifetime_days)).timestamp()),
    }).encode()).decode().rstrip("=")
    return f"{header}.{payload}.signature"


def test_accepts_expected_read_only_service_account_token():
    result = claims(make_token())
    assert result["expiry"] > result["issued"]


@pytest.mark.parametrize("token", [
    "not-a-jwt",
    make_token(subject="system:serviceaccount:default:default"),
    make_token(lifetime_days=2),
])
def test_rejects_wrong_or_short_lived_token(token):
    with pytest.raises(ValueError):
        claims(token)
