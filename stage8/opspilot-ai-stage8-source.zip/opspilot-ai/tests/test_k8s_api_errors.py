"""Fault injection tests, independent of the real cluster and user database."""
from contextlib import nullcontext
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from flask_jwt_extended import create_access_token
from kubernetes.client.exceptions import ApiException
from urllib3.exceptions import ReadTimeoutError
from yaml import YAMLError

from backend.app import create_app
from backend.extensions import db
from backend.models import User, AuditLog
from backend.api import kubernetes as routes
from backend.services.k8s_service import all_items, ClusterReadLimitError


@pytest.fixture
def api_context(monkeypatch):
    app=create_app({"TESTING":True,"SQLALCHEMY_DATABASE_URI":"sqlite://","REDIS_URL":None,
                    "SECRET_KEY":"test-secret-with-at-least-thirty-two-characters"})
    with app.app_context():
        db.create_all()
        user=User(username="test-reader",password_hash="not-a-login-credential",role="viewer")
        db.session.add(user)
        db.session.commit()
        headers={"Authorization":"Bearer "+create_access_token(identity=str(user.id))}
        monkeypatch.setattr(routes,"open_client",lambda _:nullcontext(object()))
        yield app.test_client(),headers
        db.session.remove()
        db.drop_all()


@pytest.mark.parametrize("upstream,expected",[(400,400),(401,502),(403,502),(404,404),(429,429),(500,502)])
def test_upstream_errors_are_sanitized_and_audited(api_context,monkeypatch,upstream,expected):
    client,headers=api_context
    error=ApiException(status=upstream,reason="secret-must-not-be-reflected")
    error.body="secret-must-not-be-reflected"
    monkeypatch.setattr(routes,"resources",Mock(side_effect=error))
    response=client.get("/api/v1/kubernetes/pods",headers=headers)
    assert response.status_code==expected
    assert response.json["upstream_status"]==upstream
    assert "secret-must-not-be-reflected" not in response.get_data(as_text=True)
    entry=db.session.query(AuditLog).one()
    assert entry.result=="failed"
    assert entry.action=="kubernetes_query"


@pytest.mark.parametrize("error,status",[(ReadTimeoutError(None,"/","test"),503),
    (YAMLError("private configuration text"),503),(ClusterReadLimitError("test"),504)])
def test_transport_and_config_failures(api_context,monkeypatch,error,status):
    client,headers=api_context
    monkeypatch.setattr(routes,"open_client",Mock(side_effect=error))
    response=client.get("/api/v1/kubernetes/nodes",headers=headers)
    assert response.status_code==status
    assert "private configuration text" not in response.get_data(as_text=True)
    assert db.session.query(AuditLog).one().result=="failed"


def test_invalid_input_and_events_truncation(api_context,monkeypatch):
    client,headers=api_context
    service=Mock(return_value=[{"name":str(i)} for i in range(250)])
    monkeypatch.setattr(routes,"resources",service)
    assert client.get("/api/v1/kubernetes/pods?namespace=BAD!",headers=headers).status_code==400
    service.assert_not_called()
    response=client.get("/api/v1/kubernetes/events",headers=headers)
    assert response.status_code==200
    assert len(response.json["items"])==200
    assert response.json["total"]==250 and response.json["truncated"] is True


def test_log_errors_do_not_return_content(api_context,monkeypatch):
    client,headers=api_context
    monkeypatch.setattr(routes,"pod_logs",Mock(side_effect=ApiException(status=400,reason="private logs")))
    response=client.get("/api/v1/kubernetes/pods/default/test/logs?previous=true",headers=headers)
    assert response.status_code==400
    assert "private logs" not in response.get_data(as_text=True)


def test_pagination_repeated_token_is_stopped():
    method=Mock(return_value=SimpleNamespace(items=[1],metadata=SimpleNamespace(_continue="repeated")))
    with pytest.raises(ClusterReadLimitError):
        all_items(method)
    assert method.call_count==2
