"""Stage 0 acceptance tests; no simulated monitoring data."""

from backend.app import create_app


def test_health_is_application_liveness_only():
    client = create_app({"TESTING": True}).test_client()
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    assert response.is_json
    assert response.json == {
        "status": "ok", "service": "opspilot-ai", "scope": "application"
    }


def test_unknown_route_returns_json_404():
    response = create_app({"TESTING": True}).test_client().get("/api/v1/missing")
    assert response.status_code == 404
    assert response.json["error"] == "Not Found"


def test_health_rejects_write_and_preserves_allow_header():
    response = create_app({"TESTING": True}).test_client().post("/api/v1/health")
    assert response.status_code == 405
    assert "GET" in response.headers["Allow"]


def test_configuration_reads_environment_and_disables_debug(monkeypatch):
    monkeypatch.setenv("SECRET_KEY", "test-value-not-a-real-secret")
    app = create_app()
    assert app.config["SECRET_KEY"] == "test-value-not-a-real-secret"
    assert app.config["DEBUG"] is False


def test_app_instances_do_not_share_test_configuration():
    first = create_app({"TESTING": True})
    second = create_app()
    assert first.testing is True
    assert second.testing is False
