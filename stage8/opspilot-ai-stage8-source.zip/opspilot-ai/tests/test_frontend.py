from html.parser import HTMLParser
from backend.app import create_app


def test_login_fallback_never_places_credentials_in_url():
    class Forms(HTMLParser):
        def __init__(self):
            super().__init__()
            self.forms = []
        def handle_starttag(self, tag, attrs):
            if tag == 'form':
                self.forms.append(dict(attrs))
    response = create_app({'TESTING':True}).test_client().get('/')
    parser = Forms()
    parser.feed(response.get_data(as_text=True))
    assert response.status_code == 200
    assert all(form.get('method', '').lower() == 'post' for form in parser.forms)
    assert 'frame-ancestors' in response.headers['Content-Security-Policy']
