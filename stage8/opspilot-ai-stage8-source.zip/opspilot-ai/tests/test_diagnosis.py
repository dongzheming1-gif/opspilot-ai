"""Isolated tests; fixtures are not real monitoring or model results."""
import json
from datetime import datetime, timezone, timedelta
from unittest.mock import MagicMock, Mock

import pytest
import requests
from flask_jwt_extended import create_access_token

from backend.app import create_app
from backend.extensions import db
from backend.models import User, Server, Metric, Diagnosis, AuditLog
from backend.api import diagnosis as routes
from backend.integrations import deepseek_client as provider
from backend.ai_engine.analyzer import validate_result
from backend.services.diagnosis_service import server_context


def valid():
    return dict(fault_type="test", severity="info", summary="test observation", evidence=["E1"],
                possible_causes=["uncertain"], troubleshooting_steps=["inspect"], recommendations=["observe"], prevention=["monitor"])


@pytest.fixture
def context():
    app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite://", "REDIS_URL": None,
                      "DEEPSEEK_API_KEY": "test-only", "DIAGNOSIS_HOURLY_LIMIT": 5, "SECRET_KEY": "test-secret-longer-than-thirty-two-characters"})
    app.extensions["redis"] = Mock()
    app.extensions["redis"].eval.return_value = 1
    with app.app_context():
        db.create_all()
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        db.session.add_all([User(username=r, role=r, password_hash="unused") for r in ("admin", "viewer")])
        db.session.add(Server(id=1, agent_id="private-agent", hostname="private-host", ip_address="private-ip", last_heartbeat=now))
        db.session.add(Metric(server_id=1, cpu_usage=1, memory_usage=2, disk_usage=3, network_in=0, network_out=0,
                              uptime_seconds=1, collected_at=now))
        db.session.commit()
        headers = {u.role: {"Authorization": "Bearer " + create_access_token(identity=str(u.id))} for u in db.session.query(User)}
        yield app, app.test_client(), headers
        db.session.remove()
        db.drop_all()


def test_context_contains_only_allowlisted_metrics(context):
    value = server_context(1)
    assert value["evidence"][0]["observation"]["disk_usage"] == 3
    assert "private" not in json.dumps(value)
    metric = db.session.query(Metric).one()
    metric.collected_at -= timedelta(minutes=3)
    db.session.commit()
    with pytest.raises(provider.DiagnosisError, match="metrics_stale"):
        server_context(1)


def test_quota_reports_configured_limit(context):
    app, client, headers = context
    app.config['DIAGNOSIS_HOURLY_LIMIT'] = 8
    app.extensions['redis'].get.return_value = '6'
    app.extensions['redis'].ttl.return_value = 100
    assert client.get('/api/v1/diagnosis/quota', headers=headers['admin']).json == {'limit':8,'remaining':2,'retry_seconds':100}


@pytest.mark.parametrize("field,value", [("evidence", ["invented"]), ("severity", "fatal"), ("severity", []),
                                         ("summary", ""), ("prevention", []), ("recommendations", [3]), ("extra", "x")])
def test_rejects_invalid_model_contract(field, value):
    result = valid()
    result[field] = value
    with pytest.raises(ValueError):
        validate_result(result, {"E1"})


def test_permissions_persistence_and_history(context, monkeypatch):
    _, client, headers = context
    analyze = Mock(return_value=valid())
    monkeypatch.setattr(routes, "analyze", analyze)
    body = {"source": "server", "server_id": 1}
    assert client.post('/api/v1/diagnosis', json=body).status_code == 401
    assert client.post('/api/v1/diagnosis', json=body, headers=headers['viewer']).status_code == 403
    analyze.assert_not_called()
    response = client.post('/api/v1/diagnosis', json=body, headers=headers['admin'])
    assert response.status_code == 201
    assert db.session.query(Diagnosis).count() == 1
    assert db.session.query(AuditLog).count() == 2
    detail = client.get(f"/api/v1/diagnosis/{response.json['id']}", headers=headers['viewer'])
    assert detail.json['result']['context']['evidence'][0]['id'] == 'E1'
    assert len(client.get('/api/v1/diagnosis', headers=headers['viewer']).json['items']) == 1


def test_quota_and_failed_provider_do_not_save_success(context, monkeypatch):
    app, client, headers = context
    analyze = Mock(side_effect=provider.DiagnosisError("deepseek_auth_failed"))
    monkeypatch.setattr(routes, "analyze", analyze)
    body = {"source": "server", "server_id": 1}
    result = client.post('/api/v1/diagnosis', json=body, headers=headers['admin'])
    assert result.status_code == 502
    assert db.session.query(Diagnosis).count() == 0
    assert db.session.query(AuditLog).filter_by(result='failed').count() == 1
    app.extensions['redis'].eval.return_value = 6
    assert client.post('/api/v1/diagnosis', json=body, headers=headers['admin']).status_code == 429
    assert analyze.call_count == 1


@pytest.mark.parametrize('content,finish', [(' ', 'stop'), ('{}', 'stop'), (json.dumps(valid()), 'length')])
def test_blank_invalid_or_truncated_provider_response(monkeypatch, content, finish):
    response = MagicMock(status_code=200)
    response.__enter__.return_value = response
    response.iter_content.return_value = [json.dumps({'choices': [{'finish_reason': finish, 'message': {'content': content}}]}).encode()]
    post = Mock(return_value=response)
    monkeypatch.setattr(provider.requests, 'post', post)
    with pytest.raises(provider.DiagnosisError):
        provider.analyze({'DEEPSEEK_API_KEY': 'test', 'DEEPSEEK_MODEL': 'test'}, {'evidence': [{'id': 'E1'}]})
    assert post.call_count == 1
    assert post.call_args.kwargs['allow_redirects'] is False
    response.__exit__.assert_called_once()


def test_network_error_does_not_expose_credentials(monkeypatch):
    monkeypatch.setattr(provider.requests, 'post', Mock(side_effect=requests.ConnectionError('secret-key')))
    with pytest.raises(provider.DiagnosisError) as error:
        provider.analyze({'DEEPSEEK_API_KEY': 'secret-key', 'DEEPSEEK_MODEL': 'test'}, {'evidence': []})
    assert str(error.value) == 'deepseek_network_error'
