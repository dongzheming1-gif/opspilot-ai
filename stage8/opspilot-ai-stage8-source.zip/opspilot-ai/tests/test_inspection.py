from contextlib import contextmanager
from datetime import timedelta
from unittest.mock import Mock

import pytest
from werkzeug.security import generate_password_hash

from backend.app import create_app
from backend.extensions import db
from backend.models import Alert, AuditLog, InspectionRun, Metric, Server, User
from backend.models.user import utcnow


@pytest.fixture
def app():
    app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite://",
                      "REDIS_URL": None, "K8S_KUBECONFIG": "test",
                      "SECRET_KEY": "inspection-test-secret-at-least-32-chars"})
    app.extensions["redis"] = Mock(incr=Mock(return_value=1))
    with app.app_context():
        db.create_all()
        db.session.add(User(username="operator", role="operator",
                            password_hash=generate_password_hash("long-test-password")))
        db.session.add(User(username="viewer", role="viewer",
                            password_hash=generate_password_hash("long-test-password")))
        db.session.add(User(username="admin", role="admin",
                            password_hash=generate_password_hash("long-test-password")))
        db.session.commit()
        yield app
        db.session.remove()
        db.drop_all()


def auth(client, username):
    response = client.post("/api/v1/auth/login", json={
        "username": username, "password": "long-test-password"})
    assert response.status_code == 200
    return {"Authorization": "Bearer " + response.json["access_token"]}


def test_inspection_alert_lifecycle_and_audit(app, monkeypatch):
    from backend.services import inspection_service

    @contextmanager
    def client(_path):
        yield object()

    snapshot = {"nodes": [{"name": "node-a", "ready": False}],
                "pods": [{"namespace": "default", "name": "broken", "anomalies": ["CrashLoopBackOff"],
                          "phase": "Running", "created_at": None}],
                "events": [{"type": "Warning", "namespace": "default", "resource": "broken",
                            "reason": "BackOff", "message": "restarting",
                            "time": utcnow().isoformat() + "Z"},
                           {"type": "Warning", "namespace": "default", "resource": "old",
                            "reason": "OldFailure", "message": "historical",
                            "time": (utcnow() - timedelta(days=1)).isoformat() + "Z"}]}
    monkeypatch.setattr(inspection_service, "open_client", client)
    monkeypatch.setattr(inspection_service, "resources", lambda _api, kind: snapshot[kind])
    with app.app_context():
        server = Server(agent_id="agent-a", hostname="host-a", ip_address="127.0.0.1",
                        last_heartbeat=utcnow() - timedelta(minutes=2))
        db.session.add(server)
        db.session.flush()
        db.session.add(Metric(server_id=server.id, collected_at=utcnow(),
                              cpu_usage=81, memory_usage=20, disk_usage=30,
                              network_in=0, network_out=0, uptime_seconds=100))
        db.session.commit()
    browser = app.test_client()
    operator = auth(browser, "operator")
    first = browser.post("/api/v1/inspections", headers=operator)
    assert first.status_code == 201
    assert first.json["report"]["finding_count"] == 5
    assert first.json["report"]["cluster"]["warning_events"] == 1
    assert first.json["report"]["status"] == "complete"
    second = browser.post("/api/v1/inspections", headers=operator)
    assert second.status_code == 201
    with app.app_context():
        assert db.session.query(Alert).filter_by(status="open").count() == 3
        assert db.session.query(InspectionRun).count() == 2
        assert db.session.query(AuditLog).filter_by(action="inspection_run").count() == 2
    snapshot["nodes"][0]["ready"] = True
    snapshot["pods"] = []
    snapshot["events"] = []
    with app.app_context():
        db.session.query(Server).one().last_heartbeat = utcnow()
        db.session.commit()
    third = browser.post("/api/v1/inspections", headers=operator)
    assert third.status_code == 201
    with app.app_context():
        assert db.session.query(Alert).filter_by(status="open").count() == 0
        assert db.session.query(Alert).filter_by(status="closed").count() == 3
    viewer = auth(browser, "viewer")
    assert browser.post("/api/v1/inspections", headers=viewer).status_code == 403
    assert browser.get("/api/v1/inspections", headers=viewer).status_code == 200
    assert browser.get("/api/v1/audit-logs", headers=viewer).status_code == 403
    admin = auth(browser, "admin")
    assert browser.get("/api/v1/audit-logs", headers=admin).status_code == 200


def test_failed_cluster_query_preserves_active_cluster_alert(app, monkeypatch):
    from backend.services import inspection_service

    @contextmanager
    def broken(_path):
        raise ValueError("credential path invalid")
        yield

    monkeypatch.setattr(inspection_service, "open_client", broken)
    with app.app_context():
        db.session.add(Alert(alert_type="node_not_ready", source="kubernetes",
                             resource_name="node-a", severity="critical", message="not ready"))
        db.session.commit()
    browser = app.test_client()
    operator = auth(browser, "operator")
    response = browser.post("/api/v1/inspections", headers=operator)
    assert response.status_code == 201
    assert response.json["report"]["status"] == "partial"
    assert "credential path invalid" not in str(response.json)
    with app.app_context():
        assert db.session.query(Alert).one().status == "open"
