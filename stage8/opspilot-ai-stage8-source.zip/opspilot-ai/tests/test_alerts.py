from datetime import datetime, timezone, timedelta
from unittest.mock import Mock

import pytest
from werkzeug.security import generate_password_hash

from backend.app import create_app

from backend.extensions import db
from backend.models import Alert, AuditLog, User


@pytest.fixture
def database_app():
    app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite://", "REDIS_URL": None,
                      "SECRET_KEY": "unit-test-secret-at-least-thirty-two-characters",
                      "AGENT_TOKENS": {"test-host": "test-token"}})
    app.extensions["redis"] = Mock(incr=Mock(return_value=1))
    with app.app_context():
        db.create_all()
        db.session.add(User(username="test-user", password_hash=generate_password_hash("test-password-long"), role="viewer"))
        db.session.commit()
        yield app
        db.session.remove()
        db.drop_all()


def test_metric_alerts_deduplicate_resolve_and_audit(database_app):
    client = database_app.test_client()
    start = datetime.now(timezone.utc).replace(microsecond=0)

    def send(cpu, memory=20, disk=30, offset=0):
        result = client.post("/api/v1/metrics", headers={"Authorization": "Bearer test-token"}, json={
            "agent_id": "test-host", "hostname": "test-host",
            "collected_at": (start + timedelta(seconds=offset)).isoformat(),
            "cpu_usage": cpu, "memory_usage": memory, "disk_usage": disk,
            "network_in": 10, "network_out": 20, "uptime_seconds": 30,
        })
        assert result.status_code == 202

    send(81)
    send(84, offset=1)
    with database_app.app_context():
        assert db.session.query(Alert).filter_by(alert_type="cpu_high", status="open").count() == 1
        assert db.session.query(Alert).count() == 1
    send(70, offset=2)
    with database_app.app_context():
        alert = db.session.query(Alert).filter_by(alert_type="cpu_high").one()
        assert alert.status == "closed" and alert.resolved_at is not None

    headers = client.post("/api/v1/auth/login", json={
        "username": "test-user", "password": "test-password-long"
    }).json
    token = {"Authorization": "Bearer " + headers["access_token"]}
    assert client.get("/api/v1/alerts", headers=token).status_code == 200
    send(10, memory=86, disk=91, offset=3)
    with database_app.app_context():
        user = db.session.query(User).filter_by(username="test-user").one()
        user.role = "operator"
        db.session.commit()
    alerts = client.get("/api/v1/alerts?status=open", headers=token).json["items"]
    memory_alert = next(item for item in alerts if item["alert_type"] == "memory_high")
    assert any(item["alert_type"] == "disk_high" for item in alerts)
    assert client.post(f"/api/v1/alerts/{memory_alert['id']}/acknowledge", headers=token).status_code == 200
    assert client.post(f"/api/v1/alerts/{memory_alert['id']}/close", headers=token).status_code == 200
    assert client.post(f"/api/v1/alerts/{memory_alert['id']}/close", headers=token).status_code == 409
    send(10, memory=88, disk=95, offset=4)
    send(82, memory=88, disk=95, offset=5)
    with database_app.app_context():
        assert db.session.query(AuditLog).filter(AuditLog.action.like("alert_%")).count() == 2
        assert db.session.query(Alert).filter_by(alert_type="memory_high").count() == 1
        assert db.session.query(Alert).filter_by(alert_type="cpu_high").count() == 2


def test_alert_filter_rejects_unknown_status(database_app):
    client = database_app.test_client()
    login = client.post("/api/v1/auth/login", json={
        "username": "test-user", "password": "test-password-long"
    }).json
    response = client.get("/api/v1/alerts?status=invalid", headers={
        "Authorization": "Bearer " + login["access_token"]
    })
    assert response.status_code == 400
