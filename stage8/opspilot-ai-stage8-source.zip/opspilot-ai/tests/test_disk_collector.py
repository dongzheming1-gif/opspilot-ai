from types import SimpleNamespace
from unittest.mock import Mock
from agent import collector


def test_disk_counters_preserve_selected_filesystem(monkeypatch):
    read = Mock(return_value=SimpleNamespace(total=1000, used=930, free=70, percent=93.0))
    monkeypatch.setattr(collector.psutil, 'disk_usage', read)
    assert collector.collect_disk('/isolated-test') == {
        'total_bytes': 1000, 'used_bytes': 930, 'free_bytes': 70, 'disk_usage': 93.0}
    read.assert_called_once_with('/isolated-test')


def test_disk_default_stays_root(monkeypatch):
    read = Mock(return_value=SimpleNamespace(total=1000, used=300, free=700, percent=30.0))
    monkeypatch.setattr(collector.psutil, 'disk_usage', read)
    collector.collect_disk()
    read.assert_called_once_with('/')
