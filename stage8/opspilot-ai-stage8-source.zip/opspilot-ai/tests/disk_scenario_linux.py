"""Opt-in root-only acceptance helper, never run by pytest or the Agent service.

Creates one 64 MiB ext4 loop filesystem, measures it, and removes only its own
files after successful unmount. No existing block device is formatted.
Run with a copy of agent/collector.py named collector.py beside this script.
"""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone

from collector import collect_disk


def run():
    if os.geteuid() != 0:
        raise RuntimeError("Root required only for the isolated test mount")
    if collect_disk('/var/tmp')['free_bytes'] < 1024 ** 3:
        raise RuntimeError("Insufficient host free space for bounded test")
    for command in ('mkfs.ext4', 'mount', 'umount'):
        if shutil.which(command) is None:
            raise RuntimeError("Required filesystem tool unavailable")
    directory = Path(tempfile.mkdtemp(prefix='opspilot-disk-check-', dir='/var/tmp'))
    image = directory / 'disk.img'
    mountpoint = directory / 'mount'
    mounted = False
    report = {'source': 'isolated_ext4_acceptance', 'image_limit_bytes': 64 * 1024 ** 2,
              'host_root_before': collect_disk('/'), 'cleanup_complete': False}
    try:
        mountpoint.mkdir()
        with image.open('xb') as file:
            file.truncate(report['image_limit_bytes'])
        subprocess.run(['mkfs.ext4', '-q', '-F', '-m', '0', str(image)], check=True, timeout=20)
        subprocess.run(['mount', '-o', 'loop,nosuid,nodev,noexec', str(image), str(mountpoint)], check=True, timeout=20)
        mounted = True
        report['before'] = collect_disk(str(mountpoint))
        with (mountpoint / 'bounded-test-data').open('xb') as file:
            block = b'X' * (1024 * 1024)
            # Fixed upper bound even if a filesystem counter is unexpected.
            for _ in range(60):
                if collect_disk(str(mountpoint))['disk_usage'] > 92:
                    break
                file.write(block)
                file.flush()
                os.fsync(file.fileno())
        report['after'] = collect_disk(str(mountpoint))
        report['collected_at'] = datetime.now(timezone.utc).isoformat()
        if not 90 < report['after']['disk_usage'] < 99:
            raise RuntimeError('Test filesystem did not reach expected bounded usage')
    finally:
        if mounted:
            subprocess.run(['umount', str(mountpoint)], check=True, timeout=20)
        # Only remove the new temporary directory, and only after unmount succeeded.
        shutil.rmtree(directory)
        report['cleanup_complete'] = not directory.exists()
        report['host_root_after'] = collect_disk('/')
    print(json.dumps(report))


if __name__ == '__main__':
    run()
