from contextlib import nullcontext
from unittest.mock import Mock
import json
import pytest
from docker.errors import NotFound, DockerException
from backend.services import docker_diagnosis as service
from backend.integrations.deepseek_client import DiagnosisError

ID='a'*64

@pytest.fixture
def engine(monkeypatch):
    container=Mock(attrs={'State':{'Status':'exited','ExitCode':1,'OOMKilled':False,'Error':'SECRET'},'RestartCount':0,'Config':{'Env':['SECRET']}})
    engine=Mock();engine.containers.get.return_value=container
    monkeypatch.setattr(service,'open_docker',lambda _:nullcontext(engine))
    monkeypatch.setattr(service,'read_logs',lambda _: {'logs':'SECRET no such file or directory','truncated':False})
    return engine,container

def test_real_state_shape_and_secret_filter(engine):
    result=service.docker_context({}, {'source':'docker','container_id':ID})
    assert result['evidence'][0]['observation']['exit_code']==1
    assert result['evidence'][1]['observation']['logs']['signals']=={'file_not_found':1}
    assert 'SECRET' not in json.dumps(result)

def test_running_exit_code_not_evidence(engine):
    engine[1].attrs['State']['Status']='running'
    result=service.docker_context({}, {'source':'docker','container_id':ID})
    assert 'exit_code' not in result['evidence'][0]['observation']

@pytest.mark.parametrize('error,status',[(NotFound('private'),404),(DockerException('private'),502)])
def test_errors_sanitized(engine,error,status):
    engine[0].containers.get.side_effect=error
    with pytest.raises(DiagnosisError) as caught:
        service.docker_context({}, {'source':'docker','container_id':ID})
    assert caught.value.status==status and 'private' not in str(caught.value)

@pytest.mark.parametrize('value',['short','../socket',None])
def test_container_id_validation(value):
    with pytest.raises(DiagnosisError):
        service.validate_docker_selection({'source':'docker','container_id':value})
